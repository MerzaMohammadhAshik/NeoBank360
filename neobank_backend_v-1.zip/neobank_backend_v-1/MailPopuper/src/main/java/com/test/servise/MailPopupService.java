package com.test.servise;



import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.SwingUtilities;

@Service
public class MailPopupService {

    private final JdbcTemplate jdbcTemplate;

    // ✅ Track mails already shown
    private final Set<Long> activePopups = ConcurrentHashMap.newKeySet();

    public MailPopupService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void startPolling() {
        Executors.newSingleThreadScheduledExecutor()
                .scheduleAtFixedRate(this::checkNewMail, 0, 3, TimeUnit.SECONDS);
    }

    private void checkNewMail() {
        String sql = """
            SELECT id, subject, body
            FROM dev_mails
            WHERE seen = 0
            ORDER BY created_at ASC
        """;

        List<Map<String, Object>> mails = jdbcTemplate.queryForList(sql);

        for (Map<String, Object> mail : mails) {
            Long id = ((Number) mail.get("id")).longValue();

            // ✅ Skip if already displayed
            if (activePopups.contains(id)) {
                continue;
            }

            activePopups.add(id);

            String subject = (String) mail.get("subject");
            String body = (String) mail.get("body");

            SwingUtilities.invokeLater(() ->
                    new MailPopup(
                            id,
                            subject,
                            body,
                            jdbcTemplate,
                            activePopups   // ✅ pass set
                    )
            );
        }
    }
}

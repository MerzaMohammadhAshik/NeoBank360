package com.test.servise;



import javax.swing.*;
import javax.swing.border.EmptyBorder;

import org.springframework.jdbc.core.JdbcTemplate;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MailPopup extends JFrame {

    private final Long mailId;
    private final JdbcTemplate jdbcTemplate;
    private final Set<Long> activePopups;

    public MailPopup(Long mailId,
                     String subject,
                     String body,
                     JdbcTemplate jdbcTemplate,
                     Set<Long> activePopups) {

        this.mailId = mailId;
        this.jdbcTemplate = jdbcTemplate;
        this.activePopups = activePopups;

        setTitle("New Mail Received");
        setSize(470, 310);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // ✅ Text area with LEFT padding
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBorder(new EmptyBorder(10, 12, 10, 10)); // ✅ padding
        textArea.setText("Subject: " + subject + "\n\n" + body);

        JScrollPane scrollPane = new JScrollPane(textArea);

        // ✅ Button panel (right aligned)
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        String otp = extractOtp(body);

        if (otp != null) {
            // ✅ Show OTP on button
            JButton copyBtn = new JButton("Copy OTP : " + otp);
            copyBtn.addActionListener(e -> {
                copyToClipboard(otp);
                markSeenAndClose();
            });
            buttonPanel.add(copyBtn);
        }

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> markSeenAndClose());
        buttonPanel.add(closeBtn);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // -------- Helpers --------

    private void markSeenAndClose() {
        jdbcTemplate.update(
                "UPDATE dev_mails SET seen = 1 WHERE id = ?",
                mailId
        );
        activePopups.remove(mailId);
        dispose();
    }

    private String extractOtp(String text) {
        Matcher matcher = Pattern.compile("\\b\\d{4,8}\\b").matcher(text);
        return matcher.find() ? matcher.group() : null;
    }

    private void copyToClipboard(String otp) {
        Toolkit.getDefaultToolkit()
                .getSystemClipboard()
                .setContents(new StringSelection(otp), null);
    }
}
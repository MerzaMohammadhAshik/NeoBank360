package com.test;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.test.servise.MailPopupService;

@SpringBootApplication
public class TestApplication {

    public static void main(String[] args) {

        System.setProperty("java.awt.headless", "false");

        ApplicationContext context =
                SpringApplication.run(TestApplication.class, args);

        MailPopupService service = context.getBean(MailPopupService.class);
        service.startPolling();
    }
}
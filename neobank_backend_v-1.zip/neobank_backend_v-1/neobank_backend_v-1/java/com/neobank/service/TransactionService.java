// src/main/java/com/neobank/service/TransactionService.java

package com.neobank.service;

import com.neobank.dto.transaction.*;
import com.neobank.entity.*;
import com.neobank.entity.Transaction.*;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.*;
import com.neobank.util.TransactionReferenceGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepository          transactionRepository;
    private final AccountRepository              accountRepository;
    private final UserRepository                 userRepository;
    private final TransactionReferenceGenerator  refGen;
    private final MailService                    mailService;

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    // ─────────────────────────────────────────────
    //  ADMIN: DEPOSIT
    // ─────────────────────────────────────────────

    @Transactional
    public TransactionResponseDTO adminDeposit(AdminTransactionRequestDTO req, String adminUsername) {

        Account account = findAccount(req.getAccountNumber());
        validateAccountOperable(account);

        BigDecimal amount = parseBigDecimal(req.getAmount(), "amount");

        BigDecimal balBefore = account.getBalance();
        account.setBalance(balBefore.add(amount));
        account.recalculateAvailableBalance();
        account.setLastTransactionAt(LocalDateTime.now());
        accountRepository.save(account);

        Transaction txn = Transaction.builder()
                .referenceNumber(refGen.generate())
                .toAccount(account)
                .toAccountNumber(account.getAccountNumber())
                .amount(amount)
                .netAmount(amount)
                .charges(BigDecimal.ZERO)
                .currency("INR")
                .transactionType(TransactionType.DEPOSIT)
                .transactionMode(TransactionMode.ADMIN)
                .description(req.getDescription() != null ? req.getDescription() : "Admin Deposit")
                .remarks(req.getRemarks())
                .toBalanceBefore(balBefore)
                .toBalanceAfter(account.getBalance())
                .status(TransactionStatus.SUCCESS)
                .initiatedByUsername(adminUsername)
                .initiatedByRole(InitiatedByRole.ADMIN)
                .processedAt(LocalDateTime.now())
                .build();

        Transaction saved = transactionRepository.save(txn);
        log.info("Admin deposit: {} → {} ₹{}", adminUsername, account.getAccountNumber(), amount);

        // Notify customer
        notifyTransaction(account, saved, "credited");

        return buildResponse(saved, account.getAccountNumber());
    }

    // ─────────────────────────────────────────────
    //  ADMIN: WITHDRAW
    // ─────────────────────────────────────────────

    @Transactional
    public TransactionResponseDTO adminWithdraw(AdminTransactionRequestDTO req, String adminUsername) {

        Account account = findAccount(req.getAccountNumber());
        validateAccountOperable(account);

        BigDecimal amount = parseBigDecimal(req.getAmount(), "amount");

        if (!account.hasSufficientBalance(amount)) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST, "INSUFFICIENT_BALANCE",
                    "Insufficient balance. Available: ₹" + account.getAvailableBalance());
        }

        BigDecimal balBefore = account.getBalance();
        account.setBalance(balBefore.subtract(amount));
        account.recalculateAvailableBalance();
        account.setLastTransactionAt(LocalDateTime.now());
        accountRepository.save(account);

        Transaction txn = Transaction.builder()
                .referenceNumber(refGen.generate())
                .fromAccount(account)
                .fromAccountNumber(account.getAccountNumber())
                .amount(amount)
                .netAmount(amount)
                .charges(BigDecimal.ZERO)
                .currency("INR")
                .transactionType(TransactionType.WITHDRAWAL)
                .transactionMode(TransactionMode.ADMIN)
                .description(req.getDescription() != null ? req.getDescription() : "Admin Withdrawal")
                .remarks(req.getRemarks())
                .fromBalanceBefore(balBefore)
                .fromBalanceAfter(account.getBalance())
                .status(TransactionStatus.SUCCESS)
                .initiatedByUsername(adminUsername)
                .initiatedByRole(InitiatedByRole.ADMIN)
                .processedAt(LocalDateTime.now())
                .build();

        Transaction saved = transactionRepository.save(txn);
        log.info("Admin withdrawal: {} → {} ₹{}", adminUsername, account.getAccountNumber(), amount);
        notifyTransaction(account, saved, "debited");
        return buildResponse(saved, account.getAccountNumber());
    }

    // ─────────────────────────────────────────────
    //  CUSTOMER: INTERNAL TRANSFER
    // ─────────────────────────────────────────────

    @Transactional
    public TransactionResponseDTO transfer(TransferRequestDTO req, String username) {

        Account from = findAccount(req.getFromAccountNumber());
        Account to   = findAccount(req.getToAccountNumber());

        validateAccountOperable(from);
        validateAccountOperable(to);
        validateOwnership(from, username);

        BigDecimal amount = parseBigDecimal(req.getAmount(), "amount");

        if (!from.hasSufficientBalance(amount)) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST, "INSUFFICIENT_BALANCE",
                    "Insufficient balance. Available: ₹" + from.getAvailableBalance());
        }

        if (amount.compareTo(from.getPerTransactionLimit()) > 0) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST, "LIMIT_EXCEEDED",
                    "Amount exceeds per-transaction limit of ₹" + from.getPerTransactionLimit());
        }

        BigDecimal fromBefore = from.getBalance();
        BigDecimal toBefore   = to.getBalance();

        from.setBalance(fromBefore.subtract(amount));
        to.setBalance(toBefore.add(amount));
        from.recalculateAvailableBalance();
        to.recalculateAvailableBalance();
        from.setLastTransactionAt(LocalDateTime.now());
        to.setLastTransactionAt(LocalDateTime.now());

        accountRepository.save(from);
        accountRepository.save(to);

        TransactionMode mode = switch (req.getMode() != null ? req.getMode().toUpperCase() : "TRANSFER") {
            case "UPI"  -> TransactionMode.ONLINE;
            case "NEFT" -> TransactionMode.ONLINE;
            default     -> TransactionMode.ONLINE;
        };

        TransactionType type = switch (req.getMode() != null ? req.getMode().toUpperCase() : "TRANSFER") {
            case "UPI"  -> TransactionType.UPI;
            case "NEFT" -> TransactionType.NEFT;
            default     -> TransactionType.TRANSFER;
        };

        Transaction txn = Transaction.builder()
                .referenceNumber(refGen.generate())
                .fromAccount(from)
                .toAccount(to)
                .fromAccountNumber(from.getAccountNumber())
                .toAccountNumber(to.getAccountNumber())
                .amount(amount)
                .netAmount(amount)
                .charges(BigDecimal.ZERO)
                .currency("INR")
                .transactionType(type)
                .transactionMode(mode)
                .upiId(req.getUpiId())
                .beneficiaryName(req.getBeneficiaryName())
                .beneficiaryIfsc(req.getBeneficiaryIfsc())
                .beneficiaryBankName(req.getBeneficiaryBankName())
                .description(req.getDescription())
                .fromBalanceBefore(fromBefore)
                .fromBalanceAfter(from.getBalance())
                .toBalanceBefore(toBefore)
                .toBalanceAfter(to.getBalance())
                .status(TransactionStatus.SUCCESS)
                .initiatedByUsername(username)
                .initiatedByRole(InitiatedByRole.CUSTOMER)
                .processedAt(LocalDateTime.now())
                .build();

        Transaction saved = transactionRepository.save(txn);
        log.info("Transfer: {} → {} ₹{}", from.getAccountNumber(), to.getAccountNumber(), amount);
        return buildResponse(saved, from.getAccountNumber());
    }

    // ─────────────────────────────────────────────
    //  GET TRANSACTIONS
    // ─────────────────────────────────────────────

    public Page<TransactionResponseDTO> getAccountTransactions(
            String accountNumber, String username, Pageable pageable) {

        Account account = findAccount(accountNumber);
        validateOwnership(account, username);
        return transactionRepository
                .findByAccountId(account.getId(), pageable)
                .map(t -> buildResponse(t, accountNumber));
    }

    public Page<TransactionResponseDTO> getAllTransactions(Pageable pageable) {
        return transactionRepository.findAll(pageable)
                .map(t -> buildResponse(t, null));
    }

    // ─────────────────────────────────────────────
    //  PRIVATE HELPERS
    // ─────────────────────────────────────────────

    private Account findAccount(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new NeoBankException(
                        HttpStatus.NOT_FOUND, "ACCOUNT_NOT_FOUND",
                        "Account not found: " + accountNumber));
    }

    private void validateAccountOperable(Account account) {
        if (!account.isOperable()) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST, "ACCOUNT_NOT_OPERABLE",
                    "Account " + account.getAccountNumber() + " is " + account.getStatus().name());
        }
    }

    private void validateOwnership(Account account, String username) {
        if (!account.getUser().getUsername().equals(username)) {
            throw new NeoBankException(HttpStatus.FORBIDDEN, "ACCESS_DENIED",
                    "You don't have access to this account.");
        }
    }

    private BigDecimal parseBigDecimal(String val, String field) {
        try {
            BigDecimal bd = new BigDecimal(val);
            if (bd.compareTo(BigDecimal.ZERO) <= 0)
                throw new NeoBankException(HttpStatus.BAD_REQUEST, "INVALID_" + field.toUpperCase(),
                        field + " must be greater than 0.");
            return bd;
        } catch (NumberFormatException e) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST, "INVALID_" + field.toUpperCase(),
                    "Invalid " + field + " value.");
        }
    }

    private void notifyTransaction(Account account, Transaction txn, String direction) {
        try {
            String email = account.getUser().getEmail();
            mailService.sendMail(email,
                "NeoBank — Transaction Alert",
                """
                Dear %s,

                ₹%s has been %s your account.

                Reference : %s
                Type      : %s
                Amount    : ₹%s
                Balance   : ₹%s
                Date/Time : %s

                Regards,
                NeoBank Team
                """.formatted(
                    account.getUser().getFullName() != null ? account.getUser().getFullName() : "Customer",
                    txn.getAmount(),
                    direction,
                    txn.getReferenceNumber(),
                    txn.getTransactionType(),
                    txn.getAmount(),
                    direction.equals("credited") ? txn.getToBalanceAfter() : txn.getFromBalanceAfter(),
                    txn.getProcessedAt().format(FMT)
                )
            );
        } catch (Exception e) {
            log.warn("Transaction email failed: {}", txn.getReferenceNumber());
        }
    }

    private TransactionResponseDTO buildResponse(Transaction t, String perspectiveAccount) {
        String balAfter = null;
        if (perspectiveAccount != null) {
            if (perspectiveAccount.equals(t.getFromAccountNumber()) && t.getFromBalanceAfter() != null)
                balAfter = t.getFromBalanceAfter().toPlainString();
            else if (perspectiveAccount.equals(t.getToAccountNumber()) && t.getToBalanceAfter() != null)
                balAfter = t.getToBalanceAfter().toPlainString();
        }

        return TransactionResponseDTO.builder()
                .id(t.getId())
                .referenceNumber(t.getReferenceNumber())
                .transactionType(t.getTransactionType().name())
                .transactionMode(t.getTransactionMode().name())
                .amount(t.getAmount().toPlainString())
                .charges(t.getCharges() != null ? t.getCharges().toPlainString() : "0")
                .netAmount(t.getNetAmount() != null ? t.getNetAmount().toPlainString() : t.getAmount().toPlainString())
                .fromAccountNumber(t.getFromAccountNumber())
                .toAccountNumber(t.getToAccountNumber())
                .beneficiaryName(t.getBeneficiaryName())
                .upiId(t.getUpiId())
                .description(t.getDescription())
                .status(t.getStatus().name())
                .balanceAfter(balAfter)
                .createdAt(t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : null)
                .processedAt(t.getProcessedAt() != null ? t.getProcessedAt().format(FMT) : null)
                .build();
    }
}
// src/main/java/com/neobank/entity/OtpVerification.java

package com.neobank.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "otp_verifications",
    indexes = {
        @Index(name = "idx_otp_email",   columnList = "email"),
        @Index(name = "idx_otp_code",    columnList = "otp_code"),
        @Index(name = "idx_otp_expires", columnList = "expires_at")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OtpVerification {

    // ─────────────────────────────────────────────
    //  PRIMARY KEY
    // ─────────────────────────────────────────────

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ─────────────────────────────────────────────
    //  TARGET — which email this OTP was sent to
    // ─────────────────────────────────────────────

    @Column(name = "email", nullable = false, length = 150)
    private String email;

    // ─────────────────────────────────────────────
    //  OTP DETAILS
    // ─────────────────────────────────────────────

    @Column(name = "otp_code", nullable = false, length = 6)
    private String otpCode;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;  // generated_at + 10 minutes

    @Column(name = "verified", nullable = false)
    private Boolean verified = false;

    @Column(name = "verified_at")
    private LocalDateTime verifiedAt;

    // ─────────────────────────────────────────────
    //  ATTEMPT TRACKING — block brute force
    // ─────────────────────────────────────────────

    @Column(name = "attempt_count", nullable = false)
    private Integer attemptCount = 0;   // max 5 attempts allowed

    @Column(name = "max_attempts", nullable = false)
    private Integer maxAttempts = 5;

    // ─────────────────────────────────────────────
    //  PURPOSE — reusable for other flows too
    // ─────────────────────────────────────────────

    @Enumerated(EnumType.STRING)
    @Column(name = "purpose", nullable = false, length = 30)
    private OtpPurpose purpose = OtpPurpose.APPLICATION_SUBMIT;

    // ─────────────────────────────────────────────
    //  LINK TO APPLICATION (nullable — set after verify)
    // ─────────────────────────────────────────────

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id_fk", referencedColumnName = "id")
    private Application application;

    // ─────────────────────────────────────────────
    //  AUDIT
    // ─────────────────────────────────────────────

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // ─────────────────────────────────────────────
    //  HELPER METHODS
    // ─────────────────────────────────────────────

    /** OTP is expired if current time is past expiresAt */
    public boolean isExpired() {
        return LocalDateTime.now().isAfter(this.expiresAt);
    }

    /** OTP is exhausted if max attempts reached */
    public boolean isExhausted() {
        return this.attemptCount >= this.maxAttempts;
    }

    /** Increment attempt count on each wrong try */
    public void incrementAttempt() {
        this.attemptCount++;
    }

    /** Mark as verified */
    public void markVerified() {
        this.verified = true;
        this.verifiedAt = LocalDateTime.now();
    }

    // ─────────────────────────────────────────────
    //  ENUMS
    // ─────────────────────────────────────────────

    public enum OtpPurpose {
        APPLICATION_SUBMIT,
        STATUS_CHECK,
        REGISTRATION,        // ← add
        PASSWORD_RESET,
        USERNAME_RECOVERY,   // ← add
        EMAIL_CHANGE
    }
}
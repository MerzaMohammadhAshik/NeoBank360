//// src/main/java/com/neobank/config/SecurityConfig.java


package com.neobank.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import lombok.RequiredArgsConstructor;

import java.util.List;


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor          // ADD — inject the filter
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter; // ADD

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .requestMatchers(
                    "/api/application/send-otp",
                    "/api/application/submit",
                    "/api/application/status/send-otp",
                    "/api/application/status/verify",
                    "/api/auth/**",
                    "/api/account/my",
                    "/actuator/health"
                ).permitAll()
                .requestMatchers("/api/application/submit-auth").hasAnyRole("CUSTOMER", "ADMIN")
                .requestMatchers("/api/auth/change-password").authenticated()
                .requestMatchers("/api/account/my",
                                 "/api/transaction/transfer",
                                 "/api/transaction/my/**").authenticated()

                .requestMatchers("/api/transaction/transfer",
                                 "/api/transaction/my/**").authenticated()
                .requestMatchers("/api/transaction/admin/**",
                                 "/api/account/admin/**").hasAnyRole("ADMIN","SUPER_ADMIN","MANAGER")
                .requestMatchers(
                    "/api/application/all",
                    "/api/application/approve",
                    "/api/application/**"       // covers /{applicationId} GET
                ).hasAnyRole("ADMIN", "SUPER_ADMIN")   // UNCOMMENT — now JWT works
                .anyRequest().authenticated()           // UNCOMMENT
            )
            // ADD THIS LINE — register the filter
            .addFilterBefore(jwtAuthenticationFilter,
                UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
  @Bean
  public CorsConfigurationSource corsConfigurationSource() {
      CorsConfiguration config = new CorsConfiguration();

      // ── Allowed origins ──
      config.setAllowedOrigins(List.of(
          "http://192.168.29.16:4200",
          "http://192.168.29.16:4201",
          "http://192.168.29.16:4202",
          "http://localhost:4202",
    	  "http://localhost:4201",
          "http://localhost:4200",        // Angular dev
          "http://localhost:3000",        // React dev (if needed)
          "https://your-frontend.com"     // Production — replace with real URL
      ));

      // ── Allowed HTTP methods ──
      config.setAllowedMethods(List.of(
          "GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"
      ));

      // ── Allowed headers ──
      config.setAllowedHeaders(List.of(
          "Authorization",
          "Content-Type",
          "Accept",
          "Origin",
          "X-Requested-With"
      ));

      // ── Expose headers to frontend ──
      config.setExposedHeaders(List.of(
          "Authorization"
      ));

      // ── Allow credentials (cookies / auth headers) ──
      config.setAllowCredentials(true);

      // ── Cache preflight for 1 hour ──
      config.setMaxAge(3600L);

      UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
      source.registerCorsConfiguration("/**", config);
      return source;
  }

  // ─────────────────────────────────────────────
  //  PASSWORD ENCODER
  // ─────────────────────────────────────────────

  @Bean
  public PasswordEncoder passwordEncoder() {
      return new BCryptPasswordEncoder(12); // strength 12
  }
}














//
//package com.neobank.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//import java.util.List;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//    // ─────────────────────────────────────────────
//    //  SECURITY FILTER CHAIN
//    // ─────────────────────────────────────────────
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//            // ── Disable CSRF (REST API — stateless) ──
//            .csrf(AbstractHttpConfigurer::disable)
//
//            // ── CORS ──
//            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
//
//            // ── Stateless session ──
//            .sessionManagement(session ->
//                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//            )
//
//            // ── Route permissions ──
//            .authorizeHttpRequests(auth -> auth
//            		.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
//            	    .requestMatchers(
//            	        "/api/application/send-otp",
//            	        "/api/application/submit",
//            	        "/api/application/status/send-otp",
//            	        "/api/application/status/verify",
//            	        "/api/auth/**",
//            	        "/actuator/health"
//            	    ).permitAll()
//
//            	    // Admin only
//            	    .requestMatchers(
//            	        "/api/application/all",
//            	        "/api/application/approve"
////            	    ).hasAnyRole("ADMIN", "SUPER_ADMIN")
//            	    ).permitAll()
//
//            	    // Admin + Manager
////            	    .requestMatchers(
////            	        "/api/application/*"
////            	    ).hasAnyRole("ADMIN", "SUPER_ADMIN", "MANAGER")
//
////            	    .anyRequest().authenticated()
//            	    .anyRequest().permitAll()
//            	);
//
//        return http.build();
//    }
//
//    // ─────────────────────────────────────────────
//    //  CORS CONFIGURATION
//    // ─────────────────────────────────────────────
//
//    @Bean
//    public CorsConfigurationSource corsConfigurationSource() {
//        CorsConfiguration config = new CorsConfiguration();
//
//        // ── Allowed origins ──
//        config.setAllowedOrigins(List.of(
//            "http://localhost:4200",        // Angular dev
//            "http://localhost:3000",        // React dev (if needed)
//            "https://your-frontend.com"     // Production — replace with real URL
//        ));
//
//        // ── Allowed HTTP methods ──
//        config.setAllowedMethods(List.of(
//            "GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"
//        ));
//
//        // ── Allowed headers ──
//        config.setAllowedHeaders(List.of(
//            "Authorization",
//            "Content-Type",
//            "Accept",
//            "Origin",
//            "X-Requested-With"
//        ));
//
//        // ── Expose headers to frontend ──
//        config.setExposedHeaders(List.of(
//            "Authorization"
//        ));
//
//        // ── Allow credentials (cookies / auth headers) ──
//        config.setAllowCredentials(true);
//
//        // ── Cache preflight for 1 hour ──
//        config.setMaxAge(3600L);
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", config);
//        return source;
//    }
//
//    // ─────────────────────────────────────────────
//    //  PASSWORD ENCODER
//    // ─────────────────────────────────────────────
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder(12); // strength 12
//    }
//}
//
//
//
//
/////////////////////////////
/////
/////
////@RequiredArgsConstructor
////public class SomeService {
////
////    private final PasswordEncoder passwordEncoder;
////
////    // Encode
////    String hashed = passwordEncoder.encode(rawPassword);
////
////    // Verify
////    boolean match = passwordEncoder.matches(rawPassword, hashedFromDb);
////}
//
//

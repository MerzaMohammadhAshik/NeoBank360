// src/main/java/com/neobank/repository/TransactionRepository.java

package com.neobank.repository;

import com.neobank.entity.Transaction;
import com.neobank.entity.Transaction.TransactionStatus;
import com.neobank.entity.Transaction.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    // For reference number generation
    @Query("SELECT t.referenceNumber FROM Transaction t WHERE t.referenceNumber LIKE :prefix% ORDER BY t.referenceNumber DESC LIMIT 1")
    Optional<String> findLastReferenceByPrefix(String prefix);

    // Customer - my transactions
    @Query("SELECT t FROM Transaction t WHERE t.fromAccount.id = :accountId OR t.toAccount.id = :accountId ORDER BY t.createdAt DESC")
    Page<Transaction> findByAccountId(Long accountId, Pageable pageable);

    // Admin - all transactions with optional filters
    Page<Transaction> findByStatusOrderByCreatedAtDesc(TransactionStatus status, Pageable pageable);
    Page<Transaction> findByTransactionTypeOrderByCreatedAtDesc(TransactionType type, Pageable pageable);

    // Stats
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.toAccount.id = :accountId AND t.status = 'SUCCESS' AND t.transactionType = 'DEPOSIT'")
    BigDecimal getTotalDeposits(Long accountId);

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.fromAccount.id = :accountId AND t.status = 'SUCCESS'")
    BigDecimal getTotalWithdrawals(Long accountId);
}
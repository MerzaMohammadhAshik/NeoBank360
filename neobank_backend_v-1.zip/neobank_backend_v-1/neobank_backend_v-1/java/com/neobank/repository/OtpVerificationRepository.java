// src/main/java/com/neobank/repository/OtpVerificationRepository.java

package com.neobank.repository;

import com.neobank.entity.OtpVerification;
import com.neobank.entity.OtpVerification.OtpPurpose;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OtpVerificationRepository extends JpaRepository<OtpVerification, Long> {

    // Get latest unverified, unexpired OTP for this email + purpose
    @Query("""
        SELECT o FROM OtpVerification o
        WHERE o.email = :email
        AND o.purpose = :purpose
        AND o.verified = false
        ORDER BY o.createdAt DESC
        LIMIT 1
    """)
    Optional<OtpVerification> findLatestActiveOtp(String email, OtpPurpose purpose);

    // Delete all OTPs for email after successful verification (cleanup)
    void deleteAllByEmailAndPurpose(String email, OtpPurpose purpose);
}
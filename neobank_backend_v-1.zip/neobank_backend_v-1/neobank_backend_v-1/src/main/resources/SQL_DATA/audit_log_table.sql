-- 13_create_system_audit_log_table.sql

CREATE TABLE IF NOT EXISTS system_audit_log (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    endpoint          VARCHAR(500) NOT NULL,
    http_method       VARCHAR(10)  NOT NULL,
    response_status   INT          NOT NULL,
    execution_time_ms BIGINT       NOT NULL,
    acting_user_id    BIGINT       NULL,
    error_message     VARCHAR(1000) NULL,
    event_timestamp   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_status    (response_status),
    INDEX idx_audit_timestamp (event_timestamp)
);

-- 14_add_composite_indexes.sql (Day 46 — bonus, do now)

ALTER TABLE transactions
  ADD INDEX idx_txn_account_date (
      from_account_id, created_at);

ALTER TABLE transactions
  ADD INDEX idx_txn_to_account_date (
      to_account_id, created_at);

ALTER TABLE loans
  ADD INDEX idx_loan_status (status);
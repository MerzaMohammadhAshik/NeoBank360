-- 11_create_audit_logs_table.sql

CREATE TABLE IF NOT EXISTS audit_logs (
    id                   BIGINT AUTO_INCREMENT PRIMARY KEY,
    admin_username       VARCHAR(100) NOT NULL,
    admin_user_id        BIGINT,
    action               VARCHAR(50)  NOT NULL,
    target_resource_type VARCHAR(50)  NOT NULL,
    target_resource_id   VARCHAR(50),
    details              VARCHAR(500),
    ip_address           VARCHAR(50),
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_al_admin    (admin_username),
    INDEX idx_al_resource (target_resource_type),
    INDEX idx_al_created  (created_at)
);

-- 12_seed_sprint4_transactions.sql
-- Extra transactions for trendSummary testing

-- customer1 (user_id=2, account_id=1):
-- Add 10+ credits and debits for each of last 6 months

INSERT INTO transactions (
    reference_number, to_account_id, to_account_number,
    amount, net_amount, charges, currency,
    transaction_type, transaction_mode,
    description, to_balance_before, to_balance_after,
    status, initiated_by_username, initiated_by_role,
    processed_at, created_at
) VALUES
-- Month 1 (6 months ago)
('TXN20260000101', 1, 'NB20260000000001',
 15000.00, 15000.00, 0.00, 'INR',
 'DEPOSIT', 'ADMIN',
 'Salary Credit Jan',
 50000.00, 65000.00, 'SUCCESS',
 'SYSTEM', 'SYSTEM',
 NOW() - INTERVAL 5 MONTH,
 NOW() - INTERVAL 5 MONTH),

('TXN20260000102', NULL, NULL,
 3500.00, 3500.00, 0.00, 'INR',
 'WITHDRAWAL', 'ONLINE',
 'Grocery Shopping',
 65000.00, 61500.00, 'SUCCESS',
 'customer1', 'CUSTOMER',
 NOW() - INTERVAL 5 MONTH + INTERVAL 5 DAY,
 NOW() - INTERVAL 5 MONTH + INTERVAL 5 DAY),

-- Add similar rows for months 2-6...
-- (truncated for brevity — add similar patterns)

-- Month 6 (current month)
('TXN20260000161', 1, 'NB20260000000001',
 15000.00, 15000.00, 0.00, 'INR',
 'DEPOSIT', 'ADMIN', 'Salary Credit This Month',
 60000.00, 75000.00, 'SUCCESS',
 'SYSTEM', 'SYSTEM', NOW(), NOW()),

('TXN20260000162', NULL, NULL,
 4200.00, 4200.00, 0.00, 'INR',
 'WITHDRAWAL', 'ONLINE', 'Utility Bills',
 75000.00, 70800.00, 'SUCCESS',
 'customer1', 'CUSTOMER', NOW(), NOW());
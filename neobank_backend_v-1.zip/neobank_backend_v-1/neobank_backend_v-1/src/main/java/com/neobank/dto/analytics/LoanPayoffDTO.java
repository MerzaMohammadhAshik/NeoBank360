package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanPayoffDTO {
    private String loanId;
    private String loanType;
    private String productName;
    private String outstandingBalance;
    private String emiAmount;
    private Integer monthsRemaining;
    private String projectedPayoffDate;
}

// ── RewardAccrualDTO.java ──
// ── TransactionAnalyticsDTO.java ──
package com.neobank.dto.analytics;
import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class TransactionAnalyticsDTO {
    private String timeframe;
    private List<DailyVolumeDTO> dailyVolumes;
    private String averageTicketSize;
    private String totalInflow;
    private String totalOutflow;
    private Long totalTransactionCount;
}

// ── DailyVolumeDTO.java ──
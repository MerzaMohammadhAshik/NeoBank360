package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ErrorRatePointDTO {
    private String hour;       // "2026-06-11 14:00"
    private Long total;
    private Long errors;
    private String errorRate;  // "12.50"
}

// ── ResponseTimePointDTO.java ──
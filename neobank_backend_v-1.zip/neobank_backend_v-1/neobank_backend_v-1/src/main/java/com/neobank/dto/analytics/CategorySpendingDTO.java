// ── CategorySpendingDTO.java ──
package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CategorySpendingDTO {
    private String month;        // "2026-01"
    private String monthLabel;   // "Jan 2026"
    private List<CategoryAmountDTO> categories;
    private String totalSpent;
}

// ── CategoryAmountDTO.java ──
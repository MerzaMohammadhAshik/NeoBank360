// src/main/java/com/neobank/entity/SystemAuditLog.java

package com.neobank.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "system_audit_log",
    indexes = {
        @Index(name = "idx_audit_status",
               columnList = "response_status"),
        @Index(name = "idx_audit_timestamp",
               columnList = "event_timestamp"),
    }
)
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class SystemAuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "endpoint",
            nullable = false, length = 500)
    private String endpoint;

    @Column(name = "http_method",
            nullable = false, length = 10)
    private String httpMethod;

    @Column(name = "response_status", nullable = false)
    private Integer responseStatus;

    @Column(name = "execution_time_ms", nullable = false)
    private Long executionTimeMs;

    @Column(name = "acting_user_id")
    private Long actingUserId;

    @Column(name = "error_message", length = 1000)
    private String errorMessage;

    @CreationTimestamp
    @Column(name = "event_timestamp", updatable = false)
    private LocalDateTime eventTimestamp;
}
// ── FinancialInsightsDTO.java ──
package com.neobank.dto.insights;
import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class FinancialInsightsDTO {
    private String       totalIncome;
    private String       totalExpense;
    private String       savings;
    private Boolean      savingsNegative;
    private List<TrendEntryDTO> trendSummary;
    private String       currency;
    private String       generatedAt;
}

// ── TrendEntryDTO.java ──
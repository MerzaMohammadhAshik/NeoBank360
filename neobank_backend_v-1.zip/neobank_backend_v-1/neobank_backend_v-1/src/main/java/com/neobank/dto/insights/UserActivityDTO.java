package com.neobank.dto.insights;
import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class UserActivityDTO {
    private Long   userId;
    private String username;
    private String fullName;
    private String email;
    private String status;
    private String lastLoginAt;
    private List<ActivityTransactionDTO> recentTransactions;
    private String totalTransactions;
    private String totalCredit;
    private String totalDebit;
}

// ── ActivityTransactionDTO.java ──
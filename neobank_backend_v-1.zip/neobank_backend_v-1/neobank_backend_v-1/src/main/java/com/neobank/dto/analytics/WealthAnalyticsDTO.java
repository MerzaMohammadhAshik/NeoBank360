package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class WealthAnalyticsDTO {
    private List<NetWorthEntryDTO> netWorthTimeline;
    private List<LoanPayoffDTO> loanPayoffForecast;
    private List<RewardAccrualDTO> rewardAccrualHistory;
    private String currentNetWorth;
    private String generatedAt;
}

// ── NetWorthEntryDTO.java ──
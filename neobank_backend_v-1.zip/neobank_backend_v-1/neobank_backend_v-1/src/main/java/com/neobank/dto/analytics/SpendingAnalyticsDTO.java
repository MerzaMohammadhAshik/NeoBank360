package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class SpendingAnalyticsDTO {
    private List<CategorySpendingDTO> monthlySpending;
    private List<String> categories;  // distinct category list
    private String generatedAt;
}

// ── WealthAnalyticsDTO.java ──
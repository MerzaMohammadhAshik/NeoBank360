// src/main/java/com/neobank/service/InsightsService.java

package com.neobank.service;

import com.neobank.dto.insights.*;
import com.neobank.entity.User;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class InsightsService {

    private final InsightsRepository insightsRepository;
    private final UserRepository     userRepository;

    private static final DateTimeFormatter FMT_FULL =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");
    private static final DateTimeFormatter FMT_MONTH =
            DateTimeFormatter.ofPattern("MMM yyyy");

    // ─────────────────────────────────────────────
    //  GET FINANCIAL INSIGHTS FOR USER
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public FinancialInsightsDTO getInsights(
            Long pathUserId, String jwtUsername) {

        // ── Security: JWT user must match path ──
        User user = userRepository.findByUsername(jwtUsername)
                .orElseThrow(() -> new NeoBankException(
                        HttpStatus.NOT_FOUND,
                        "USER_NOT_FOUND", "User not found."));

        if (!user.getId().equals(pathUserId)) {
            throw new NeoBankException(HttpStatus.FORBIDDEN,
                    "ACCESS_DENIED",
                    "You can only view your own insights.");
        }

        // ── Aggregations ──
        BigDecimal totalIncome =
                insightsRepository.getTotalIncome(user.getId());
        BigDecimal totalExpense =
                insightsRepository.getTotalExpense(user.getId());

        if (totalIncome  == null) totalIncome  = BigDecimal.ZERO;
        if (totalExpense == null) totalExpense = BigDecimal.ZERO;

        BigDecimal savings = totalIncome.subtract(totalExpense);
        boolean    isNegative = savings.compareTo(BigDecimal.ZERO) < 0;

        // ── 6-month trend ──
        List<TrendEntryDTO> trend = buildTrendSummary(user.getId());

        return FinancialInsightsDTO.builder()
                .totalIncome(totalIncome
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .totalExpense(totalExpense
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .savings(savings
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .savingsNegative(isNegative)
                .trendSummary(trend)
                .currency("INR")
                .generatedAt(LocalDateTime.now().format(FMT_FULL))
                .build();
    }

    // ─────────────────────────────────────────────
    //  BUILD 6-MONTH TREND (zero-padded)
    // ─────────────────────────────────────────────

    private List<TrendEntryDTO> buildTrendSummary(Long userId) {

        // Go back 6 full months from start of current month
        LocalDateTime from = LocalDate.now()
                .withDayOfMonth(1)
                .minusMonths(5)
                .atStartOfDay();

        // DB results (may be missing some months)
        List<Object[]> rows =
                insightsRepository.getMonthlyTrend(userId, from);

        // Map results by "YYYY-MM" key
        Map<String, Object[]> dataMap = new LinkedHashMap<>();
        for (Object[] row : rows) {
            int yr = ((Number) row[0]).intValue();
            int mo = ((Number) row[1]).intValue();
            String key = String.format("%04d-%02d", yr, mo);
            dataMap.put(key, row);
        }

        // Build all 6 months (oldest first)
        List<TrendEntryDTO> result = new ArrayList<>();
        for (int i = 5; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            String key   = String.format("%04d-%02d",
                    ym.getYear(), ym.getMonthValue());

            BigDecimal income  = BigDecimal.ZERO;
            BigDecimal expense = BigDecimal.ZERO;

            if (dataMap.containsKey(key)) {
                Object[] row = dataMap.get(key);
                income  = toBD(row[2]);
                expense = toBD(row[3]);
            }

            BigDecimal sav = income.subtract(expense);

            result.add(TrendEntryDTO.builder()
                    .month(key)
                    .monthLabel(ym.atDay(1).format(FMT_MONTH))
                    .totalIncome(income
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .totalExpense(expense
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .savings(sav
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .build());
        }

        return result;
    }

    private BigDecimal toBD(Object val) {
        if (val == null) return BigDecimal.ZERO;
        try { return new BigDecimal(val.toString()); }
        catch (Exception e) { return BigDecimal.ZERO; }
    }
}
package com.neobank.dto.insights;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ActivityTransactionDTO {
    private String referenceNumber;
    private String transactionType;
    private String amount;
    private String description;
    private String accountNumber;
    private String status;
    private String createdAt;
}

// ── AuditLogDTO.java ──
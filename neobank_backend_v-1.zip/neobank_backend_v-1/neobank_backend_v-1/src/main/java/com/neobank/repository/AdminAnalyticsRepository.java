// src/main/java/com/neobank/repository/
//   AdminAnalyticsRepository.java

package com.neobank.repository;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;
import com.neobank.entity.Transaction;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AdminAnalyticsRepository
        extends JpaRepository<Transaction, Long> {

    // ── Daily inflow/outflow volumes ──
    @Query(value = """
        SELECT
          DATE(t.created_at) AS txnDate,
          COALESCE(SUM(CASE
            WHEN t.transaction_type IN
              ('DEPOSIT','LOAN_DISBURSEMENT','REFUND')
            THEN t.amount ELSE 0 END), 0) AS inflow,
          COALESCE(SUM(CASE
            WHEN t.transaction_type IN
              ('WITHDRAWAL','TRANSFER','BILL_PAYMENT',
               'EMI_DEDUCTION','LOAN_FORECLOSURE')
            THEN t.amount ELSE 0 END), 0) AS outflow,
          COUNT(*) AS txnCount
        FROM transactions t
        WHERE t.status = 'SUCCESS'
        AND   t.created_at >= :from
        GROUP BY DATE(t.created_at)
        ORDER BY txnDate ASC
        """, nativeQuery = true)
    List<Object[]> getDailyVolumes(
            @Param("from") LocalDateTime from);

    // ── Average ticket size + totals (timeframe) ──
    @Query(value = """
        SELECT
          COALESCE(AVG(t.amount), 0) AS avgTicket,
          COALESCE(SUM(CASE
            WHEN t.transaction_type IN
              ('DEPOSIT','LOAN_DISBURSEMENT','REFUND')
            THEN t.amount ELSE 0 END), 0) AS totalInflow,
          COALESCE(SUM(CASE
            WHEN t.transaction_type IN
              ('WITHDRAWAL','TRANSFER','BILL_PAYMENT',
               'EMI_DEDUCTION','LOAN_FORECLOSURE')
            THEN t.amount ELSE 0 END), 0) AS totalOutflow,
          COUNT(*) AS txnCount
        FROM transactions t
        WHERE t.status = 'SUCCESS'
        AND   t.created_at >= :from
        """, nativeQuery = true)
    List<Object[]> getTransactionSummary(
            @Param("from") LocalDateTime from);

    // ── Loan distribution by status + type ──
    @Query(value = """
        SELECT
          l.status, l.loan_type,
          COUNT(*) AS cnt,
          COALESCE(SUM(l.principal_amount), 0) AS totalAmt
        FROM loans l
        WHERE (:from IS NULL OR l.created_at >= :from)
        GROUP BY l.status, l.loan_type
        ORDER BY l.status, l.loan_type
        """, nativeQuery = true)
    List<Object[]> getLoanDistribution(
            @Param("from") LocalDateTime from);

    // ── NPA: overdue vs total ──
    @Query(value = """
        SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status = 'OVERDUE'
                   THEN 1 ELSE 0 END) AS overdue
        FROM loans
        WHERE status IN ('APPROVED','OVERDUE','CLOSED')
        """, nativeQuery = true)
    List<Object[]> getNpaStats();
}
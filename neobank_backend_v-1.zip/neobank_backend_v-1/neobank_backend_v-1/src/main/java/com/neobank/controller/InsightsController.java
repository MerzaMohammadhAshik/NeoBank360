// src/main/java/com/neobank/controller/InsightsController.java

package com.neobank.controller;

import com.neobank.dto.ApiResponseDTO;
import com.neobank.dto.insights.FinancialInsightsDTO;
import com.neobank.service.InsightsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/insights")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class InsightsController {

    private final InsightsService insightsService;

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponseDTO <FinancialInsightsDTO>> getInsights(
            @PathVariable Long userId,
            Authentication auth) {

        return ResponseEntity.ok(ApiResponseDTO.success(
                "Insights fetched",
                insightsService.getInsights(
                        userId, auth.getName())));
    }
}
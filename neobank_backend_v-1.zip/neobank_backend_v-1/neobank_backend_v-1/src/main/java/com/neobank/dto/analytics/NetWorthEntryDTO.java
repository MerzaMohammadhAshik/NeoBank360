package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class NetWorthEntryDTO {
    private String month;
    private String monthLabel;
    private String totalBalance;
    private String outstandingPrincipal;
    private String netWorth;
}

// ── LoanPayoffDTO.java ──
package com.neobank.dto.insights;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class SystemHealthDTO {
    private String  dbStatus;        // UP / DOWN
    private String  appStatus;       // UP
    private Long    uptimeSeconds;
    private String  uptimeFormatted; // "2d 3h 45m"
    private Integer activeSessionCount;
    private String  javaVersion;
    private String  springProfile;
    private String  checkedAt;
}

// ── UserActivityDTO.java ──
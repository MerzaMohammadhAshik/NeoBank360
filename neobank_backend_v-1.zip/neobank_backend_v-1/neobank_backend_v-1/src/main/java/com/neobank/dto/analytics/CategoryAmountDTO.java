package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CategoryAmountDTO {
    private String category;
    private String amount;
    private String budgetLimit;   // null if no budget set
}

// ── SpendingAnalyticsDTO.java ──
package com.neobank.dto.insights;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PendingApprovalDTO {
    private Long   id;
    private String module;        // LOAN / CARD / APPLICATION
    private String referenceId;   // loanId / cardId / applicationId
    private String applicantName;
    private String applicantEmail;
    private String description;   // product name / card network / account type
    private String amount;        // for loans
    private String requestedAt;
    private String priority;      // NORMAL / HIGH (overdue pending)
}

// ── SystemHealthDTO.java ──
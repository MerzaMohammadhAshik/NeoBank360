package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DailyVolumeDTO {
    private String date;       // "2026-06-01"
    private String inflow;
    private String outflow;
    private Long transactionCount;
}

// ── LoanAnalyticsDTO.java ──
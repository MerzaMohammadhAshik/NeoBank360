package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class SystemLogEntryDTO {
    private Long id;
    private String endpoint;
    private String httpMethod;
    private Integer responseStatus;
    private Long executionTimeMs;
    private Long actingUserId;
    private String actingUsername;
    private String errorMessage;
    private String eventTimestamp;
}

// ── SystemLogPageDTO.java ──
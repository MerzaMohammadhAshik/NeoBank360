// src/main/java/com/neobank/entity/AuditLog.java

package com.neobank.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "audit_logs",
    indexes = {
        @Index(name = "idx_al_admin",    columnList = "admin_username"),
        @Index(name = "idx_al_resource", columnList = "target_resource_type"),
        @Index(name = "idx_al_created",  columnList = "created_at"),
    }
)
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "admin_username",
            nullable = false, length = 100)
    private String adminUsername;

    @Column(name = "admin_user_id")
    private Long adminUserId;

    @Enumerated(EnumType.STRING)
    @Column(name = "action",
            nullable = false, length = 50)
    private AuditAction action;

    @Column(name = "target_resource_type",
            nullable = false, length = 50)
    private String targetResourceType;

    @Column(name = "target_resource_id",
            length = 50)
    private String targetResourceId;

    @Column(name = "details", length = 500)
    private String details;

    @Column(name = "ip_address", length = 50)
    private String ipAddress;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    public enum AuditAction {
        USER_ACTIVATED,
        USER_DEACTIVATED,
        LOAN_APPROVED,
        LOAN_REJECTED,
        CARD_APPROVED,
        CARD_REJECTED,
        CARD_BLOCKED,
        CARD_UNBLOCKED,
        APPLICATION_APPROVED,
        APPLICATION_REJECTED,
        ACCOUNT_STATUS_CHANGED,
        FORECLOSURE_APPROVED,
        TREASURY_CREATED,
        TREASURY_TOPUP,
        TREASURY_STATUS_CHANGED,
        ADMIN_VIEW_USER_ACTIVITY
    }
}
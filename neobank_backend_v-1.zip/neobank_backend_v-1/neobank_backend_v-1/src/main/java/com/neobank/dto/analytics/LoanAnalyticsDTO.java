package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanAnalyticsDTO {
    private String timeframe;
    private List<LoanStatusCountDTO> loanDistribution;
    private Long totalLoans;
    private Long npaCount;
    private String npaRatio;
}

// ── LoanStatusCountDTO.java ──
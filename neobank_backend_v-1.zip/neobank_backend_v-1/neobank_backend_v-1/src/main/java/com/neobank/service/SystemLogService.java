// src/main/java/com/neobank/service/SystemLogService.java

package com.neobank.service;

import com.neobank.dto.analytics.*;
import com.neobank.entity.SystemAuditLog;
import com.neobank.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class SystemLogService {

    private final SystemAuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm:ss a");

    @Transactional(readOnly = true)
    public SystemLogPageDTO getSystemLogs(
            LocalDateTime from, LocalDateTime to,
            Integer status, int page, int size) {

        Page<SystemAuditLog> result =
                auditLogRepository.search(
                        from, to, status,
                        PageRequest.of(page, size));

        // Build username cache to avoid N+1
        Map<Long, String> usernameCache = new HashMap<>();

        List<SystemLogEntryDTO> content = new ArrayList<>();
        for (SystemAuditLog log : result.getContent()) {
            String username = null;
            if (log.getActingUserId() != null) {
                username = usernameCache.computeIfAbsent(
                    log.getActingUserId(), id ->
                        userRepository.findById(id)
                            .map(u -> u.getUsername())
                            .orElse("unknown"));
            }

            content.add(SystemLogEntryDTO.builder()
                    .id(log.getId())
                    .endpoint(log.getEndpoint())
                    .httpMethod(log.getHttpMethod())
                    .responseStatus(log.getResponseStatus())
                    .executionTimeMs(log.getExecutionTimeMs())
                    .actingUserId(log.getActingUserId())
                    .actingUsername(username)
                    .errorMessage(log.getErrorMessage())
                    .eventTimestamp(log.getEventTimestamp() != null
                        ? log.getEventTimestamp().format(FMT)
                        : null)
                    .build());
        }

        // Error rate by hour (last 24h)
        LocalDateTime last24h = LocalDateTime.now()
                .minusHours(24);
        List<Object[]> errorRows =
                auditLogRepository.getErrorRateByHour(last24h);

        List<ErrorRatePointDTO> errorRate = new ArrayList<>();
        for (Object[] row : errorRows) {
            long total = ((Number) row[1]).longValue();
            long errors = ((Number) row[2]).longValue();
            String rate = total > 0
                ? BigDecimal.valueOf(errors)
                    .divide(BigDecimal.valueOf(total),
                            4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(2, RoundingMode.HALF_UP)
                    .toPlainString()
                : "0.00";

            errorRate.add(ErrorRatePointDTO.builder()
                    .hour(row[0].toString())
                    .total(total)
                    .errors(errors)
                    .errorRate(rate)
                    .build());
        }

        // Response time by hour (last 24h)
        List<Object[]> rtRows =
                auditLogRepository
                        .getAvgResponseTimeByHour(last24h);

        List<ResponseTimePointDTO> responseTime =
                new ArrayList<>();
        for (Object[] row : rtRows) {
            BigDecimal avg = row[1] != null
                ? new BigDecimal(row[1].toString())
                    .setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

            responseTime.add(ResponseTimePointDTO.builder()
                    .hour(row[0].toString())
                    .avgTimeMs(avg.toPlainString())
                    .build());
        }

        return SystemLogPageDTO.builder()
                .content(content)
                .totalElements(result.getTotalElements())
                .totalPages(result.getTotalPages())
                .currentPage(page)
                .errorRateByHour(errorRate)
                .responseTimeByHour(responseTime)
                .build();
    }
}
package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanStatusCountDTO {
    private String status;
    private String loanType;
    private Long count;
    private String totalAmount;
}

// ── SystemLogEntryDTO.java ──
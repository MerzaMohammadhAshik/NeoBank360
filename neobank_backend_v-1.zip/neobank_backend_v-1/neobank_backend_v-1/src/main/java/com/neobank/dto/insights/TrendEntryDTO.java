package com.neobank.dto.insights;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class TrendEntryDTO {
    private String monthLabel;   // e.g. "Jan 2026"
    private String month;        // "2026-01"
    private String totalIncome;
    private String totalExpense;
    private String savings;
}

// ── AdminDashboardDTO.java ──
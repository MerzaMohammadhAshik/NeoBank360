
// src/main/java/com/neobank/controller/
//   AdminAnalyticsController.java

package com.neobank.controller;

import com.neobank.dto.ApiResponseDTO;
import com.neobank.dto.analytics.*;
import com.neobank.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/admin/analytics")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
public class AdminAnalyticsController {

    private final AdminAnalyticsService analyticsService;
    private final SystemLogService systemLogService;

    @GetMapping("/transactions")
    public ResponseEntity<ApiResponseDTO<
            TransactionAnalyticsDTO>> getTransactionAnalytics(
            @RequestParam(defaultValue = "7d") String timeframe) {

        return ResponseEntity.ok(ApiResponseDTO.success(
                "Transaction analytics fetched",
                analyticsService.getTransactionAnalytics(
                        timeframe)));
    }

    @GetMapping("/loans")
    public ResponseEntity<ApiResponseDTO<
            LoanAnalyticsDTO>> getLoanAnalytics(
            @RequestParam(defaultValue = "30d") String timeframe) {

        return ResponseEntity.ok(ApiResponseDTO.success(
                "Loan analytics fetched",
                analyticsService.getLoanAnalytics(timeframe)));
    }
}
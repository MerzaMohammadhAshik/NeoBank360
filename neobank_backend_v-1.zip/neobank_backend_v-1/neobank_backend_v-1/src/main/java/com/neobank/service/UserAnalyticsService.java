// src/main/java/com/neobank/service/
//   UserAnalyticsService.java

package com.neobank.service;

import com.neobank.dto.analytics.*;
import com.neobank.entity.User;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class UserAnalyticsService {

    private final UserAnalyticsRepository repository;
    private final UserRepository userRepository;
    private final LoanRepository loanRepository;
    private final LoanEmiRepository loanEmiRepository;

    private static final DateTimeFormatter FMT_FULL =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");
    private static final DateTimeFormatter FMT_MONTH =
            DateTimeFormatter.ofPattern("MMM yyyy");

    private static final List<String> DEFAULT_CATEGORIES =
            List.of("Groceries","Utilities","Rent",
                    "Entertainment","Transport","Other");

    // ─────────────────────────────────────────────
    //  SPENDING ANALYTICS
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public SpendingAnalyticsDTO getSpendingAnalytics(
            Long pathUserId, String jwtUsername, int months) {

        User user = verifyUser(pathUserId, jwtUsername);

        if (months < 1 || months > 12) months = 6;

        LocalDateTime from = LocalDate.now()
                .withDayOfMonth(1)
                .minusMonths(months - 1)
                .atStartOfDay();

        // Budget limits by category
        Map<String, BigDecimal> budgetLimits = new HashMap<>();
        for (Object[] row : repository.getBudgetLimits(
                user.getId())) {
            budgetLimits.put(row[0].toString(),
                    toBD(row[1]));
        }

        // Raw spending data: month -> category -> amount
        List<Object[]> rows = repository.getCategorySpending(
                user.getId(), from);

        Map<String, Map<String, BigDecimal>> monthMap =
                new LinkedHashMap<>();

        for (Object[] row : rows) {
            String ym = row[0].toString();
            String category = row[1] != null
                    ? row[1].toString() : "Other";
            BigDecimal amt = toBD(row[2]);

            monthMap.computeIfAbsent(ym,
                    k -> new LinkedHashMap<>())
                .merge(category, amt, BigDecimal::add);
        }

        // Build all months (zero-padded)
        List<CategorySpendingDTO> result = new ArrayList<>();
        Set<String> allCategories = new TreeSet<>();

        for (int i = months - 1; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            String key = String.format("%04d-%02d",
                    ym.getYear(), ym.getMonthValue());

            Map<String, BigDecimal> catMap =
                    monthMap.getOrDefault(key,
                            new LinkedHashMap<>());

            List<CategoryAmountDTO> categories =
                    new ArrayList<>();
            BigDecimal total = BigDecimal.ZERO;

            for (Map.Entry<String, BigDecimal> e :
                    catMap.entrySet()) {
                allCategories.add(e.getKey());
                total = total.add(e.getValue());

                BigDecimal limit =
                        budgetLimits.get(e.getKey());

                categories.add(CategoryAmountDTO.builder()
                        .category(e.getKey())
                        .amount(e.getValue()
                                .setScale(2, RoundingMode.HALF_UP)
                                .toPlainString())
                        .budgetLimit(limit != null
                            ? limit.setScale(2,
                                RoundingMode.HALF_UP)
                                .toPlainString()
                            : null)
                        .build());
            }

            result.add(CategorySpendingDTO.builder()
                    .month(key)
                    .monthLabel(ym.atDay(1).format(FMT_MONTH))
                    .categories(categories)
                    .totalSpent(total
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .build());
        }

        return SpendingAnalyticsDTO.builder()
                .monthlySpending(result)
                .categories(new ArrayList<>(allCategories))
                .generatedAt(
                    LocalDateTime.now().format(FMT_FULL))
                .build();
    }

    // ─────────────────────────────────────────────
    //  WEALTH ANALYTICS
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public WealthAnalyticsDTO getWealthAnalytics(
            Long pathUserId, String jwtUsername) {

        User user = verifyUser(pathUserId, jwtUsername);

        // ── Net Worth Timeline (last 6 months) ──
        List<NetWorthEntryDTO> timeline =
                buildNetWorthTimeline(user.getId());

        // ── Loan Payoff Forecast ──
        List<LoanPayoffDTO> payoffForecast =
                buildLoanPayoffForecast(user.getId());

        // ── Reward Accrual History ──
        List<RewardAccrualDTO> rewardHistory =
                buildRewardAccrualHistory(user.getId());

        String currentNetWorth = timeline.isEmpty()
                ? "0.00"
                : timeline.get(timeline.size() - 1)
                    .getNetWorth();

        return WealthAnalyticsDTO.builder()
                .netWorthTimeline(timeline)
                .loanPayoffForecast(payoffForecast)
                .rewardAccrualHistory(rewardHistory)
                .currentNetWorth(currentNetWorth)
                .generatedAt(
                    LocalDateTime.now().format(FMT_FULL))
                .build();
    }

    // ─────────────────────────────────────────────
    //  NET WORTH TIMELINE BUILDER
    // ─────────────────────────────────────────────

    private List<NetWorthEntryDTO> buildNetWorthTimeline(
            Long userId) {

        int monthsBack = 6;
        LocalDateTime from = LocalDate.now()
                .withDayOfMonth(1)
                .minusMonths(monthsBack - 1)
                .atStartOfDay();

        // Current totals
        BigDecimal currentBalance =
                repository.getTotalBalance(userId);
        BigDecimal currentOutstanding =
                repository.getTotalOutstandingPrincipal(userId);
        if (currentBalance == null)
            currentBalance = BigDecimal.ZERO;
        if (currentOutstanding == null)
            currentOutstanding = BigDecimal.ZERO;

        // Monthly balance changes (to walk backward)
        List<Object[]> changes =
                repository.getMonthlyBalanceChanges(
                        userId, from);

        Map<String, BigDecimal> changeMap = new HashMap<>();
        for (Object[] row : changes) {
            changeMap.put(row[0].toString(), toBD(row[1]));
        }

        // Walk backward from current month to compute
        // historical balances
        List<NetWorthEntryDTO> result = new ArrayList<>();
        BigDecimal[] runningBalance = { currentBalance };

        // Build forward then reverse for display
        List<BigDecimal> balances = new ArrayList<>();
        balances.add(currentBalance); // month 0 (current)

        for (int i = 0; i < monthsBack - 1; i++) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            String key = String.format("%04d-%02d",
                    ym.getYear(), ym.getMonthValue());
            BigDecimal change = changeMap.getOrDefault(
                    key, BigDecimal.ZERO);
            // Going backward: previous = current - thisMonthChange
            BigDecimal prev = balances.get(i)
                    .subtract(change);
            balances.add(prev);
        }

        // balances[0] = current month, balances[5] = 5 months ago
        // Reverse so oldest first
        Collections.reverse(balances);

        // For outstanding principal, we approximate as
        // constant (current value) across months since
        // historical loan principal isn't tracked.
        // This is a reasonable approximation per SRS
        // ("derived from existing schema").
        for (int i = 0; i < monthsBack; i++) {
            YearMonth ym = YearMonth.now()
                    .minusMonths(monthsBack - 1 - i);
            String key = String.format("%04d-%02d",
                    ym.getYear(), ym.getMonthValue());

            BigDecimal balance = balances.get(i)
                    .max(BigDecimal.ZERO);
            BigDecimal netWorth = balance
                    .subtract(currentOutstanding);

            result.add(NetWorthEntryDTO.builder()
                    .month(key)
                    .monthLabel(ym.atDay(1).format(FMT_MONTH))
                    .totalBalance(balance
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .outstandingPrincipal(currentOutstanding
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .netWorth(netWorth
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .build());
        }

        return result;
    }

    // ─────────────────────────────────────────────
    //  LOAN PAYOFF FORECAST BUILDER
    // ─────────────────────────────────────────────

    private List<LoanPayoffDTO> buildLoanPayoffForecast(
            Long userId) {

        List<Object[]> loans =
                repository.getActiveLoansForUser(userId);

        List<LoanPayoffDTO> result = new ArrayList<>();
        DateTimeFormatter dateFmt =
                DateTimeFormatter.ofPattern("MMM yyyy");

        for (Object[] row : loans) {
            String loanId = row[0].toString();
            String loanType = row[1].toString();
            String productName = row[2] != null
                    ? row[2].toString() : loanType;
            BigDecimal outstanding = toBD(row[3]);
            BigDecimal emiAmount = toBD(row[4]);
            int tenureMonths = row[6] != null
                    ? ((Number) row[6]).intValue() : 0;
            int emisPaid = row[7] != null
                    ? ((Number) row[7]).intValue() : 0;

            int monthsRemaining =
                    Math.max(tenureMonths - emisPaid, 0);

            String projectedPayoff = LocalDate.now()
                    .plusMonths(monthsRemaining)
                    .format(dateFmt);

            result.add(LoanPayoffDTO.builder()
                    .loanId(loanId)
                    .loanType(loanType)
                    .productName(productName)
                    .outstandingBalance(outstanding
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .emiAmount(emiAmount
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .monthsRemaining(monthsRemaining)
                    .projectedPayoffDate(projectedPayoff)
                    .build());
        }

        return result;
    }

    // ─────────────────────────────────────────────
    //  REWARD ACCRUAL HISTORY BUILDER
    // ─────────────────────────────────────────────

    private List<RewardAccrualDTO> buildRewardAccrualHistory(
            Long userId) {

        int monthsBack = 6;
        LocalDateTime from = LocalDate.now()
                .withDayOfMonth(1)
                .minusMonths(monthsBack - 1)
                .atStartOfDay();

        List<Object[]> rows =
                repository.getRewardAccrualByMonth(
                        userId, from);

        Map<String, Integer> monthMap = new HashMap<>();
        for (Object[] row : rows) {
            monthMap.put(row[0].toString(),
                    ((Number) row[1]).intValue());
        }

        Long startingPoints =
                repository.getRewardPointsBefore(
                        userId, from);
        if (startingPoints == null) startingPoints = 0L;

        List<RewardAccrualDTO> result = new ArrayList<>();
        long cumulative = startingPoints;

        for (int i = monthsBack - 1; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            String key = String.format("%04d-%02d",
                    ym.getYear(), ym.getMonthValue());

            int earned = monthMap.getOrDefault(key, 0);
            cumulative += earned;

            result.add(RewardAccrualDTO.builder()
                    .month(key)
                    .monthLabel(ym.atDay(1).format(FMT_MONTH))
                    .pointsEarned(earned)
                    .cumulativePoints((int) cumulative)
                    .build());
        }

        return result;
    }

    // ─────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────

    private User verifyUser(Long pathUserId,
            String jwtUsername) {
        User user = userRepository.findByUsername(jwtUsername)
                .orElseThrow(() -> new NeoBankException(
                        HttpStatus.NOT_FOUND,
                        "USER_NOT_FOUND", "User not found."));

        if (!user.getId().equals(pathUserId)) {
            throw new NeoBankException(HttpStatus.FORBIDDEN,
                    "ACCESS_DENIED",
                    "You can only view your own analytics.");
        }
        return user;
    }

    private BigDecimal toBD(Object val) {
        if (val == null) return BigDecimal.ZERO;
        try { return new BigDecimal(val.toString()); }
        catch (Exception e) { return BigDecimal.ZERO; }
    }
}
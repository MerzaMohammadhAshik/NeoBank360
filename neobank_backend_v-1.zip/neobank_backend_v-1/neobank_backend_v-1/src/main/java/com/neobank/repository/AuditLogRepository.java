// src/main/java/com/neobank/repository/AuditLogRepository.java

package com.neobank.repository;

import com.neobank.entity.AuditLog;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditLogRepository
        extends JpaRepository<AuditLog, Long> {

    Page<AuditLog> findAllByOrderByCreatedAtDesc(
            Pageable pageable);

    List<AuditLog> findByAdminUsernameOrderByCreatedAtDesc(
            String adminUsername);

    List<AuditLog> findByTargetResourceTypeAndTargetResourceId(
            String resourceType, String resourceId);
}
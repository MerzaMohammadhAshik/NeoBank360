// src/main/java/com/neobank/controller/
//   AdminDashboardController.java

package com.neobank.controller;

import com.neobank.dto.ApiResponseDTO;
import com.neobank.dto.insights.*;
import com.neobank.service.AdminDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AdminDashboardController {

    private final AdminDashboardService adminDashboardService;

    // ── Platform dashboard ──
    @GetMapping("/dashboard")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
    public ResponseEntity<ApiResponseDTO
            <AdminDashboardDTO>> getDashboard() {
        return ResponseEntity.ok(ApiResponseDTO.success(
                "Dashboard fetched",
                adminDashboardService.getDashboard()));
    }

    // ── Pending approvals ──
    @GetMapping("/pending-approvals")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
    public ResponseEntity<ApiResponseDTO
            <List<PendingApprovalDTO>>> getPendingApprovals(
            @RequestParam(required = false) String module) {
        return ResponseEntity.ok(ApiResponseDTO.success(
                "Pending approvals fetched",
                adminDashboardService.getPendingApprovals(
                        module)));
    }

    // ── System health ──
    @GetMapping("/system-health")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<ApiResponseDTO
            <SystemHealthDTO>> getSystemHealth() {
        return ResponseEntity.ok(ApiResponseDTO.success(
                "System health fetched",
                adminDashboardService.getSystemHealth()));
    }

    // ── User activity ──
    @GetMapping("/users/{userId}/activity")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
    public ResponseEntity<ApiResponseDTO
            <UserActivityDTO>> getUserActivity(
            @PathVariable Long userId,
            Authentication auth) {
        return ResponseEntity.ok(ApiResponseDTO.success(
                "User activity fetched",
                adminDashboardService.getUserActivity(
                        userId, auth.getName())));
    }

    // ── Update user status ──
    @PatchMapping("/users/{userId}/status")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<ApiResponseDTO<Void>> updateStatus(
            @PathVariable Long userId,
            @RequestParam  String status,
            Authentication auth) {
        adminDashboardService.updateUserStatus(
                userId, status, auth.getName());
        return ResponseEntity.ok(ApiResponseDTO.success(
                "User status updated", null));
    }
}
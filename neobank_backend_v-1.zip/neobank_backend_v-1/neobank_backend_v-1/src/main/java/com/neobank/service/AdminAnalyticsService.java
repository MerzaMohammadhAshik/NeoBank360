// src/main/java/com/neobank/service/
//   AdminAnalyticsService.java

package com.neobank.service;

import com.neobank.dto.analytics.*;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.AdminAnalyticsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AdminAnalyticsService {

    private final AdminAnalyticsRepository repository;

    private static final Set<String> VALID_TIMEFRAMES =
            Set.of("7d", "30d", "YTD");

    // ─────────────────────────────────────────────
    //  TRANSACTION ANALYTICS
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public TransactionAnalyticsDTO getTransactionAnalytics(
            String timeframe) {

        validateTimeframe(timeframe);
        LocalDateTime from = resolveFromDate(timeframe);

        // Daily volumes
        List<Object[]> dailyRows =
                repository.getDailyVolumes(from);

        List<DailyVolumeDTO> dailyVolumes = new ArrayList<>();
        for (Object[] row : dailyRows) {
            dailyVolumes.add(DailyVolumeDTO.builder()
                    .date(row[0].toString())
                    .inflow(toBD(row[1])
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .outflow(toBD(row[2])
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .transactionCount(((Number) row[3])
                            .longValue())
                    .build());
        }

        // Summary
        List<Object[]> summary =
                repository.getTransactionSummary(from);

        BigDecimal avgTicket = BigDecimal.ZERO;
        BigDecimal totalInflow = BigDecimal.ZERO;
        BigDecimal totalOutflow = BigDecimal.ZERO;
        long txnCount = 0;

        if (!summary.isEmpty()) {
            Object[] row = summary.get(0);
            avgTicket = toBD(row[0]);
            totalInflow = toBD(row[1]);
            totalOutflow = toBD(row[2]);
            txnCount = ((Number) row[3]).longValue();
        }

        return TransactionAnalyticsDTO.builder()
                .timeframe(timeframe)
                .dailyVolumes(dailyVolumes)
                .averageTicketSize(avgTicket
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .totalInflow(totalInflow
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .totalOutflow(totalOutflow
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .totalTransactionCount(txnCount)
                .build();
    }

    // ─────────────────────────────────────────────
    //  LOAN ANALYTICS
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public LoanAnalyticsDTO getLoanAnalytics(
            String timeframe) {

        validateTimeframe(timeframe);
        LocalDateTime from = resolveFromDate(timeframe);

        List<Object[]> rows =
                repository.getLoanDistribution(from);

        List<LoanStatusCountDTO> distribution =
                new ArrayList<>();
        long totalLoans = 0;

        for (Object[] row : rows) {
            long cnt = ((Number) row[2]).longValue();
            totalLoans += cnt;
            distribution.add(LoanStatusCountDTO.builder()
                    .status(row[0].toString())
                    .loanType(row[1].toString())
                    .count(cnt)
                    .totalAmount(toBD(row[3])
                            .setScale(2, RoundingMode.HALF_UP)
                            .toPlainString())
                    .build());
        }

        // NPA ratio (all-time, not timeframe-bound)
        List<Object[]> npaRows = repository.getNpaStats();
        long npaTotal = 0;
        long npaOverdue = 0;
        if (!npaRows.isEmpty()) {
            Object[] row = npaRows.get(0);
            npaTotal = row[0] != null
                    ? ((Number) row[0]).longValue() : 0;
            npaOverdue = row[1] != null
                    ? ((Number) row[1]).longValue() : 0;
        }

        String npaRatio = "0.00";
        if (npaTotal > 0) {
            npaRatio = BigDecimal.valueOf(npaOverdue)
                    .divide(BigDecimal.valueOf(npaTotal),
                            4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(2, RoundingMode.HALF_UP)
                    .toPlainString();
        }

        return LoanAnalyticsDTO.builder()
                .timeframe(timeframe)
                .loanDistribution(distribution)
                .totalLoans(totalLoans)
                .npaCount(npaOverdue)
                .npaRatio(npaRatio)
                .build();
    }

    // ─────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────

    private void validateTimeframe(String timeframe) {
        if (timeframe == null ||
            !VALID_TIMEFRAMES.contains(timeframe)) {
            throw new NeoBankException(
                    HttpStatus.BAD_REQUEST,
                    "INVALID_TIMEFRAME",
                    "Timeframe must be one of: 7d, 30d, YTD");
        }
    }

    private LocalDateTime resolveFromDate(String timeframe) {
        return switch (timeframe) {
            case "7d"  -> LocalDate.now()
                    .minusDays(6).atStartOfDay();
            case "30d" -> LocalDate.now()
                    .minusDays(29).atStartOfDay();
            case "YTD" -> LocalDate.now()
                    .withDayOfYear(1).atStartOfDay();
            default -> LocalDate.now()
                    .minusDays(6).atStartOfDay();
        };
    }

    private BigDecimal toBD(Object val) {
        if (val == null) return BigDecimal.ZERO;
        try { return new BigDecimal(val.toString()); }
        catch (Exception e) { return BigDecimal.ZERO; }
    }
}
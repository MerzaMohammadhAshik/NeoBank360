// src/main/java/com/neobank/repository/
//   UserAnalyticsRepository.java

package com.neobank.repository;

import com.neobank.entity.Transaction;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface UserAnalyticsRepository
        extends JpaRepository<Transaction, Long> {

    // ── Category spending per month (from transaction
    //    description matching budget categories) ──
    @Query(value = """
        SELECT
          DATE_FORMAT(t.created_at, '%Y-%m') AS ym,
          COALESCE(b.category, 'Other')      AS category,
          SUM(t.amount)                      AS amt
        FROM transactions t
        JOIN accounts a
          ON t.from_account_number = a.account_number
        LEFT JOIN budgets b
          ON b.user_id = a.user_id
          AND t.description LIKE CONCAT('%', b.category, '%')
        WHERE a.user_id = :userId
        AND   a.status  = 'ACTIVE'
        AND   t.status  = 'SUCCESS'
        AND   t.from_account_number IS NOT NULL
        AND   t.transaction_type NOT IN
              ('EMI_DEDUCTION','LOAN_FORECLOSURE',
               'TREASURY_TOPUP')
        AND   t.created_at >= :from
        GROUP BY ym, category
        ORDER BY ym ASC, amt DESC
        """, nativeQuery = true)
    List<Object[]> getCategorySpending(
            @Param("userId") Long userId,
            @Param("from") LocalDateTime from);

    // ── Budget limits per category for user ──
    @Query(value = """
        SELECT category, limit_amount
        FROM budgets
        WHERE user_id = :userId
        """, nativeQuery = true)
    List<Object[]> getBudgetLimits(
            @Param("userId") Long userId);

    // ── Total active account balance ──
    @Query("""
        SELECT COALESCE(SUM(a.balance), 0)
        FROM Account a
        WHERE a.user.id = :userId
        AND   a.status  = 'ACTIVE'
        """)
    java.math.BigDecimal getTotalBalance(
            @Param("userId") Long userId);

    // ── Net worth snapshot for past months
    //    (uses transactions to reconstruct historical
    //     balance via running total) ──
    @Query(value = """
        SELECT
          DATE_FORMAT(t.created_at, '%Y-%m') AS ym,
          SUM(CASE
            WHEN t.to_account_number = a.account_number
            THEN t.amount ELSE 0 END) -
          SUM(CASE
            WHEN t.from_account_number = a.account_number
            THEN t.amount ELSE 0 END) AS netChange
        FROM transactions t
        JOIN accounts a ON (
             t.to_account_number   = a.account_number
          OR t.from_account_number = a.account_number)
        WHERE a.user_id = :userId
        AND   a.status  = 'ACTIVE'
        AND   t.status  = 'SUCCESS'
        AND   t.created_at >= :from
        GROUP BY ym
        ORDER BY ym ASC
        """, nativeQuery = true)
    List<Object[]> getMonthlyBalanceChanges(
            @Param("userId") Long userId,
            @Param("from") LocalDateTime from);

    // ── Outstanding loan principal per month
    //    (approximation: current outstanding for
    //     active loans, applied retroactively) ──
    @Query(value = """
        SELECT
          l.loan_id, l.loan_type,
          COALESCE(lp.product_name, l.loan_type) AS productName,
          l.outstanding_balance, l.emi_amount,
          l.disbursement_date, l.tenure_months,
          l.emis_paid
        FROM loans l
        LEFT JOIN loan_products lp
          ON l.loan_product_id = lp.id
        WHERE l.user_id = :userId
        AND   l.status IN ('APPROVED','OVERDUE')
        """, nativeQuery = true)
    List<Object[]> getActiveLoansForUser(
            @Param("userId") Long userId);

    // ── Total outstanding principal (current) ──
    @Query("""
        SELECT COALESCE(SUM(l.outstandingBalance), 0)
        FROM Loan l
        WHERE l.user.id = :userId
        AND   l.status IN (
            com.neobank.entity.Loan$LoanStatus.APPROVED,
            com.neobank.entity.Loan$LoanStatus.OVERDUE)
        """)
    java.math.BigDecimal getTotalOutstandingPrincipal(
            @Param("userId") Long userId);

    // ── Reward points earned per month ──
    @Query(value = """
        SELECT
          DATE_FORMAT(rh.created_at, '%Y-%m') AS ym,
          SUM(rh.points) AS pts
        FROM reward_history rh
        JOIN rewards r ON rh.reward_id = r.id
        WHERE r.user_id = :userId
        AND   rh.points > 0
        AND   rh.created_at >= :from
        GROUP BY ym
        ORDER BY ym ASC
        """, nativeQuery = true)
    List<Object[]> getRewardAccrualByMonth(
            @Param("userId") Long userId,
            @Param("from") LocalDateTime from);

    // ── Total reward points so far (before window) ──
    @Query(value = """
        SELECT COALESCE(SUM(rh.points), 0)
        FROM reward_history rh
        JOIN rewards r ON rh.reward_id = r.id
        WHERE r.user_id = :userId
        AND   rh.created_at < :from
        """, nativeQuery = true)
    Long getRewardPointsBefore(
            @Param("userId") Long userId,
            @Param("from") LocalDateTime from);
}
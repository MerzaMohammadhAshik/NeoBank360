package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class SystemLogPageDTO {
    private List<SystemLogEntryDTO> content;
    private long totalElements;
    private int totalPages;
    private int currentPage;
    private List<ErrorRatePointDTO> errorRateByHour;
    private List<ResponseTimePointDTO> responseTimeByHour;
}

// ── ErrorRatePointDTO.java ──
package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class RewardAccrualDTO {
    private String month;
    private String monthLabel;
    private Integer pointsEarned;
    private Integer cumulativePoints;
}
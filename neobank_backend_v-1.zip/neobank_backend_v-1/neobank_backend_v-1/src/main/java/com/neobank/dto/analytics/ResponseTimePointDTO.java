package com.neobank.dto.analytics;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ResponseTimePointDTO {
    private String hour;
    private String avgTimeMs;
}
package com.neobank.dto.insights;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AdminDashboardDTO {
    private Long   totalUsers;
    private Long   totalActiveUsers;
    private Long   totalInactiveUsers;
    private Long   totalAccounts;
    private Long   totalActiveAccounts;
    private Long   totalTransactions;
    private Long   totalLoans;
    private Long   activeLoans;
    private Long   pendingLoans;
    private Long   totalCards;
    private Long   pendingCards;
    private Long   totalApplications;
    private Long   pendingApplications;
    private Long   totalPendingApprovals;
    private String platformTotalIncome;
    private String platformTotalExpense;
    private String platformSavingsRate;
    private String todayTransactions;
    private String generatedAt;
}

// ── PendingApprovalDTO.java ──
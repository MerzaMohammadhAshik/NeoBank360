//// src/main/java/com/neobank/controller/CardController.java
//
//package com.neobank.controller;
//
//import com.neobank.dto.ApiResponseDTO;
//import com.neobank.dto.card.*;
//import com.neobank.service.CardService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.data.domain.*;
//import org.springframework.http.*;
//import org.springframework.security.core.Authentication;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/cards")
//@RequiredArgsConstructor
//@CrossOrigin(origins = "*")
//public class CardController2 {
//
//    private final CardService cardService;
//
//    // Issue new card
//    @PostMapping("/issue")
//    public ResponseEntity<ApiResponseDTO<CardResponseDTO>> issue(
//            @RequestBody IssueCardRequestDTO req,
//            Authentication auth) {
//        return ResponseEntity.status(HttpStatus.CREATED)
//                .body(ApiResponseDTO.success("Card issued",
//                        cardService.issueCard(req, auth.getName())));
//    }
//
//    // My cards
//    @GetMapping("/my")
//    public ResponseEntity<ApiResponseDTO<List<CardResponseDTO>>> getMyCards(
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Cards fetched",
//                cardService.getMyCards(auth.getName())));
//    }
//
//    // Block card
//    @PostMapping("/{cardId}/block")
//    public ResponseEntity<ApiResponseDTO<CardResponseDTO>> block(
//            @PathVariable Long cardId,
//            @RequestParam(required = false) String reason,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Card blocked",
//                cardService.blockCard(cardId, reason, auth.getName())));
//    }
//
//    // Unblock card
//    @PostMapping("/{cardId}/unblock")
//    public ResponseEntity<ApiResponseDTO<CardResponseDTO>> unblock(
//            @PathVariable Long cardId,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Card unblocked",
//                cardService.unblockCard(cardId, auth.getName())));
//    }
//
//    // Update limits
//    @PutMapping("/{cardId}/limits")
//    public ResponseEntity<ApiResponseDTO<CardResponseDTO>> updateLimits(
//            @PathVariable Long cardId,
//            @RequestBody  UpdateLimitsRequestDTO req,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Limits updated",
//                cardService.updateLimits(cardId, req, auth.getName())));
//    }
//
//    // Send PIN setup OTP
//    @PostMapping("/{cardId}/pin/send-otp")
//    public ResponseEntity<ApiResponseDTO<Void>> sendPinOtp(
//            @PathVariable Long cardId,
//            Authentication auth) {
//        cardService.sendPinSetupOtp(cardId, auth.getName());
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "OTP sent to registered email", null));
//    }
//
//    // Set card PIN
//    @PostMapping("/pin/set")
//    public ResponseEntity<ApiResponseDTO<CardResponseDTO>> setPin(
//            @RequestBody SetCardPinRequestDTO req,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Card PIN set successfully",
//                cardService.setCardPin(req, auth.getName())));
//    }
//
//    // Request replacement
//    @PostMapping("/replacement")
//    public ResponseEntity<ApiResponseDTO<CardResponseDTO>> requestReplacement(
//            @RequestBody ReplacementRequestDTO req,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Replacement requested. New card issued.",
//                cardService.requestReplacement(req, auth.getName())));
//    }
//
//    // Card transaction history
//    @GetMapping("/{cardId}/transactions")
//    public ResponseEntity<ApiResponseDTO<Page<CardTransactionResponseDTO>>> getTransactions(
//            @PathVariable Long cardId,
//            @RequestParam(defaultValue = "0")  int page,
//            @RequestParam(defaultValue = "15") int size,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Transactions fetched",
//                cardService.getCardTransactions(
//                        cardId, auth.getName(),
//                        PageRequest.of(page, size))));
//    }
//
//    // Send OTP for card transfer
//    @PostMapping("/transfer/send-otp")
//    public ResponseEntity<ApiResponseDTO<Void>> sendTransferOtp(
//            @RequestParam String cardNumber,
//            Authentication auth) {
//        cardService.sendCardTransferOtp(cardNumber, auth.getName());
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "OTP sent", null));
//    }
//
//    // Card transfer
//    @PostMapping("/transfer")
//    public ResponseEntity<ApiResponseDTO<CardTransactionResponseDTO>> transfer(
//            @RequestBody CardTransferRequestDTO req,
//            Authentication auth) {
//        return ResponseEntity.ok(ApiResponseDTO.success(
//                "Transfer successful",
//                cardService.cardTransfer(req, auth.getName())));
//    }
//}
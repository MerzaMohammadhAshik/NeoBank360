// src/main/java/com/neobank/service/AdminDashboardService.java

package com.neobank.service;

import com.neobank.dto.insights.*;
import com.neobank.entity.*;
import com.neobank.entity.Application.ApplicationStatus;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class AdminDashboardService {

    private final UserRepository         userRepository;
    private final AccountRepository      accountRepository;
    private final TransactionRepository  transactionRepository;
    private final LoanRepository         loanRepository;
    private final DebitCardRepository    cardRepository;
    private final ApplicationRepository  applicationRepository;
    private final InsightsRepository     insightsRepository;
    private final AuditLogRepository     auditLogRepository;
    private final DataSource             dataSource;

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    // ─────────────────────────────────────────────
    //  ADMIN DASHBOARD
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public AdminDashboardDTO getDashboard() {

        // User counts
        long totalUsers       = userRepository.count();
        long activeUsers      = userRepository
                .countByStatus(User.UserStatus.ACTIVE);
        long inactiveUsers    = totalUsers - activeUsers;

        // Account counts
        long totalAccounts    = accountRepository.count();
        long activeAccounts   = accountRepository
                .countByStatus(Account.AccountStatus.ACTIVE);

        // Transaction counts
        long totalTransactions = transactionRepository.count();
        long todayTxns         =
                insightsRepository.getTodayTransactionCount();

        // Loan counts
        long totalLoans       = loanRepository.count();
        long activeLoans      = loanRepository
                .countByStatus(Loan.LoanStatus.APPROVED)
                + loanRepository.countByStatus(
                        Loan.LoanStatus.OVERDUE);
        long pendingLoans     = loanRepository
                .countByStatus(Loan.LoanStatus.PENDING);

        // Card counts
        long totalCards       = cardRepository.count();
        long pendingCards     = cardRepository
                .countByRequestStatus(
                        DebitCard.CardRequestStatus.PENDING);

        // Application counts
        long totalApps        = applicationRepository.count();
        long pendingApps      = applicationRepository
//                .countByStatus(
//                        Application.ApplicationStatus.PENDING);
                .countByStatusIn(
                        Arrays.asList(
                        		ApplicationStatus.PENDING,
                        		ApplicationStatus.SUBMITTED));
        
        // Total pending across all modules
        long totalPending = pendingLoans + pendingCards + pendingApps;

        // Platform financials
        BigDecimal platIncome  =
                insightsRepository.getPlatformTotalIncome();
        BigDecimal platExpense =
                insightsRepository.getPlatformTotalExpense();
        if (platIncome  == null) platIncome  = BigDecimal.ZERO;
        if (platExpense == null) platExpense = BigDecimal.ZERO;

        String savingsRate = "0.00%";
        if (platIncome.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal savings = platIncome.subtract(platExpense);
            BigDecimal rate    = savings
                    .divide(platIncome, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(2, RoundingMode.HALF_UP);
            savingsRate = rate.toPlainString() + "%";
        }

        return AdminDashboardDTO.builder()
                .totalUsers(totalUsers)
                .totalActiveUsers(activeUsers)
                .totalInactiveUsers(inactiveUsers)
                .totalAccounts(totalAccounts)
                .totalActiveAccounts(activeAccounts)
                .totalTransactions(totalTransactions)
                .totalLoans(totalLoans)
                .activeLoans(activeLoans)
                .pendingLoans(pendingLoans)
                .totalCards(totalCards)
                .pendingCards(pendingCards)
                .totalApplications(totalApps)
                .pendingApplications(pendingApps)
                .totalPendingApprovals(totalPending)
                .platformTotalIncome(platIncome
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .platformTotalExpense(platExpense
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .platformSavingsRate(savingsRate)
                .todayTransactions(String.valueOf(todayTxns))
                .generatedAt(LocalDateTime.now().format(FMT))
                .build();
    }

    // ─────────────────────────────────────────────
    //  PENDING APPROVALS (all modules)
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<PendingApprovalDTO> getPendingApprovals(
            String module) {

        List<PendingApprovalDTO> result = new ArrayList<>();

        // ── Pending Loans ──
        if (module == null || module.isBlank() ||
            "LOAN".equalsIgnoreCase(module)) {

            loanRepository
                .findByStatusOrderByCreatedAtDesc(
                        Loan.LoanStatus.PENDING,
                        PageRequest.of(0, 100))
                .forEach(loan -> result.add(
                    PendingApprovalDTO.builder()
                        .id(loan.getId())
                        .module("LOAN")
                        .referenceId(loan.getLoanId())
                        .applicantName(
                            loan.getUser().getFullName())
                        .applicantEmail(
                            loan.getUser().getEmail())
                        .description(
                            (loan.getLoanProduct() != null
                                ? loan.getLoanProduct()
                                      .getProductName()
                                : loan.getLoanType().name())
                            + " Loan")
                        .amount(loan.getPrincipalAmount()
                                    .toPlainString())
                        .requestedAt(loan.getCreatedAt() != null
                            ? loan.getCreatedAt().format(FMT)
                            : null)
                        .priority("NORMAL")
                        .build()
                ));
        }

        // ── Pending Cards ──
        if (module == null || module.isBlank() ||
            "CARD".equalsIgnoreCase(module)) {

            cardRepository
                .findByRequestStatusOrderByCreatedAtDesc(
                        DebitCard.CardRequestStatus.PENDING,
                        PageRequest.of(0, 100))
                .forEach(card -> result.add(
                    PendingApprovalDTO.builder()
                        .id(card.getId())
                        .module("CARD")
                        .referenceId(String.valueOf(card.getId()))
                        .applicantName(card.getCardholderName())
                        .applicantEmail(card.getUser().getEmail())
                        .description(card.getNetwork().name()
                                + " Debit Card")
                        .amount(null)
                        .requestedAt(card.getCreatedAt() != null
                            ? card.getCreatedAt().format(FMT)
                            : null)
                        .priority("NORMAL")
                        .build()
                ));
        }

        // ── Pending Applications ──
        if (module == null || module.isBlank() ||
            "APPLICATION".equalsIgnoreCase(module)) {

            applicationRepository
//                .findByStatusOrderByCreatedAtDesc(
//                        Application.ApplicationStatus.PENDING,
//                        PageRequest.of(0, 100))
                .findByStatusInOrderByCreatedAtDesc(
                        Arrays.asList(ApplicationStatus.PENDING,ApplicationStatus.SUBMITTED),
                        PageRequest.of(0, 100))
                .forEach(app -> result.add(
                    PendingApprovalDTO.builder()
                        .id(app.getId())
                        .module("APPLICATION")
                        .referenceId(app.getApplicationId())
                        .applicantName(app.getFullName())
                        .applicantEmail(app.getEmailId())
                        .description(app.getAccountType()
                                + " Account Application")
                        .amount(null)
                        .requestedAt(app.getCreatedAt() != null
                            ? app.getCreatedAt().format(FMT)
                            : null)
                        .priority("NORMAL")
                        .build()
                ));
        }

        // Sort oldest first
        result.sort(Comparator.comparing(
                PendingApprovalDTO::getRequestedAt,
                Comparator.nullsLast(
                        Comparator.naturalOrder())));

        return result;
    }

    // ─────────────────────────────────────────────
    //  SYSTEM HEALTH
    // ─────────────────────────────────────────────

    public SystemHealthDTO getSystemHealth() {

        // Check DB connectivity
        String dbStatus = "UP";
        try (Connection conn = dataSource.getConnection()) {
            conn.isValid(2);
        } catch (Exception e) {
            dbStatus = "DOWN";
            log.warn("DB health check failed: {}", e.getMessage());
        }

        // Uptime
        long uptimeMs = ManagementFactory
                .getRuntimeMXBean().getUptime();
        long uptimeSec = uptimeMs / 1000;

        long days    = TimeUnit.SECONDS.toDays(uptimeSec);
        long hours   = TimeUnit.SECONDS.toHours(uptimeSec) % 24;
        long minutes = TimeUnit.SECONDS.toMinutes(uptimeSec) % 60;

        String uptimeFmt = days + "d " + hours + "h " + minutes + "m";

        // Java version
        String javaVersion = System.getProperty("java.version");

        return SystemHealthDTO.builder()
                .dbStatus(dbStatus)
                .appStatus("UP")
                .uptimeSeconds(uptimeSec)
                .uptimeFormatted(uptimeFmt)
                .activeSessionCount(0) // JWT = stateless
                .javaVersion(javaVersion)
                .springProfile("default")
                .checkedAt(LocalDateTime.now().format(FMT))
                .build();
    }

    // ─────────────────────────────────────────────
    //  USER ACTIVITY
    // ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public UserActivityDTO getUserActivity(Long userId,
            String adminUsername) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NeoBankException(
                        HttpStatus.NOT_FOUND,
                        "USER_NOT_FOUND", "User not found."));

        // Last 20 transactions for this user
        List<ActivityTransactionDTO> txns = new ArrayList<>();

        transactionRepository
            .findByUserIdOrderByCreatedAtDesc(
                    userId, PageRequest.of(0, 20))
            .forEach(t -> txns.add(
                ActivityTransactionDTO.builder()
                    .referenceNumber(t.getReferenceNumber())
                    .transactionType(
                        t.getTransactionType().name())
                    .amount(t.getAmount().toPlainString())
                    .description(t.getDescription())
                    .accountNumber(
                        t.getFromAccountNumber() != null
                        ? t.getFromAccountNumber()
                        : t.getToAccountNumber())
                    .status(t.getStatus().name())
                    .createdAt(t.getCreatedAt() != null
                        ? t.getCreatedAt().format(FMT) : null)
                    .build()
            ));

        // Totals
        BigDecimal totalCredit =
                insightsRepository.getTotalIncome(userId);
        BigDecimal totalDebit  =
                insightsRepository.getTotalExpense(userId);
        if (totalCredit == null) totalCredit = BigDecimal.ZERO;
        if (totalDebit  == null) totalDebit  = BigDecimal.ZERO;

        // Audit log this admin action
        auditLogRepository.save(AuditLog.builder()
                .adminUsername(adminUsername)
                .action(AuditLog.AuditAction.ADMIN_VIEW_USER_ACTIVITY)
                .targetResourceType("USER")
                .targetResourceId(userId.toString())
                .details("Viewed activity for user: " +
                         user.getUsername())
                .build());

        return UserActivityDTO.builder()
                .userId(user.getId())
                .username(user.getUsername())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .status(user.getStatus().name())
                .lastLoginAt(user.getLastLoginAt() != null
                    ? user.getLastLoginAt().format(FMT) : null)
                .recentTransactions(txns)
                .totalTransactions(String.valueOf(txns.size()))
                .totalCredit(totalCredit
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .totalDebit(totalDebit
                        .setScale(2, RoundingMode.HALF_UP)
                        .toPlainString())
                .build();
    }

    // ─────────────────────────────────────────────
    //  UPDATE USER STATUS
    // ─────────────────────────────────────────────

    @Transactional
    public void updateUserStatus(
            Long userId,
            String newStatus,
            String adminUsername) {

        User admin = userRepository.findByUsername(adminUsername)
                .orElseThrow(() -> new NeoBankException(
                        HttpStatus.NOT_FOUND,
                        "ADMIN_NOT_FOUND", "Admin not found."));

        // Self-deactivation blocked
        if (admin.getId().equals(userId) &&
            "INACTIVE".equalsIgnoreCase(newStatus)) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST,
                    "SELF_DEACTIVATION",
                    "Admin cannot deactivate their own account.");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NeoBankException(
                        HttpStatus.NOT_FOUND,
                        "USER_NOT_FOUND", "User not found."));

        User.UserStatus status;
        try {
            status = User.UserStatus.valueOf(
                    newStatus.toUpperCase());
        } catch (Exception e) {
            throw new NeoBankException(HttpStatus.BAD_REQUEST,
                    "INVALID_STATUS",
                    "Status must be ACTIVE, INACTIVE, " +
                    "SUSPENDED, or LOCKED.");
        }

        user.setStatus(status);
        userRepository.save(user);

        // Audit log
        AuditLog.AuditAction action =
                status == User.UserStatus.ACTIVE
                ? AuditLog.AuditAction.USER_ACTIVATED
                : AuditLog.AuditAction.USER_DEACTIVATED;

        auditLogRepository.save(AuditLog.builder()
                .adminUsername(adminUsername)
                .adminUserId(admin.getId())
                .action(action)
                .targetResourceType("USER")
                .targetResourceId(userId.toString())
                .details("User " + user.getUsername() +
                         " status changed to " + status.name())
                .build());

        log.info("User {} status → {} by admin {}",
                user.getUsername(), status, adminUsername);
    }
}
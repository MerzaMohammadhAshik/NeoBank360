// src/main/java/com/neobank/repository/InsightsRepository.java

package com.neobank.repository;

import com.neobank.entity.Transaction;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface InsightsRepository
        extends JpaRepository<Transaction, Long> {

    // ── Total CREDIT for active accounts ──
    @Query("""
        SELECT COALESCE(SUM(t.amount), 0)
        FROM Transaction t
        WHERE (t.toAccount.user.id = :userId
               OR t.fromAccount.user.id = :userId)
        AND   t.toAccount.user.id   = :userId
        AND   t.toAccount.status    = 'ACTIVE'
        AND   t.status              = 'SUCCESS'
        AND   t.transactionType NOT IN (
                'LOAN_DISBURSEMENT','CARD_TRANSFER',
                'EMI_DEDUCTION','LOAN_FORECLOSURE')
        AND   t.amount > 0
        """)
    BigDecimal getTotalIncome(@Param("userId") Long userId);

    // ── Total DEBIT for active accounts ──
    @Query("""
        SELECT COALESCE(SUM(t.amount), 0)
        FROM Transaction t
        WHERE t.fromAccount.user.id = :userId
        AND   t.fromAccount.status  = 'ACTIVE'
        AND   t.status              = 'SUCCESS'
        AND   t.transactionType NOT IN (
                'EMI_DEDUCTION','LOAN_FORECLOSURE',
                'TREASURY_TOPUP')
        AND   t.amount > 0
        """)
    BigDecimal getTotalExpense(@Param("userId") Long userId);

    // ── Monthly trend — last 6 months ──
    @Query(value = """
        SELECT
          YEAR(t.created_at)   AS yr,
          MONTH(t.created_at)  AS mo,
          COALESCE(SUM(CASE
            WHEN t.to_account_number = a.account_number
            THEN t.amount ELSE 0 END), 0) AS income,
          COALESCE(SUM(CASE
            WHEN t.from_account_number = a.account_number
            THEN t.amount ELSE 0 END), 0) AS expense
        FROM transactions t
        JOIN accounts a ON (
             t.to_account_number   = a.account_number
          OR t.from_account_number = a.account_number)
        WHERE a.user_id   = :userId
        AND   a.status    = 'ACTIVE'
        AND   t.status    = 'SUCCESS'
        AND   t.created_at >= :from
        GROUP BY YEAR(t.created_at),
                 MONTH(t.created_at)
        ORDER BY yr DESC, mo DESC
        """,
        nativeQuery = true)
    List<Object[]> getMonthlyTrend(
            @Param("userId") Long userId,
            @Param("from")   LocalDateTime from);

    // ── Platform totals for admin ──
    @Query("""
        SELECT COALESCE(SUM(t.amount), 0)
        FROM Transaction t
        WHERE t.toAccount.status = 'ACTIVE'
        AND   t.status           = 'SUCCESS'
        AND   t.transactionType NOT IN (
                'LOAN_DISBURSEMENT','EMI_DEDUCTION',
                'LOAN_FORECLOSURE','TREASURY_TOPUP')
        """)
    BigDecimal getPlatformTotalIncome();

    @Query("""
        SELECT COALESCE(SUM(t.amount), 0)
        FROM Transaction t
        WHERE t.fromAccount.status = 'ACTIVE'
        AND   t.status             = 'SUCCESS'
        AND   t.transactionType NOT IN (
                'EMI_DEDUCTION','LOAN_FORECLOSURE',
                'TREASURY_TOPUP')
        """)
    BigDecimal getPlatformTotalExpense();

    // ── Today transaction count ──
    @Query(value = """
        SELECT COUNT(*) FROM transactions
        WHERE DATE(created_at) = CURDATE()
        AND   status = 'SUCCESS'
        """,
        nativeQuery = true)
    Long getTodayTransactionCount();
}
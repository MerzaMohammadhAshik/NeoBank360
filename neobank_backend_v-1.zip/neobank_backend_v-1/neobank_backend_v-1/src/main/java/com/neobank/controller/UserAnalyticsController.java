// src/main/java/com/neobank/controller/
//   UserAnalyticsController.java

package com.neobank.controller;

import com.neobank.dto.ApiResponseDTO;
import com.neobank.dto.analytics.*;
import com.neobank.service.UserAnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserAnalyticsController {

    private final UserAnalyticsService analyticsService;

    @GetMapping("/spending/{userId}")
    public ResponseEntity<ApiResponseDTO<
            SpendingAnalyticsDTO>> getSpendingAnalytics(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "6") int months,
            Authentication auth) {

        return ResponseEntity.ok(ApiResponseDTO.success(
                "Spending analytics fetched",
                analyticsService.getSpendingAnalytics(
                        userId, auth.getName(), months)));
    }

    @GetMapping("/wealth/{userId}")
    public ResponseEntity<ApiResponseDTO<
            WealthAnalyticsDTO>> getWealthAnalytics(
            @PathVariable Long userId,
            Authentication auth) {

        return ResponseEntity.ok(ApiResponseDTO.success(
                "Wealth analytics fetched",
                analyticsService.getWealthAnalytics(
                        userId, auth.getName())));
    }
}
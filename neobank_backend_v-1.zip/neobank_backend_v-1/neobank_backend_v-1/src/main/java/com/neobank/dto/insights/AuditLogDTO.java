package com.neobank.dto.insights;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLogDTO {
    private Long   id;
    private String adminUsername;
    private String action;
    private String targetResourceType;
    private String targetResourceId;
    private String details;
    private String createdAt;
}
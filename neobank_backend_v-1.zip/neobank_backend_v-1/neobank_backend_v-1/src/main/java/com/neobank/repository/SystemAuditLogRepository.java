
// src/main/java/com/neobank/repository/
//   SystemAuditLogRepository.java

package com.neobank.repository;

import com.neobank.entity.SystemAuditLog;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SystemAuditLogRepository
        extends JpaRepository<SystemAuditLog, Long> {

    @Query("""
        SELECT a FROM SystemAuditLog a
        WHERE (:from IS NULL OR a.eventTimestamp >= :from)
        AND   (:to   IS NULL OR a.eventTimestamp <= :to)
        AND   (:status IS NULL OR a.responseStatus = :status)
        ORDER BY a.eventTimestamp DESC
        """)
    Page<SystemAuditLog> search(
            @Param("from") LocalDateTime from,
            @Param("to") LocalDateTime to,
            @Param("status") Integer status,
            Pageable pageable);

    // ── Error rate (per hour, last 24h) ──
    @Query(value = """
        SELECT
          DATE_FORMAT(event_timestamp, '%Y-%m-%d %H:00') AS hr,
          COUNT(*) AS total,
          SUM(CASE WHEN response_status >= 400
                   THEN 1 ELSE 0 END) AS errors
        FROM system_audit_log
        WHERE event_timestamp >= :from
        GROUP BY hr
        ORDER BY hr ASC
        """, nativeQuery = true)
    List<Object[]> getErrorRateByHour(
            @Param("from") LocalDateTime from);

    // ── Avg response time per hour (last 24h) ──
    @Query(value = """
        SELECT
          DATE_FORMAT(event_timestamp, '%Y-%m-%d %H:00') AS hr,
          AVG(execution_time_ms) AS avgTime
        FROM system_audit_log
        WHERE event_timestamp >= :from
        GROUP BY hr
        ORDER BY hr ASC
        """, nativeQuery = true)
    List<Object[]> getAvgResponseTimeByHour(
            @Param("from") LocalDateTime from);
}
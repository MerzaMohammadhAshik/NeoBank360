// src/main/java/com/neobank/aspect/AuditLogAspect.java

package com.neobank.aop;

import com.neobank.entity.SystemAuditLog;
import com.neobank.repository.SystemAuditLogRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.
        SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.
        RequestContextHolder;
import org.springframework.web.context.request.
        ServletRequestAttributes;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AuditLogAspect {

    private final SystemAuditLogRepository auditLogRepository;
    private final UserLookupHelper userLookupHelper;

    @Around("execution(* com.neobank.controller..*(..))")
    public Object logApiCall(ProceedingJoinPoint pjp)
            throws Throwable {

        long start = System.currentTimeMillis();

        String endpoint = "UNKNOWN";
        String method   = "UNKNOWN";

        try {
            ServletRequestAttributes attrs =
                (ServletRequestAttributes)
                    RequestContextHolder
                        .getRequestAttributes();
            if (attrs != null) {
                HttpServletRequest req =
                        attrs.getRequest();
                endpoint = req.getRequestURI();
                method   = req.getMethod();
            }
        } catch (Exception ignored) {}

        int status = 200;
        String errorMessage = null;

        try {
            Object result = pjp.proceed();

            if (result instanceof ResponseEntity<?> re) {
                status = re.getStatusCode().value();
            }
            return result;

        } catch (Throwable ex) {
            // Determine status code from exception
            status = resolveStatusFromException(ex);
            errorMessage = sanitize(ex.getMessage());
            throw ex;

        } finally {
            long duration =
                System.currentTimeMillis() - start;

            Long userId = userLookupHelper
                    .getCurrentUserId();

            persistAsync(endpoint, method, status,
                    duration, userId, errorMessage);
        }
    }

    private int resolveStatusFromException(Throwable ex) {
        try {
            // NeoBankException has getHttpStatus()
            var method = ex.getClass()
                    .getMethod("getHttpStatus");
            Object val = method.invoke(ex);
            if (val instanceof org.springframework
                    .http.HttpStatus hs) {
                return hs.value();
            }
        } catch (Exception ignored) {}
        return 500;
    }

    /**
     * Removes sensitive data (passwords, JWTs, tokens)
     * from error messages before persisting.
     */
    private String sanitize(String message) {
        if (message == null) return null;

        String sanitized = message;

        // Remove anything that looks like a JWT
        sanitized = sanitized.replaceAll(
            "Bearer\\s+[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+",
            "Bearer [REDACTED]");
        sanitized = sanitized.replaceAll(
            "[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+",
            "[JWT_REDACTED]");

        // Remove password-like fields
        sanitized = sanitized.replaceAll(
            "(?i)(password|pwd|secret)\\s*[:=]\\s*\\S+",
            "$1=[REDACTED]");

        // Truncate to fit column
        if (sanitized.length() > 1000) {
            sanitized = sanitized.substring(0, 1000);
        }

        return sanitized;
    }

    @Async
    public void persistAsync(String endpoint, String method,
            int status, long durationMs, Long userId,
            String errorMessage) {
        try {
            SystemAuditLog log = SystemAuditLog.builder()
                    .endpoint(endpoint)
                    .httpMethod(method)
                    .responseStatus(status)
                    .executionTimeMs(durationMs)
                    .actingUserId(userId)
                    .errorMessage(
                        status >= 400 ? errorMessage : null)
                    .build();

            auditLogRepository.save(log);
        } catch (Exception e) {
            log.warn("Failed to write audit log: {}",
                    e.getMessage());
        }
    }
}
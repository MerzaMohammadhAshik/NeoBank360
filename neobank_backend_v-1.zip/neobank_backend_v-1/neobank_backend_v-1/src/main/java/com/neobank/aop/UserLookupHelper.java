// src/main/java/com/neobank/aspect/UserLookupHelper.java

package com.neobank.aop;

import com.neobank.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.
        SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserLookupHelper {

    private final UserRepository userRepository;

    public Long getCurrentUserId() {
        try {
            Authentication auth = SecurityContextHolder
                    .getContext().getAuthentication();

            if (auth == null || !auth.isAuthenticated()
                || "anonymousUser".equals(auth.getPrincipal())) {
                return null;
            }

            return userRepository
                    .findByUsername(auth.getName())
                    .map(u -> u.getId())
                    .orElse(null);

        } catch (Exception e) {
            return null;
        }
    }
}
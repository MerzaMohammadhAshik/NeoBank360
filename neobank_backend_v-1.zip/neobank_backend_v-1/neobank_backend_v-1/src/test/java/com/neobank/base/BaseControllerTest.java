//// src/test/java/com/neobank/base/BaseControllerTest.java
//
//package com.neobank.base;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.neobank.config.JwtAuthenticationFilter;
//import com.neobank.config.JwtUtil;
//
////import com.neobank.security.JwtAuthFilter;
////import com.neobank.security.JwtUtil;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.web.servlet.MockMvc;
//
//public abstract class BaseControllerTest {
//
//    @Autowired
//    protected MockMvc mockMvc;
//
//    @Autowired
//    protected ObjectMapper objectMapper;
//
//    // Mock security so tests don't need real JWT
//    @MockBean
//    protected JwtUtil jwtUtil;
//
//    @MockBean
//    protected JwtAuthenticationFilter jwtAuthFilter;
//
//    // Helper: convert object to JSON string
//    protected String toJson(Object obj) throws Exception {
//        return objectMapper.writeValueAsString(obj);
//    }
//}
//// src/test/java/com/neobank/controller/LoanControllerTest.java
//
//package com.neobank.controller;
//
//import com.neobank.base.BaseControllerTest;
//import com.neobank.dto.ApiResponseDTO;
//import com.neobank.dto.loan.*;
//import com.neobank.exception.NeoBankException;
//import com.neobank.service.LoanService;
//import org.junit.jupiter.api.*;
//import org.springframework.boot.test.autoconfigure.web.servlet.*;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.data.domain.*;
//import org.springframework.http.*;
//import org.springframework.mock.web.MockMultipartFile;
//import org.springframework.security.test.context.support.WithMockUser;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//
//import java.util.List;
//
//import static org.hamcrest.Matchers.*;
//import static org.mockito.ArgumentMatchers.*;
//import static org.mockito.Mockito.*;
//import static org.springframework.security.test.web.servlet
//        .request.SecurityMockMvcRequestPostProcessors.csrf;
//import static org.springframework.test.web.servlet.request
//        .MockMvcRequestBuilders.*;
//import static org.springframework.test.web.servlet.result
//        .MockMvcResultMatchers.*;
//
//@WebMvcTest(LoanController.class)
//@DisplayName("LoanController Tests")
//class LoanControllerTest extends BaseControllerTest {
//
//    @MockBean
//    private LoanService loanService;
//
//    // ─────────────────────────────────────────────
//    //  TEST DATA BUILDERS
//    // ─────────────────────────────────────────────
//
//    private LoanResponseDTO buildLoanResponse(
//            String loanId,
//            String status) {
//        return LoanResponseDTO.builder()
//                .id(1L)
//                .loanId(loanId)
//                .loanType("PERSONAL")
//                .status(status)
//                .principalAmount("250000.00")
//                .tenureMonths(36)
//                .interestRate("13.50")
//                .emiAmount("8438.00")
//                .outstandingBalance("250000.00")
//                .totalInterest("53768.00")
//                .totalPayable("303768.00")
//                .emisPaid(0)
//                .emisOverdue(0)
//                .totalEmis(36)
//                .foreclosureRequested(false)
//                .accountNumber("NB20260000000001")
//                .purpose("Home renovation")
//                .createdAt("01 Jun 2026, 10:00 AM")
//                .build();
//    }
//
//    private LoanEmiResponseDTO buildEmiResponse(
//            int emiNumber,
//            String status) {
//        return LoanEmiResponseDTO.builder()
//                .id((long) emiNumber)
//                .emiNumber(emiNumber)
//                .dueDate("01 Jul 2026")
//                .emiAmount("8438.00")
//                .principalComponent("5563.00")
//                .interestComponent("2875.00")
//                .outstandingAfter("244437.00")
//                .status(status)
//                .build();
//    }
//
//    private EmiCalculatorResponseDTO buildCalcResponse() {
//        return EmiCalculatorResponseDTO.builder()
//                .principal("250000")
//                .annualRate("13.5")
//                .tenureMonths(36)
//                .emiAmount("8438.00")
//                .totalInterest("53768.00")
//                .totalPayable("303768.00")
//                .build();
//    }
//
//    // ─────────────────────────────────────────────
//    //  EMI CALCULATOR (public endpoint)
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/calculate-emi")
//    class EmiCalculatorTests {
//
//        @Test
//        @DisplayName("Should return EMI for valid input")
//        void calculateEmi_validInput_returnsEmi()
//                throws Exception {
//
//            EmiCalculatorRequestDTO req =
//                    new EmiCalculatorRequestDTO(
//                            "250000", "13.5", 36);
//
//            when(loanService.calculateEmi(any()))
//                    .thenReturn(buildCalcResponse());
//
//            mockMvc.perform(post("/api/loans/calculate-emi")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req)))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data.emiAmount")
//                        .value("8438.00"))
//                .andExpect(jsonPath("$.data.totalInterest")
//                        .value("53768.00"))
//                .andExpect(jsonPath("$.data.totalPayable")
//                        .value("303768.00"));
//
//            verify(loanService, times(1)).calculateEmi(any());
//        }
//
//        @Test
//        @DisplayName("Should return 400 for negative principal")
//        void calculateEmi_negativePrincipal_returns400()
//                throws Exception {
//
//            EmiCalculatorRequestDTO req =
//                    new EmiCalculatorRequestDTO(
//                            "-1000", "13.5", 36);
//
//            when(loanService.calculateEmi(any()))
//                    .thenThrow(new NeoBankException(
//                            HttpStatus.BAD_REQUEST,
//                            "INVALID_AMOUNT",
//                            "Principal must be > 0."));
//
//            mockMvc.perform(post("/api/loans/calculate-emi")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req)))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.success").value(false))
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_AMOUNT"));
//        }
//
//        @Test
//        @DisplayName("Should return 400 for zero interest rate")
//        void calculateEmi_zeroRate_returns400()
//                throws Exception {
//
//            EmiCalculatorRequestDTO req =
//                    new EmiCalculatorRequestDTO(
//                            "250000", "0", 36);
//
//            when(loanService.calculateEmi(any()))
//                    .thenThrow(new NeoBankException(
//                            HttpStatus.BAD_REQUEST,
//                            "INVALID_RATE",
//                            "Interest rate must be > 0."));
//
//            mockMvc.perform(post("/api/loans/calculate-emi")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req)))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_RATE"));
//        }
//
//        @Test
//        @DisplayName("Should return 400 for tenure > 360")
//        void calculateEmi_tenureTooLong_returns400()
//                throws Exception {
//
//            EmiCalculatorRequestDTO req =
//                    new EmiCalculatorRequestDTO(
//                            "250000", "13.5", 361);
//
//            when(loanService.calculateEmi(any()))
//                    .thenThrow(new NeoBankException(
//                            HttpStatus.BAD_REQUEST,
//                            "INVALID_TENURE",
//                            "Tenure must be 1–360 months."));
//
//            mockMvc.perform(post("/api/loans/calculate-emi")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req)))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_TENURE"));
//        }
//
//        @Test
//        @DisplayName("EMI calculator is public — no auth needed")
//        void calculateEmi_noAuth_returnsOk()
//                throws Exception {
//
//            when(loanService.calculateEmi(any()))
//                    .thenReturn(buildCalcResponse());
//
//            // No @WithMockUser — should still work
//            mockMvc.perform(post("/api/loans/calculate-emi")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(new EmiCalculatorRequestDTO(
//                            "100000", "10", 12))))
//                .andExpect(status().isOk());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  APPLY FOR LOAN
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/apply")
//    class ApplyLoanTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should submit loan application")
//        void applyLoan_validRequest_returns201()
//                throws Exception {
//
//            MockMultipartFile dataPart =
//                    new MockMultipartFile(
//                        "data",
//                        "",
//                        "application/json",
//                        toJson(new LoanApplicationRequestDTO(
//                            1L, null,
//                            "NB20260000000001",
//                            "250000", 36,
//                            "Home renovation"))
//                        .getBytes());
//
//            MockMultipartFile incomePart =
//                    new MockMultipartFile(
//                        "incomeProof",
//                        "salary.pdf",
//                        "application/pdf",
//                        "salary data".getBytes());
//
//            when(loanService.applyLoan(
//                    any(), any(), any(),
//                    any(), any(), any(),
//                    eq("customer1")))
//                .thenReturn(buildLoanResponse(
//                        "LN20260000001", "PENDING"));
//
//            mockMvc.perform(
//                    MockMvcRequestBuilders
//                        .multipart("/api/loans/apply")
//                        .file(dataPart)
//                        .file(incomePart)
//                        .with(csrf()))
//                .andExpect(status().isCreated())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data.loanId")
//                        .value("LN20260000001"))
//                .andExpect(jsonPath("$.data.status")
//                        .value("PENDING"));
//
//            verify(loanService, times(1))
//                    .applyLoan(any(), any(), any(),
//                               any(), any(), any(),
//                               eq("customer1"));
//        }
//
//        @Test
//        @DisplayName("Should return 401 for unauthenticated user")
//        void applyLoan_noAuth_returns401()
//                throws Exception {
//
//            mockMvc.perform(
//                    MockMvcRequestBuilders
//                        .multipart("/api/loans/apply")
//                        .file(new MockMultipartFile(
//                            "data", "", "application/json",
//                            "{}".getBytes())))
//                .andExpect(status().isUnauthorized());
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 409 when pending loan exists")
//        void applyLoan_pendingLoanExists_returns409()
//                throws Exception {
//
//            MockMultipartFile dataPart =
//                    new MockMultipartFile(
//                        "data", "",
//                        "application/json",
//                        toJson(new LoanApplicationRequestDTO(
//                            1L, null,
//                            "NB20260000000001",
//                            "250000", 36, "Test"))
//                        .getBytes());
//
//            MockMultipartFile incomePart =
//                    new MockMultipartFile(
//                        "incomeProof",
//                        "income.pdf",
//                        "application/pdf",
//                        "data".getBytes());
//
//            when(loanService.applyLoan(
//                    any(), any(), any(),
//                    any(), any(), any(), any()))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.CONFLICT,
//                        "PENDING_LOAN",
//                        "You already have a loan " +
//                        "application under review."));
//
//            mockMvc.perform(
//                    MockMvcRequestBuilders
//                        .multipart("/api/loans/apply")
//                        .file(dataPart)
//                        .file(incomePart)
//                        .with(csrf()))
//                .andExpect(status().isConflict())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("PENDING_LOAN"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 400 when amount out of range")
//        void applyLoan_amountOutOfRange_returns400()
//                throws Exception {
//
//            MockMultipartFile dataPart =
//                    new MockMultipartFile(
//                        "data", "",
//                        "application/json",
//                        toJson(new LoanApplicationRequestDTO(
//                            1L, null,
//                            "NB20260000000001",
//                            "999999999", 36, "Test"))
//                        .getBytes());
//
//            MockMultipartFile incomePart =
//                    new MockMultipartFile(
//                        "incomeProof",
//                        "income.pdf",
//                        "application/pdf",
//                        "data".getBytes());
//
//            when(loanService.applyLoan(
//                    any(), any(), any(),
//                    any(), any(), any(), any()))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "AMOUNT_OUT_OF_RANGE",
//                        "Amount must be between " +
//                        "₹10,000 and ₹50,00,000 " +
//                        "for this product."));
//
//            mockMvc.perform(
//                    MockMvcRequestBuilders
//                        .multipart("/api/loans/apply")
//                        .file(dataPart)
//                        .file(incomePart)
//                        .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("AMOUNT_OUT_OF_RANGE"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 400 when tenure not allowed")
//        void applyLoan_tenureNotAllowed_returns400()
//                throws Exception {
//
//            MockMultipartFile dataPart =
//                    new MockMultipartFile(
//                        "data", "",
//                        "application/json",
//                        toJson(new LoanApplicationRequestDTO(
//                            1L, null,
//                            "NB20260000000001",
//                            "250000", 13, "Test"))
//                        .getBytes());
//
//            MockMultipartFile incomePart =
//                    new MockMultipartFile(
//                        "incomeProof",
//                        "income.pdf",
//                        "application/pdf",
//                        "data".getBytes());
//
//            when(loanService.applyLoan(
//                    any(), any(), any(),
//                    any(), any(), any(), any()))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "TENURE_NOT_ALLOWED",
//                        "Tenure 13 months is not allowed."));
//
//            mockMvc.perform(
//                    MockMvcRequestBuilders
//                        .multipart("/api/loans/apply")
//                        .file(dataPart)
//                        .file(incomePart)
//                        .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("TENURE_NOT_ALLOWED"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 400 when income proof missing")
//        void applyLoan_missingIncomeProof_returns400()
//                throws Exception {
//
//            MockMultipartFile dataPart =
//                    new MockMultipartFile(
//                        "data", "",
//                        "application/json",
//                        toJson(new LoanApplicationRequestDTO(
//                            1L, null,
//                            "NB20260000000001",
//                            "250000", 36, "Test"))
//                        .getBytes());
//
//            when(loanService.applyLoan(
//                    any(), any(), any(),
//                    any(), any(), any(), any()))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "MISSING_DOC",
//                        "Income proof document is required."));
//
//            mockMvc.perform(
//                    MockMvcRequestBuilders
//                        .multipart("/api/loans/apply")
//                        .file(dataPart)
//                        .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("MISSING_DOC"));
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  MY LOANS
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("GET /api/loans/my")
//    class GetMyLoansTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return customer's loan list")
//        void getMyLoans_authenticated_returnsList()
//                throws Exception {
//
//            List<LoanResponseDTO> loans = List.of(
//                buildLoanResponse("LN20260000001", "APPROVED"),
//                buildLoanResponse("LN20260000002", "PENDING")
//            );
//
//            when(loanService.getMyLoans("customer1"))
//                    .thenReturn(loans);
//
//            mockMvc.perform(get("/api/loans/my"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data", hasSize(2)))
//                .andExpect(jsonPath("$.data[0].loanId")
//                        .value("LN20260000001"))
//                .andExpect(jsonPath("$.data[0].status")
//                        .value("APPROVED"))
//                .andExpect(jsonPath("$.data[1].status")
//                        .value("PENDING"));
//
//            verify(loanService, times(1))
//                    .getMyLoans("customer1");
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return empty list when no loans")
//        void getMyLoans_noLoans_returnsEmptyList()
//                throws Exception {
//
//            when(loanService.getMyLoans("customer1"))
//                    .thenReturn(List.of());
//
//            mockMvc.perform(get("/api/loans/my"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data", hasSize(0)));
//        }
//
//        @Test
//        @DisplayName("Should return 401 for unauthenticated user")
//        void getMyLoans_noAuth_returns401()
//                throws Exception {
//
//            mockMvc.perform(get("/api/loans/my"))
//                .andExpect(status().isUnauthorized());
//
//            verify(loanService, never()).getMyLoans(any());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  EMI SCHEDULE
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("GET /api/loans/{loanId}/emi-schedule")
//    class EmiScheduleTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return full EMI schedule")
//        void getEmiSchedule_validLoan_returnsSchedule()
//                throws Exception {
//
//            List<LoanEmiResponseDTO> schedule = List.of(
//                buildEmiResponse(1, "PAID"),
//                buildEmiResponse(2, "PENDING"),
//                buildEmiResponse(3, "PENDING")
//            );
//
//            when(loanService.getEmiSchedule(
//                    "LN20260000001", "customer1"))
//                .thenReturn(schedule);
//
//            mockMvc.perform(get(
//                    "/api/loans/LN20260000001/emi-schedule"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data", hasSize(3)))
//                .andExpect(jsonPath("$.data[0].emiNumber")
//                        .value(1))
//                .andExpect(jsonPath("$.data[0].status")
//                        .value("PAID"))
//                .andExpect(jsonPath("$.data[1].status")
//                        .value("PENDING"));
//
//            verify(loanService, times(1))
//                    .getEmiSchedule(
//                            "LN20260000001", "customer1");
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 403 for other user's loan")
//        void getEmiSchedule_otherUserLoan_returns403()
//                throws Exception {
//
//            when(loanService.getEmiSchedule(
//                    "LN20260000099", "customer1"))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.FORBIDDEN,
//                        "ACCESS_DENIED",
//                        "Access denied to this loan."));
//
//            mockMvc.perform(get(
//                    "/api/loans/LN20260000099/emi-schedule"))
//                .andExpect(status().isForbidden())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("ACCESS_DENIED"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 404 for non-existent loan")
//        void getEmiSchedule_loanNotFound_returns404()
//                throws Exception {
//
//            when(loanService.getEmiSchedule(
//                    "LN99999999999", "customer1"))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.NOT_FOUND,
//                        "LOAN_NOT_FOUND",
//                        "Loan not found: LN99999999999"));
//
//            mockMvc.perform(get(
//                    "/api/loans/LN99999999999/emi-schedule"))
//                .andExpect(status().isNotFound())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("LOAN_NOT_FOUND"));
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  FORECLOSURE REQUEST
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/{loanId}/foreclosure")
//    class ForeclosureRequestTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should submit foreclosure request")
//        void requestForeclosure_activeLoan_returnsOk()
//                throws Exception {
//
//            LoanResponseDTO updated =
//                    buildLoanResponse("LN20260000001",
//                            "APPROVED");
//            updated.setForeclosureRequested(true);
//            updated.setForeclosureAmount("225000.00");
//
//            when(loanService.requestForeclosure(
//                    "LN20260000001", "customer1"))
//                .thenReturn(updated);
//
//            mockMvc.perform(post(
//                    "/api/loans/LN20260000001/foreclosure")
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath(
//                        "$.data.foreclosureRequested")
//                        .value(true))
//                .andExpect(jsonPath("$.data.foreclosureAmount")
//                        .value("225000.00"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 409 if already requested")
//        void requestForeclosure_alreadyRequested_returns409()
//                throws Exception {
//
//            when(loanService.requestForeclosure(
//                    "LN20260000001", "customer1"))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.CONFLICT,
//                        "ALREADY_REQUESTED",
//                        "Foreclosure already requested."));
//
//            mockMvc.perform(post(
//                    "/api/loans/LN20260000001/foreclosure")
//                    .with(csrf()))
//                .andExpect(status().isConflict())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("ALREADY_REQUESTED"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 400 for closed loan")
//        void requestForeclosure_closedLoan_returns400()
//                throws Exception {
//
//            when(loanService.requestForeclosure(
//                    "LN20260000001", "customer1"))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_STATUS",
//                        "Foreclosure can only be requested " +
//                        "for active loans."));
//
//            mockMvc.perform(post(
//                    "/api/loans/LN20260000001/foreclosure")
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_STATUS"));
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  MANUAL EMI PAYMENT
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("PATCH /api/loans/{loanId}/repayments/{emiId}/pay")
//    class ManualEmiPayTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should manually pay a PENDING EMI")
//        void manualPayEmi_pendingEmi_returnsOk()
//                throws Exception {
//
//            LoanEmiResponseDTO paid = buildEmiResponse(2, "PAID");
//
//            when(loanService.manualPayEmi(
//                    eq("LN20260000001"), eq(2L),
//                    any(), eq("customer1"), eq(false)))
//                .thenReturn(paid);
//
//            mockMvc.perform(patch(
//                    "/api/loans/LN20260000001/repayments/2/pay")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content("{}")
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data.status")
//                        .value("PAID"))
//                .andExpect(jsonPath("$.data.emiNumber")
//                        .value(2));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 400 for already paid EMI")
//        void manualPayEmi_alreadyPaid_returns400()
//                throws Exception {
//
//            when(loanService.manualPayEmi(
//                    eq("LN20260000001"), eq(1L),
//                    any(), eq("customer1"), eq(false)))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "ALREADY_PAID",
//                        "This EMI is already paid."));
//
//            mockMvc.perform(patch(
//                    "/api/loans/LN20260000001/repayments/1/pay")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content("{}")
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("ALREADY_PAID"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 400 for insufficient balance")
//        void manualPayEmi_insufficientBalance_returns400()
//                throws Exception {
//
//            when(loanService.manualPayEmi(
//                    eq("LN20260000001"), eq(2L),
//                    any(), eq("customer1"), eq(false)))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INSUFFICIENT_BALANCE",
//                        "Insufficient balance for EMI."));
//
//            mockMvc.perform(patch(
//                    "/api/loans/LN20260000001/repayments/2/pay")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content("{}")
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INSUFFICIENT_BALANCE"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can pay EMI for any loan")
//        void adminManualPayEmi_validEmi_returnsOk()
//                throws Exception {
//
//            LoanEmiResponseDTO paid = buildEmiResponse(3, "PAID");
//
//            when(loanService.manualPayEmi(
//                    eq("LN20260000001"), eq(3L),
//                    any(), eq("admin"), eq(true)))
//                .thenReturn(paid);
//
//            mockMvc.perform(patch(
//                    "/api/loans/admin/LN20260000001" +
//                    "/repayments/3/pay")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content("{\"note\":\"Manual correction\"}")
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data.status")
//                        .value("PAID"));
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  ADMIN: GET ALL LOANS
//    // ─────────────────────────────────────────────
//
////    @Nested
////    @DisplayName("GET /api/loans/admin/all")
////    class AdminGetAllLoansTests {
////
////        @Test
////        @WithMockUser(username = "admin",
////                      roles = "ADMIN")
////        @DisplayName("Admin can get all loans")
////        void getAllLoans_adminRole_returnsPagedList()
////                throws Exception {
////
////            Page<LoanResponseDTO> page = new PageImpl<>(List.of(
////                buildLoanResponse("LN20260000001", "APPROVED"),
////                buildLoanResponse("LN20260000002", "PENDING"),
////                buildLoanResponse("LN20260000003", "REJECTED")
////            ));
////
////            when(loanService.getAllLoans(
////                    anyString(), any(Pageable.class)))
////                .thenReturn(page);
////
////            mockMvc.perform(
////                    get("/api/loans/admin/all")
////                    .param("page", "0")
////                    .param("size", "15"))
////                .andExpect(status().isOk())
////                .andExpect(jsonPath("$.success").value(true))
////                .andExpect(jsonPath("$.data.content",
////                        hasSize(3)))
////                .andExpect(jsonPath(
////                        "$.data.content[0].status")
////                        .value("APPROVED"));
////        }
////
////        @Test
////        @WithMockUser(username = "admin",
////                      roles = "ADMIN")
////        @DisplayName("Admin can filter loans by status")
////        void getAllLoans_withStatusFilter_returnsFiltered()
////                throws Exception {
////
////            Page<LoanResponseDTO> page = new PageImpl<>(List.of(
////                buildLoanResponse("LN20260000002", "PENDING")
////            ));
////
////            when(loanService.getAllLoans(
////                    eq("PENDING"), any(Pageable.class)))
////                .thenReturn(page);
////
////            mockMvc.perform(
////                    get("/api/loans/admin/all")
////                    .param("status", "PENDING"))
////                .andExpect(status().isOk())
////                .andExpect(jsonPath("$.data.content",
////                        hasSize(1)))
////                .andExpect(jsonPath(
////                        "$.data.content[0].status")
////                        .value("PENDING"));
////        }
////
////        @Test
////        @WithMockUser(username = "customer1",
////                      roles = "CUSTOMER")
////        @DisplayName("Customer cannot access admin endpoint")
////        void getAllLoans_customerRole_returns403()
////                throws Exception {
////
////            mockMvc.perform(
////                    get("/api/loans/admin/all"))
////                .andExpect(status().isForbidden());
////
////            verify(loanService, never())
////                    .getAllLoans(any(), any());
////        }
////    }
//
//    // ─────────────────────────────────────────────
//    //  ADMIN: APPROVE LOAN
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/admin/{loanId}/approve")
//    class ApproveLoanTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can approve loan with treasury")
//        void approveLoan_validRequest_returnsApproved()
//                throws Exception {
//
//            ApproveLoanRequestDTO req =
//                    new ApproveLoanRequestDTO("13.5", 1L);
//
//            LoanResponseDTO approved =
//                    buildLoanResponse("LN20260000001", "APPROVED");
//            approved.setInterestRate("13.5");
//            approved.setEmiAmount("8438.00");
//            approved.setTreasuryCode("TRY20260000001");
//            approved.setTreasuryName("NeoBank Main Treasury");
//
//            when(loanService.approveLoan(
//                    eq("LN20260000001"), any(), eq("admin")))
//                .thenReturn(approved);
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/approve")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data.status")
//                        .value("APPROVED"))
//                .andExpect(jsonPath("$.data.interestRate")
//                        .value("13.5"))
//                .andExpect(jsonPath("$.data.emiAmount")
//                        .value("8438.00"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for already approved loan")
//        void approveLoan_alreadyApproved_returns400()
//                throws Exception {
//
//            when(loanService.approveLoan(
//                    eq("LN20260000001"), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_STATUS",
//                        "Only PENDING loans can be approved."));
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/approve")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new ApproveLoanRequestDTO("13.5", 1L)))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_STATUS"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for insufficient treasury")
//        void approveLoan_insufficientTreasury_returns400()
//                throws Exception {
//
//            when(loanService.approveLoan(
//                    eq("LN20260000001"), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "TREASURY_INSUFFICIENT_FUNDS",
//                        "Treasury has insufficient funds."));
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/approve")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new ApproveLoanRequestDTO("13.5", 1L)))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("TREASURY_INSUFFICIENT_FUNDS"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for invalid interest rate")
//        void approveLoan_invalidRate_returns400()
//                throws Exception {
//
//            when(loanService.approveLoan(
//                    eq("LN20260000001"), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_RATE",
//                        "Rate must be between 0.1% and 50%."));
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/approve")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new ApproveLoanRequestDTO("99", 1L)))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_RATE"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot approve loans")
//        void approveLoan_customerRole_returns403()
//                throws Exception {
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/approve")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new ApproveLoanRequestDTO("13.5", 1L)))
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//
//            verify(loanService, never())
//                    .approveLoan(any(), any(), any());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  ADMIN: REJECT LOAN
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/admin/{loanId}/reject")
//    class RejectLoanTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can reject loan with reason")
//        void rejectLoan_validReason_returnsRejected()
//                throws Exception {
//
//            RejectLoanRequestDTO req =
//                    new RejectLoanRequestDTO(
//                        "Insufficient income documentation.");
//
//            LoanResponseDTO rejected =
//                    buildLoanResponse("LN20260000001",
//                            "REJECTED");
//            rejected.setRejectionReason(
//                "Insufficient income documentation.");
//
//            when(loanService.rejectLoan(
//                    eq("LN20260000001"), any(), eq("admin")))
//                .thenReturn(rejected);
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/reject")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data.status")
//                        .value("REJECTED"))
//                .andExpect(jsonPath("$.data.rejectionReason")
//                        .value("Insufficient income " +
//                               "documentation."));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 when reason is blank")
//        void rejectLoan_blankReason_returns400()
//                throws Exception {
//
//            when(loanService.rejectLoan(
//                    eq("LN20260000001"), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "REASON_REQUIRED",
//                        "Rejection reason is required."));
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/reject")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new RejectLoanRequestDTO("")))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("REASON_REQUIRED"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot reject loans")
//        void rejectLoan_customerRole_returns403()
//                throws Exception {
//
//            mockMvc.perform(
//                    post("/api/loans/admin/LN20260000001/reject")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new RejectLoanRequestDTO("reason")))
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//
//            verify(loanService, never())
//                    .rejectLoan(any(), any(), any());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  ADMIN: APPROVE FORECLOSURE
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/admin/{loanId}/foreclosure/approve")
//    class ApproveForeclosureTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can approve foreclosure")
//        void approveForeclosure_validRequest_returnsForeclosed()
//                throws Exception {
//
//            LoanResponseDTO foreclosed =
//                    buildLoanResponse("LN20260000001",
//                            "FORECLOSED");
//            foreclosed.setOutstandingBalance("0.00");
//
//            when(loanService.approveForeclosure(
//                    "LN20260000001", "admin"))
//                .thenReturn(foreclosed);
//
//            mockMvc.perform(post(
//                    "/api/loans/admin/LN20260000001" +
//                    "/foreclosure/approve")
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data.status")
//                        .value("FORECLOSED"))
//                .andExpect(jsonPath("$.data.outstandingBalance")
//                        .value("0.00"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 if no foreclosure requested")
//        void approveForeclosure_noRequest_returns400()
//                throws Exception {
//
//            when(loanService.approveForeclosure(
//                    "LN20260000001", "admin"))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "NO_FORECLOSURE",
//                        "No foreclosure request found."));
//
//            mockMvc.perform(post(
//                    "/api/loans/admin/LN20260000001" +
//                    "/foreclosure/approve")
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("NO_FORECLOSURE"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for insufficient balance")
//        void approveForeclosure_insufficientBalance_returns400()
//                throws Exception {
//
//            when(loanService.approveForeclosure(
//                    "LN20260000001", "admin"))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INSUFFICIENT_BALANCE",
//                        "Account has insufficient balance."));
//
//            mockMvc.perform(post(
//                    "/api/loans/admin/LN20260000001" +
//                    "/foreclosure/approve")
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INSUFFICIENT_BALANCE"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot approve foreclosure")
//        void approveForeclosure_customerRole_returns403()
//                throws Exception {
//
//            mockMvc.perform(post(
//                    "/api/loans/admin/LN20260000001" +
//                    "/foreclosure/approve")
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  ADMIN: LOAN DETAIL
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("GET /api/loans/admin/{loanId}")
//    class AdminGetLoanDetailTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can get full loan detail with docs")
//        void getLoanDetail_adminRole_returnsFullDetail()
//                throws Exception {
//
//            LoanResponseDTO detail =
//                    buildLoanResponse("LN20260000001",
//                            "APPROVED");
//            detail.setIncomeProofBase64("base64string");
//            detail.setIncomeProofType("application/pdf");
//
//            when(loanService.getLoanDetail("LN20260000001"))
//                    .thenReturn(detail);
//
//            mockMvc.perform(get(
//                    "/api/loans/admin/LN20260000001"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data.loanId")
//                        .value("LN20260000001"))
//                .andExpect(jsonPath("$.data.incomeProofBase64")
//                        .value("base64string"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Returns 404 for non-existent loan")
//        void getLoanDetail_notFound_returns404()
//                throws Exception {
//
//            when(loanService.getLoanDetail("LN99999999999"))
//                    .thenThrow(new NeoBankException(
//                            HttpStatus.NOT_FOUND,
//                            "LOAN_NOT_FOUND",
//                            "Loan not found."));
//
//            mockMvc.perform(get(
//                    "/api/loans/admin/LN99999999999"))
//                .andExpect(status().isNotFound())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("LOAN_NOT_FOUND"));
//        }
//    }
//}
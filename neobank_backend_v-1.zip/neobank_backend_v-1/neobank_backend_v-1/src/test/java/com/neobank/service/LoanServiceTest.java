// src/test/java/com/neobank/service/LoanServiceTest.java

package com.neobank.service;

import com.neobank.dto.loan.*;
import com.neobank.entity.*;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.*;
import com.neobank.util.LoanIdGenerator;
import com.neobank.util.TransactionReferenceGenerator;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("LoanService Unit Tests")
class LoanServiceTest {

    @Mock private LoanRepository            loanRepository;
    @Mock private LoanEmiRepository         loanEmiRepository;
    @Mock private UserRepository            userRepository;
    @Mock private AccountRepository         accountRepository;
    @Mock private TransactionRepository     transactionRepository;
    @Mock private TreasuryRepository        treasuryRepository;
    @Mock private TreasuryService           treasuryService;
    @Mock private LoanProductService        loanProductService;
    @Mock private LoanIdGenerator           loanIdGenerator;
    @Mock private TransactionReferenceGenerator refGen;
    @Mock private MailService               mailService;

    @InjectMocks
    private LoanService loanService;

    // ─────────────────────────────────────────────
    //  TEST FIXTURES
    // ─────────────────────────────────────────────

    private User buildUser(Long id, String username) {
        User user = new User();
        user.setId(id);
        user.setUsername(username);
        user.setEmail(username + "@neobank.in");
        user.setFullName("Test User " + id);
        user.setStatus(User.UserStatus.ACTIVE);
        return user;
    }

    private Account buildAccount(
            Long id, User user, String accNum) {
        Account acc = new Account();
        acc.setId(id);
        acc.setUser(user);
        acc.setAccountNumber(accNum);
        acc.setBalance(new BigDecimal("500000"));
        acc.setAvailableBalance(new BigDecimal("500000"));
        acc.setHoldAmount(BigDecimal.ZERO);
        acc.setStatus(Account.AccountStatus.ACTIVE);
        acc.setAccountType(Account.AccountType.SAVINGS);
        return acc;
    }

    private Treasury buildTreasury() {
        Treasury t = new Treasury();
        t.setId(1L);
        t.setTreasuryCode("TRY20260000001");
        t.setName("NeoBank Main Treasury");
        t.setBalance(new BigDecimal("1000000000"));
        t.setTotalDisbursed(BigDecimal.ZERO);
        t.setTotalRecovered(BigDecimal.ZERO);
        t.setTotalInterestEarned(BigDecimal.ZERO);
        t.setStatus(Treasury.TreasuryStatus.ACTIVE);
        return t;
    }

    private Loan buildLoan(
            String loanId, User user, Account account,
            Loan.LoanStatus status) {
        Loan loan = new Loan();
        loan.setId(1L);
        loan.setLoanId(loanId);
        loan.setUser(user);
        loan.setAccount(account);
        loan.setLoanType(Loan.LoanType.PERSONAL);
        loan.setPrincipalAmount(new BigDecimal("250000"));
        loan.setTenureMonths(36);
        loan.setStatus(status);
        loan.setOutstandingBalance(new BigDecimal("250000"));
        loan.setEmisPaid(0);
        loan.setEmisOverdue(0);
        loan.setForeclosureRequested(false);
        return loan;
    }

    // ─────────────────────────────────────────────
    //  EMI CALCULATOR TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("calculateEmi()")
    class CalculateEmiTests {

        @Test
        @DisplayName("Should calculate correct EMI for valid input")
        void calculateEmi_validInput_returnsCorrectEmi() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "250000", "13.5", 36);

            EmiCalculatorResponseDTO result =
                    loanService.calculateEmi(req);

            assertThat(result).isNotNull();
            assertThat(result.getPrincipal())
                    .isEqualTo("250000");
            assertThat(result.getAnnualRate())
                    .isEqualTo("13.5");
            assertThat(result.getTenureMonths())
                    .isEqualTo(36);

            // EMI = P × r × (1+r)^n / ((1+r)^n - 1)
            // Approx ₹8438 for 250000 @ 13.5% for 36 months
            BigDecimal emi = new BigDecimal(result.getEmiAmount());
            assertThat(emi).isBetween(
                    new BigDecimal("8400"),
                    new BigDecimal("8500"));

            // Total payable = EMI × tenure
            BigDecimal totalPayable =
                    new BigDecimal(result.getTotalPayable());
            assertThat(totalPayable).isGreaterThan(
                    new BigDecimal("250000"));

            // Interest = totalPayable - principal
            BigDecimal interest =
                    new BigDecimal(result.getTotalInterest());
            assertThat(interest).isPositive();
            assertThat(totalPayable.subtract(interest))
                    .isEqualByComparingTo(
                            new BigDecimal("250000"));
        }

        @Test
        @DisplayName("Should throw 400 for zero principal")
        void calculateEmi_zeroPrincipal_throws400() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "0", "13.5", 36);

            assertThatThrownBy(() ->
                loanService.calculateEmi(req))
                .isInstanceOf(NeoBankException.class)
                .extracting("httpStatus")
                .isEqualTo(HttpStatus.BAD_REQUEST);
        }

        @Test
        @DisplayName("Should throw 400 for negative principal")
        void calculateEmi_negativePrincipal_throws400() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "-5000", "13.5", 36);

            assertThatThrownBy(() ->
                loanService.calculateEmi(req))
                .isInstanceOf(NeoBankException.class)
                .hasMessageContaining("Principal must be > 0");
        }

        @Test
        @DisplayName("Should throw 400 for zero rate")
        void calculateEmi_zeroRate_throws400() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "250000", "0", 36);

            assertThatThrownBy(() ->
                loanService.calculateEmi(req))
                .isInstanceOf(NeoBankException.class)
                .hasMessageContaining("Interest rate must be > 0");
        }

        @Test
        @DisplayName("Should throw 400 for tenure > 360")
        void calculateEmi_tenureExceedsMax_throws400() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "250000", "13.5", 361);

            assertThatThrownBy(() ->
                loanService.calculateEmi(req))
                .isInstanceOf(NeoBankException.class)
                .hasMessageContaining("Tenure must be 1–360");
        }

        @Test
        @DisplayName("Should throw 400 for tenure = 0")
        void calculateEmi_zeroTenure_throws400() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "250000", "13.5", 0);

            assertThatThrownBy(() ->
                loanService.calculateEmi(req))
                .isInstanceOf(NeoBankException.class);
        }

        @Test
        @DisplayName("EMI formula: totalPayable = EMI × tenure")
        void calculateEmi_totalPayableEqualsEmiTimeTenure() {

            EmiCalculatorRequestDTO req =
                    new EmiCalculatorRequestDTO(
                            "100000", "12", 12);

            EmiCalculatorResponseDTO result =
                    loanService.calculateEmi(req);

            BigDecimal emi =
                    new BigDecimal(result.getEmiAmount());
            BigDecimal totalPayable =
                    new BigDecimal(result.getTotalPayable());
            BigDecimal expected =
                    emi.multiply(BigDecimal.valueOf(12));

            // Allow ₹1 rounding difference
            assertThat(totalPayable
                    .subtract(expected)
                    .abs())
                .isLessThanOrEqualTo(BigDecimal.ONE);
        }
    }

    // ─────────────────────────────────────────────
    //  GET MY LOANS TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("getMyLoans()")
    class GetMyLoansTests {

        @Test
        @DisplayName("Should return all loans for user")
        void getMyLoans_returnsUserLoans() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");

            Loan loan1 = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);
            Loan loan2 = buildLoan(
                    "LN20260000002", user, acc,
                    Loan.LoanStatus.PENDING);

            when(userRepository.findByUsername("customer1"))
                    .thenReturn(Optional.of(user));
            when(loanRepository
                    .findByUserIdOrderByCreatedAtDesc(2L))
                .thenReturn(List.of(loan1, loan2));

            List<LoanResponseDTO> result =
                    loanService.getMyLoans("customer1");

            assertThat(result).hasSize(2);
            assertThat(result.get(0).getLoanId())
                    .isEqualTo("LN20260000001");
            assertThat(result.get(0).getStatus())
                    .isEqualTo("APPROVED");
            assertThat(result.get(1).getStatus())
                    .isEqualTo("PENDING");
        }

        @Test
        @DisplayName("Should return empty list for user with no loans")
        void getMyLoans_noLoans_returnsEmpty() {

            User user = buildUser(2L, "customer1");

            when(userRepository.findByUsername("customer1"))
                    .thenReturn(Optional.of(user));
            when(loanRepository
                    .findByUserIdOrderByCreatedAtDesc(2L))
                .thenReturn(List.of());

            List<LoanResponseDTO> result =
                    loanService.getMyLoans("customer1");

            assertThat(result).isEmpty();
        }
    }

    // ─────────────────────────────────────────────
    //  FORECLOSURE REQUEST TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("requestForeclosure()")
    class ForeclosureRequestTests {

        @Test
        @DisplayName("Should set foreclosureRequested with 2% charge")
        void requestForeclosure_activeLoan_setsFlag() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);
            loan.setOutstandingBalance(
                    new BigDecimal("200000"));

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));
            when(loanRepository.save(any()))
                    .thenReturn(loan);

            LoanResponseDTO result =
                    loanService.requestForeclosure(
                            "LN20260000001", "customer1");

            assertThat(result.getForeclosureRequested())
                    .isTrue();
            // 200000 + 2% = 204000
            assertThat(result.getForeclosureAmount())
                    .isEqualTo("204000.00");
        }

        @Test
        @DisplayName("Should throw 409 if already requested")
        void requestForeclosure_alreadyRequested_throws409() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);
            loan.setForeclosureRequested(true);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.requestForeclosure(
                        "LN20260000001", "customer1"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("ALREADY_REQUESTED");
        }

        @Test
        @DisplayName("Should throw 400 for rejected loan")
        void requestForeclosure_rejectedLoan_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.REJECTED);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.requestForeclosure(
                        "LN20260000001", "customer1"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_STATUS");
        }

        @Test
        @DisplayName("Should throw 403 for other user's loan")
        void requestForeclosure_otherUserLoan_throws403() {

            User user1 = buildUser(2L, "customer1");
            User user2 = buildUser(3L, "customer2");
            Account acc = buildAccount(
                    1L, user2, "NB20260000000002");
            Loan loan = buildLoan(
                    "LN20260000001", user2, acc,
                    Loan.LoanStatus.APPROVED);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            // customer1 trying to access customer2's loan
            assertThatThrownBy(() ->
                loanService.requestForeclosure(
                        "LN20260000001", "customer1"))
                .isInstanceOf(NeoBankException.class)
                .extracting("httpStatus")
                .isEqualTo(HttpStatus.FORBIDDEN);
        }
    }

    // ─────────────────────────────────────────────
    //  APPROVE LOAN TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("approveLoan()")
    class ApproveLoanTests {

        @Test
        @DisplayName("Should approve loan and debit treasury")
        void approveLoan_validRequest_approvesAndDebits() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.PENDING);
            Treasury treasury = buildTreasury();

            ApproveLoanRequestDTO req =
                    new ApproveLoanRequestDTO("13.5", 1L);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));
            when(treasuryService.findById(1L))
                    .thenReturn(treasury);
            when(refGen.generate())
                    .thenReturn("TXN20260000001");
            when(transactionRepository.save(any()))
                    .thenReturn(new Transaction());
            when(accountRepository.save(any()))
                    .thenReturn(acc);
            when(loanRepository.save(any()))
                    .thenReturn(loan);
            when(loanEmiRepository.saveAll(any()))
                    .thenReturn(List.of());

            LoanResponseDTO result =
                    loanService.approveLoan(
                            "LN20260000001", req, "admin");

            assertThat(result.getStatus())
                    .isEqualTo("APPROVED");

            // Treasury should be debited
            verify(treasuryRepository, times(1))
                    .save(treasury);

            // Account should be credited
            assertThat(acc.getBalance())
                    .isEqualByComparingTo(
                        new BigDecimal("750000")); // 500000 + 250000

            // Transaction should be created
            verify(transactionRepository, times(1))
                    .save(any());

            // EMI schedule should be generated
            verify(loanEmiRepository, times(1))
                    .saveAll(any());
        }

        @Test
        @DisplayName("Should throw 400 for non-PENDING loan")
        void approveLoan_alreadyApproved_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.approveLoan(
                    "LN20260000001",
                    new ApproveLoanRequestDTO("13.5", 1L),
                    "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_STATUS");
        }

        @Test
        @DisplayName("Should throw 400 for insufficient treasury")
        void approveLoan_insufficientTreasury_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.PENDING);
            loan.setPrincipalAmount(
                    new BigDecimal("999999999"));

            Treasury treasury = buildTreasury();
            // Treasury has only 1 billion, loan wants more

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));
            when(treasuryService.findById(1L))
                    .thenReturn(treasury);

            assertThatThrownBy(() ->
                loanService.approveLoan(
                    "LN20260000001",
                    new ApproveLoanRequestDTO("13.5", 1L),
                    "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("TREASURY_INSUFFICIENT_FUNDS");
        }
    }

    // ─────────────────────────────────────────────
    //  REJECT LOAN TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("rejectLoan()")
    class RejectLoanTests {

        @Test
        @DisplayName("Should reject loan with reason")
        void rejectLoan_validReason_rejectsLoan() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.PENDING);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));
            when(loanRepository.save(any()))
                    .thenReturn(loan);

            RejectLoanRequestDTO req =
                    new RejectLoanRequestDTO(
                        "Insufficient income.");

            LoanResponseDTO result =
                    loanService.rejectLoan(
                        "LN20260000001", req, "admin");

            assertThat(result.getStatus())
                    .isEqualTo("REJECTED");
            assertThat(result.getRejectionReason())
                    .isEqualTo("Insufficient income.");
        }

        @Test
        @DisplayName("Should throw 400 for blank reason")
        void rejectLoan_blankReason_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.PENDING);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.rejectLoan(
                    "LN20260000001",
                    new RejectLoanRequestDTO(""),
                    "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("REASON_REQUIRED");
        }

        @Test
        @DisplayName("Should throw 400 for non-PENDING loan")
        void rejectLoan_approvedLoan_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.rejectLoan(
                    "LN20260000001",
                    new RejectLoanRequestDTO("Reason"),
                    "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_STATUS");
        }
    }

    // ─────────────────────────────────────────────
    //  APPROVE FORECLOSURE TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("approveForeclosure()")
    class ApproveForeclosureTests {

        @Test
        @DisplayName("Should foreclose loan correctly")
        void approveForeclosure_validRequest_closesLoan() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Treasury treasury = buildTreasury();

            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);
            loan.setForeclosureRequested(true);
            loan.setForeclosureAmount(new BigDecimal("204000"));
            loan.setOutstandingBalance(new BigDecimal("200000"));
            loan.setTreasury(treasury);

            LoanEmi pendingEmi = new LoanEmi();
            pendingEmi.setStatus(LoanEmi.EmiStatus.PENDING);
            pendingEmi.setEmiNumber(5);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));
            when(loanEmiRepository
                    .findByLoanIdOrderByEmiNumberAsc(1L))
                .thenReturn(List.of(pendingEmi));
            when(refGen.generate())
                    .thenReturn("TXN20260000002");
            when(transactionRepository.save(any()))
                    .thenReturn(new Transaction());
            when(accountRepository.save(any()))
                    .thenReturn(acc);
            when(loanRepository.save(any()))
                    .thenReturn(loan);

            LoanResponseDTO result =
                    loanService.approveForeclosure(
                            "LN20260000001", "admin");

            assertThat(result.getStatus())
                    .isEqualTo("FORECLOSED");
            assertThat(result.getOutstandingBalance())
                    .isEqualTo("0.00");

            // Customer account debited
            assertThat(acc.getBalance())
                .isEqualByComparingTo(
                    new BigDecimal("500000")
                    .subtract(new BigDecimal("204000")));

            // Treasury credited
            verify(treasuryRepository, times(1))
                    .save(treasury);

            // EMI waived
            assertThat(pendingEmi.getStatus())
                    .isEqualTo(LoanEmi.EmiStatus.WAIVED);
        }

        @Test
        @DisplayName("Should throw 400 for no foreclosure request")
        void approveForeclosure_noRequest_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);
            loan.setForeclosureRequested(false);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.approveForeclosure(
                    "LN20260000001", "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("NO_FORECLOSURE");
        }

        @Test
        @DisplayName("Should throw 400 for insufficient balance")
        void approveForeclosure_insufficientBalance_throws400() {

            User user = buildUser(2L, "customer1");
            Account acc = buildAccount(
                    1L, user, "NB20260000000001");
            acc.setBalance(new BigDecimal("100")); // Very low
            acc.setAvailableBalance(new BigDecimal("100"));

            Treasury treasury = buildTreasury();
            Loan loan = buildLoan(
                    "LN20260000001", user, acc,
                    Loan.LoanStatus.APPROVED);
            loan.setForeclosureRequested(true);
            loan.setForeclosureAmount(
                    new BigDecimal("204000")); // Needs more
            loan.setOutstandingBalance(
                    new BigDecimal("200000"));
            loan.setTreasury(treasury);

            when(loanRepository
                    .findByLoanId("LN20260000001"))
                .thenReturn(Optional.of(loan));

            assertThatThrownBy(() ->
                loanService.approveForeclosure(
                    "LN20260000001", "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INSUFFICIENT_BALANCE");
        }
    }
}
//// src/test/java/com/neobank/controller/
////   LoanProductControllerTest.java
//
//package com.neobank.controller;
//
//import com.neobank.base.BaseControllerTest;
//import com.neobank.dto.loan.*;
//import com.neobank.exception.NeoBankException;
//import com.neobank.service.LoanProductService;
//import org.junit.jupiter.api.*;
//import org.springframework.boot.test.autoconfigure.web.servlet.*;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.*;
//import org.springframework.security.test.context.support.WithMockUser;
//
//import java.util.List;
//
//import static org.hamcrest.Matchers.*;
//import static org.mockito.ArgumentMatchers.*;
//import static org.mockito.Mockito.*;
//import static org.springframework.security.test.web.servlet
//        .request.SecurityMockMvcRequestPostProcessors.csrf;
//import static org.springframework.test.web.servlet.request
//        .MockMvcRequestBuilders.*;
//import static org.springframework.test.web.servlet.result
//        .MockMvcResultMatchers.*;
//@WebMvcTest(LoanProductController.class)
//@DisplayName("LoanProductController Tests")
//class LoanProductControllerTest extends BaseControllerTest {
//
//    @MockBean
//    private LoanProductService productService;
//
//    // ─────────────────────────────────────────────
//    //  TEST DATA BUILDERS
//    // ─────────────────────────────────────────────
//
//    private LoanProductResponseDTO buildProduct(
//            Long id, String name, String loanType) {
//        return LoanProductResponseDTO.builder()
//                .id(id)
//                .productName(name)
//                .description("Test product description")
//                .loanType(loanType)
//                .minAmount("10000.00")
//                .maxAmount("5000000.00")
//                .annualInterestRate("13.50")
//                .allowedTenures("12,24,36,48,60")
//                .incomeProofRequired(true)
//                .addressProofRequired(false)
//                .propertyDocRequired(false)
//                .vehicleDocRequired(false)
//                .bankStatementRequired(false)
//                .isActive(true)
//                .createdBy("admin")
//                .createdAt("01 Jun 2026, 10:00 AM")
//                .build();
//    }
//
//    private CreateLoanProductRequestDTO buildCreateRequest() {
//        CreateLoanProductRequestDTO req =
//                new CreateLoanProductRequestDTO();
//        req.setProductName("NeoBank Personal Loan");
//        req.setDescription("Quick unsecured loan");
//        req.setLoanType("PERSONAL");
//        req.setMinAmount("10000");
//        req.setMaxAmount("5000000");
//        req.setAnnualInterestRate("13.5");
//        req.setAllowedTenures("12,24,36,48,60");
//        req.setIncomeProofRequired(true);
//        req.setAddressProofRequired(false);
//        req.setPropertyDocRequired(false);
//        req.setVehicleDocRequired(false);
//        req.setBankStatementRequired(false);
//        return req;
//    }
//
//    // ─────────────────────────────────────────────
//    //  GET ACTIVE PRODUCTS (public/authenticated)
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("GET /api/loans/products/active")
//    class GetActiveProductsTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return active products for customer")
//        void getActiveProducts_customerRole_returnsList()
//                throws Exception {
//
//            List<LoanProductResponseDTO> products = List.of(
//                buildProduct(1L, "Personal Loan", "PERSONAL"),
//                buildProduct(2L, "Home Loan",     "HOME"),
//                buildProduct(3L, "Car Loan",      "VEHICLE")
//            );
//
//            when(productService.getActiveProducts())
//                    .thenReturn(products);
//
//            mockMvc.perform(
//                    get("/api/loans/products/active"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data", hasSize(3)))
//                .andExpect(jsonPath("$.data[0].productName")
//                        .value("Personal Loan"))
//                .andExpect(jsonPath("$.data[1].loanType")
//                        .value("HOME"))
//                .andExpect(jsonPath("$.data[2].isActive")
//                        .value(true));
//
//            verify(productService, times(1))
//                    .getActiveProducts();
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return empty list when no active")
//        void getActiveProducts_noActive_returnsEmpty()
//                throws Exception {
//
//            when(productService.getActiveProducts())
//                    .thenReturn(List.of());
//
//            mockMvc.perform(
//                    get("/api/loans/products/active"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data", hasSize(0)));
//        }
//
//        @Test
//        @DisplayName("Returns 401 when unauthenticated")
//        void getActiveProducts_noAuth_returns401()
//                throws Exception {
//
//            mockMvc.perform(
//                    get("/api/loans/products/active"))
//                .andExpect(status().isUnauthorized());
//
//            verify(productService, never())
//                    .getActiveProducts();
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Products have all required fields")
//        void getActiveProducts_hasAllFields()
//                throws Exception {
//
//            when(productService.getActiveProducts())
//                    .thenReturn(List.of(
//                        buildProduct(1L, "Personal Loan",
//                                "PERSONAL")));
//
//            mockMvc.perform(
//                    get("/api/loans/products/active"))
//                .andExpect(jsonPath("$.data[0].id")
//                        .value(1))
//                .andExpect(jsonPath("$.data[0].productName")
//                        .value("Personal Loan"))
//                .andExpect(jsonPath("$.data[0].loanType")
//                        .value("PERSONAL"))
//                .andExpect(jsonPath("$.data[0].minAmount")
//                        .value("10000.00"))
//                .andExpect(jsonPath("$.data[0].maxAmount")
//                        .value("5000000.00"))
//                .andExpect(jsonPath(
//                        "$.data[0].annualInterestRate")
//                        .value("13.50"))
//                .andExpect(jsonPath("$.data[0].allowedTenures")
//                        .value("12,24,36,48,60"))
//                .andExpect(jsonPath(
//                        "$.data[0].incomeProofRequired")
//                        .value(true));
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  GET ONE PRODUCT
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("GET /api/loans/products/{id}")
//    class GetOneProductTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return product by ID")
//        void getProduct_validId_returnsProduct()
//                throws Exception {
//
//            when(productService.getProduct(1L))
//                    .thenReturn(buildProduct(1L,
//                        "Personal Loan", "PERSONAL"));
//
//            mockMvc.perform(
//                    get("/api/loans/products/1"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data.id").value(1))
//                .andExpect(jsonPath("$.data.productName")
//                        .value("Personal Loan"));
//
//            verify(productService, times(1))
//                    .getProduct(1L);
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Should return 404 for non-existent product")
//        void getProduct_notFound_returns404()
//                throws Exception {
//
//            when(productService.getProduct(999L))
//                    .thenThrow(new NeoBankException(
//                            HttpStatus.NOT_FOUND,
//                            "PRODUCT_NOT_FOUND",
//                            "Loan product not found: 999"));
//
//            mockMvc.perform(
//                    get("/api/loans/products/999"))
//                .andExpect(status().isNotFound())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("PRODUCT_NOT_FOUND"));
//        }
//
//        @Test
//        @DisplayName("Returns 401 for unauthenticated request")
//        void getProduct_noAuth_returns401()
//                throws Exception {
//
//            mockMvc.perform(
//                    get("/api/loans/products/1"))
//                .andExpect(status().isUnauthorized());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  GET ALL PRODUCTS (admin)
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("GET /api/loans/products")
//    class GetAllProductsTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can see all products including inactive")
//        void getAllProducts_adminRole_returnsAll()
//                throws Exception {
//
//            LoanProductResponseDTO inactive =
//                    buildProduct(4L, "Old Product", "PERSONAL");
//            inactive.setIsActive(false);
//
//            List<LoanProductResponseDTO> all = List.of(
//                buildProduct(1L, "Personal Loan", "PERSONAL"),
//                buildProduct(2L, "Home Loan",     "HOME"),
//                inactive
//            );
//
//            when(productService.getAllProducts())
//                    .thenReturn(all);
//
//            mockMvc.perform(
//                    get("/api/loans/products"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data", hasSize(3)))
//                .andExpect(jsonPath("$.data[2].isActive")
//                        .value(false));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot access admin product list")
//        void getAllProducts_customerRole_returns403()
//                throws Exception {
//
//            mockMvc.perform(
//                    get("/api/loans/products"))
//                .andExpect(status().isForbidden());
//
//            verify(productService, never()).getAllProducts();
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  CREATE PRODUCT
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("POST /api/loans/products")
//    class CreateProductTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can create a new loan product")
//        void createProduct_validRequest_returns201()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenReturn(buildProduct(
//                    5L, "NeoBank Personal Loan",
//                    "PERSONAL"));
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(buildCreateRequest()))
//                    .with(csrf()))
//                .andExpect(status().isCreated())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data.id").value(5))
//                .andExpect(jsonPath("$.data.productName")
//                        .value("NeoBank Personal Loan"))
//                .andExpect(jsonPath("$.data.loanType")
//                        .value("PERSONAL"))
//                .andExpect(jsonPath("$.data.isActive")
//                        .value(true));
//
//            verify(productService, times(1))
//                    .createProduct(any(), eq("admin"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 409 for duplicate product name")
//        void createProduct_duplicateName_returns409()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.CONFLICT,
//                        "PRODUCT_EXISTS",
//                        "A product with name " +
//                        "'NeoBank Personal Loan' " +
//                        "already exists."));
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(buildCreateRequest()))
//                    .with(csrf()))
//                .andExpect(status().isConflict())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("PRODUCT_EXISTS"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for missing product name")
//        void createProduct_missingName_returns400()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "NAME_REQUIRED",
//                        "Product name is required."));
//
//            CreateLoanProductRequestDTO req =
//                    buildCreateRequest();
//            req.setProductName("");
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("NAME_REQUIRED"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 when maxAmount < minAmount")
//        void createProduct_maxLessThanMin_returns400()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_AMOUNT",
//                        "Max amount must be greater " +
//                        "than min amount."));
//
//            CreateLoanProductRequestDTO req =
//                    buildCreateRequest();
//            req.setMinAmount("5000000");
//            req.setMaxAmount("1000");
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_AMOUNT"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for invalid interest rate")
//        void createProduct_rateAbove50_returns400()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_RATE",
//                        "Rate must be between 0.1% and 50%."));
//
//            CreateLoanProductRequestDTO req =
//                    buildCreateRequest();
//            req.setAnnualInterestRate("99");
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_RATE"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for invalid tenure format")
//        void createProduct_invalidTenures_returns400()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_TENURES",
//                        "Tenures must be comma-separated months."));
//
//            CreateLoanProductRequestDTO req =
//                    buildCreateRequest();
//            req.setAllowedTenures("abc,xyz");
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_TENURES"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for invalid loan type")
//        void createProduct_invalidLoanType_returns400()
//                throws Exception {
//
//            when(productService.createProduct(
//                    any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_TYPE",
//                        "Loan type must be HOME, PERSONAL, " +
//                        "VEHICLE, or EDUCATION."));
//
//            CreateLoanProductRequestDTO req =
//                    buildCreateRequest();
//            req.setLoanType("INVALID_TYPE");
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_TYPE"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot create products")
//        void createProduct_customerRole_returns403()
//                throws Exception {
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(buildCreateRequest()))
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//
//            verify(productService, never())
//                    .createProduct(any(), any());
//        }
//
//        @Test
//        @DisplayName("Unauthenticated cannot create products")
//        void createProduct_noAuth_returns401()
//                throws Exception {
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(buildCreateRequest())))
//                .andExpect(status().isUnauthorized());
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  UPDATE PRODUCT
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("PUT /api/loans/products/{id}")
//    class UpdateProductTests {
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can update product details")
//        void updateProduct_validRequest_returnsUpdated()
//                throws Exception {
//
//            UpdateLoanProductRequestDTO req =
//                    new UpdateLoanProductRequestDTO();
//            req.setProductName("Updated Personal Loan");
//            req.setAnnualInterestRate("12.5");
//            req.setIsActive(true);
//
//            LoanProductResponseDTO updated =
//                    buildProduct(1L,
//                            "Updated Personal Loan",
//                            "PERSONAL");
//            updated.setAnnualInterestRate("12.50");
//
//            when(productService.updateProduct(
//                    eq(1L), any(), eq("admin")))
//                .thenReturn(updated);
//
//            mockMvc.perform(
//                    put("/api/loans/products/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.success").value(true))
//                .andExpect(jsonPath("$.data.productName")
//                        .value("Updated Personal Loan"))
//                .andExpect(jsonPath("$.data.annualInterestRate")
//                        .value("12.50"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Admin can deactivate product")
//        void updateProduct_setInactive_returnsInactive()
//                throws Exception {
//
//            UpdateLoanProductRequestDTO req =
//                    new UpdateLoanProductRequestDTO();
//            req.setIsActive(false);
//
//            LoanProductResponseDTO deactivated =
//                    buildProduct(1L, "Personal Loan",
//                            "PERSONAL");
//            deactivated.setIsActive(false);
//
//            when(productService.updateProduct(
//                    eq(1L), any(), eq("admin")))
//                .thenReturn(deactivated);
//
//            mockMvc.perform(
//                    put("/api/loans/products/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.data.isActive")
//                        .value(false));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 404 for non-existent product")
//        void updateProduct_notFound_returns404()
//                throws Exception {
//
//            when(productService.updateProduct(
//                    eq(999L), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.NOT_FOUND,
//                        "PRODUCT_NOT_FOUND",
//                        "Loan product not found: 999"));
//
//            mockMvc.perform(
//                    put("/api/loans/products/999")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new UpdateLoanProductRequestDTO()))
//                    .with(csrf()))
//                .andExpect(status().isNotFound())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("PRODUCT_NOT_FOUND"));
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 409 for duplicate name on update")
//        void updateProduct_duplicateName_returns409()
//                throws Exception {
//
//            when(productService.updateProduct(
//                    eq(2L), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.CONFLICT,
//                        "PRODUCT_EXISTS",
//                        "Product name already taken."));
//
//            UpdateLoanProductRequestDTO req =
//                    new UpdateLoanProductRequestDTO();
//            req.setProductName("Personal Loan");
//
//            mockMvc.perform(
//                    put("/api/loans/products/2")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isConflict())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("PRODUCT_EXISTS"));
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot update products")
//        void updateProduct_customerRole_returns403()
//                throws Exception {
//
//            mockMvc.perform(
//                    put("/api/loans/products/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(
//                        new UpdateLoanProductRequestDTO()))
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//
//            verify(productService, never())
//                    .updateProduct(any(), any(), any());
//        }
//
//        @Test
//        @WithMockUser(username = "admin",
//                      roles = "ADMIN")
//        @DisplayName("Should return 400 for invalid tenure on update")
//        void updateProduct_invalidTenure_returns400()
//                throws Exception {
//
//            when(productService.updateProduct(
//                    eq(1L), any(), eq("admin")))
//                .thenThrow(new NeoBankException(
//                        HttpStatus.BAD_REQUEST,
//                        "INVALID_TENURES",
//                        "Each tenure must be between 1–360."));
//
//            UpdateLoanProductRequestDTO req =
//                    new UpdateLoanProductRequestDTO();
//            req.setAllowedTenures("999");
//
//            mockMvc.perform(
//                    put("/api/loans/products/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(req))
//                    .with(csrf()))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.errorCode")
//                        .value("INVALID_TENURES"));
//        }
//    }
//
//    // ─────────────────────────────────────────────
//    //  SECURITY — ROLE MATRIX
//    // ─────────────────────────────────────────────
//
//    @Nested
//    @DisplayName("Security Role Matrix")
//    class SecurityRoleMatrixTests {
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer can access active products")
//        void customer_canAccess_activeProducts()
//                throws Exception {
//
//            when(productService.getActiveProducts())
//                    .thenReturn(List.of());
//
//            mockMvc.perform(
//                    get("/api/loans/products/active"))
//                .andExpect(status().isOk());
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot access all products")
//        void customer_cannotAccess_allProducts()
//                throws Exception {
//
//            mockMvc.perform(
//                    get("/api/loans/products"))
//                .andExpect(status().isForbidden());
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot create products")
//        void customer_cannotCreate_product()
//                throws Exception {
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(buildCreateRequest()))
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//        }
//
//        @Test
//        @WithMockUser(username = "customer1",
//                      roles = "CUSTOMER")
//        @DisplayName("Customer cannot update products")
//        void customer_cannotUpdate_product()
//                throws Exception {
//
//            mockMvc.perform(
//                    put("/api/loans/products/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content("{}")
//                    .with(csrf()))
//                .andExpect(status().isForbidden());
//        }
//
//        @Test
//        @WithMockUser(username = "admin", roles = "ADMIN")
//        @DisplayName("Admin can access all products")
//        void admin_canAccess_allProducts()
//                throws Exception {
//
//            when(productService.getAllProducts())
//                    .thenReturn(List.of());
//
//            mockMvc.perform(
//                    get("/api/loans/products"))
//                .andExpect(status().isOk());
//        }
//
//        @Test
//        @WithMockUser(username = "admin", roles = "ADMIN")
//        @DisplayName("Admin can create product")
//        void admin_canCreate_product() throws Exception {
//
//            when(productService.createProduct(any(), any()))
//                    .thenReturn(buildProduct(
//                        1L, "New Product", "PERSONAL"));
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content(toJson(buildCreateRequest()))
//                    .with(csrf()))
//                .andExpect(status().isCreated());
//        }
//
//        @Test
//        @DisplayName("Unauthenticated: all endpoints return 401")
//        void unauthenticated_allEndpoints_return401()
//                throws Exception {
//
//            mockMvc.perform(
//                    get("/api/loans/products/active"))
//                .andExpect(status().isUnauthorized());
//
//            mockMvc.perform(
//                    get("/api/loans/products/1"))
//                .andExpect(status().isUnauthorized());
//
//            mockMvc.perform(
//                    get("/api/loans/products"))
//                .andExpect(status().isUnauthorized());
//
//            mockMvc.perform(
//                    post("/api/loans/products")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .content("{}"))
//                .andExpect(status().isUnauthorized());
//        }
//    }
//}
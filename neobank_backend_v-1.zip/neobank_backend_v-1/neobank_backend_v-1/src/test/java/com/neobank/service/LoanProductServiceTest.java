// src/test/java/com/neobank/service/
//   LoanProductServiceTest.java

package com.neobank.service;

import com.neobank.dto.loan.*;
import com.neobank.entity.*;
import com.neobank.exception.NeoBankException;
import com.neobank.repository.LoanProductRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("LoanProductService Unit Tests")
class LoanProductServiceTest {

    @Mock
    private LoanProductRepository productRepository;

    @InjectMocks
    private LoanProductService productService;

    // ─────────────────────────────────────────────
    //  FIXTURE
    // ─────────────────────────────────────────────

    private LoanProduct buildProduct(
            Long id, String name, boolean active) {
        LoanProduct p = new LoanProduct();
        p.setId(id);
        p.setProductName(name);
        p.setDescription("Test description");
        p.setLoanType(Loan.LoanType.PERSONAL);
        p.setMinAmount(new BigDecimal("10000"));
        p.setMaxAmount(new BigDecimal("5000000"));
        p.setAnnualInterestRate(new BigDecimal("13.5"));
        p.setAllowedTenures("12,24,36,48,60");
        p.setIncomeProofRequired(true);
        p.setAddressProofRequired(false);
        p.setPropertyDocRequired(false);
        p.setVehicleDocRequired(false);
        p.setBankStatementRequired(false);
        p.setIsActive(active);
        p.setCreatedBy("admin");
        return p;
    }

    private CreateLoanProductRequestDTO buildCreateReq() {
        CreateLoanProductRequestDTO req =
                new CreateLoanProductRequestDTO();
        req.setProductName("NeoBank Personal Loan");
        req.setDescription("Quick unsecured loan");
        req.setLoanType("PERSONAL");
        req.setMinAmount("10000");
        req.setMaxAmount("5000000");
        req.setAnnualInterestRate("13.5");
        req.setAllowedTenures("12,24,36,48,60");
        req.setIncomeProofRequired(true);
        req.setAddressProofRequired(false);
        req.setPropertyDocRequired(false);
        req.setVehicleDocRequired(false);
        req.setBankStatementRequired(false);
        return req;
    }

    // ─────────────────────────────────────────────
    //  CREATE PRODUCT TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("createProduct()")
    class CreateProductTests {

        @Test
        @DisplayName("Should create product successfully")
        void createProduct_validRequest_returnsCreated() {

            LoanProduct saved =
                    buildProduct(1L, "NeoBank Personal Loan",
                            true);

            when(productRepository.existsByProductNameIgnoreCase(
                    "NeoBank Personal Loan"))
                .thenReturn(false);
            when(productRepository.save(any()))
                    .thenReturn(saved);

            LoanProductResponseDTO result =
                    productService.createProduct(
                            buildCreateReq(), "admin");

            assertThat(result).isNotNull();
            assertThat(result.getProductName())
                    .isEqualTo("NeoBank Personal Loan");
            assertThat(result.getLoanType())
                    .isEqualTo("PERSONAL");
            assertThat(result.getIsActive()).isTrue();
            assertThat(result.getCreatedBy())
                    .isEqualTo("admin");

            verify(productRepository, times(1)).save(any());
        }

        @Test
        @DisplayName("Should throw 409 for duplicate name")
        void createProduct_duplicateName_throws409() {

            when(productRepository.existsByProductNameIgnoreCase(
                    "NeoBank Personal Loan"))
                .thenReturn(true);

            assertThatThrownBy(() ->
                productService.createProduct(
                        buildCreateReq(), "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("httpStatus")
                .isEqualTo(HttpStatus.CONFLICT);

            verify(productRepository, never()).save(any());
        }

        @Test
        @DisplayName("Should throw 400 for blank name")
        void createProduct_blankName_throws400() {

            CreateLoanProductRequestDTO req = buildCreateReq();
            req.setProductName("");

            assertThatThrownBy(() ->
                productService.createProduct(req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("NAME_REQUIRED");
        }

        @Test
        @DisplayName("Should throw 400 for invalid loan type")
        void createProduct_invalidLoanType_throws400() {

            CreateLoanProductRequestDTO req = buildCreateReq();
            req.setLoanType("CRYPTO");

            assertThatThrownBy(() ->
                productService.createProduct(req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_TYPE");
        }

        @Test
        @DisplayName("Should throw 400 when maxAmount < minAmount")
        void createProduct_maxLessThanMin_throws400() {

            CreateLoanProductRequestDTO req = buildCreateReq();
            req.setMinAmount("5000000");
            req.setMaxAmount("1000");

            when(productRepository.existsByProductNameIgnoreCase(
                    anyString())).thenReturn(false);

            assertThatThrownBy(() ->
                productService.createProduct(req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_AMOUNT");
        }

        @Test
        @DisplayName("Should throw 400 for rate > 50%")
        void createProduct_rateAbove50_throws400() {

            CreateLoanProductRequestDTO req = buildCreateReq();
            req.setAnnualInterestRate("51");

            when(productRepository.existsByProductNameIgnoreCase(
                    anyString())).thenReturn(false);

            assertThatThrownBy(() ->
                productService.createProduct(req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_RATE");
        }

        @Test
        @DisplayName("Should throw 400 for invalid tenures")
        void createProduct_invalidTenures_throws400() {

            CreateLoanProductRequestDTO req = buildCreateReq();
            req.setAllowedTenures("abc,xyz");

            when(productRepository.existsByProductNameIgnoreCase(
                    anyString())).thenReturn(false);

            assertThatThrownBy(() ->
                productService.createProduct(req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_TENURES");
        }

        @Test
        @DisplayName("Should throw 400 for tenure > 360")
        void createProduct_tenureAbove360_throws400() {

            CreateLoanProductRequestDTO req = buildCreateReq();
            req.setAllowedTenures("12,24,361");

            when(productRepository.existsByProductNameIgnoreCase(
                    anyString())).thenReturn(false);

            assertThatThrownBy(() ->
                productService.createProduct(req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("INVALID_TENURES");
        }
    }

    // ─────────────────────────────────────────────
    //  GET PRODUCTS TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("getActiveProducts() / getAllProducts()")
    class GetProductsTests {

        @Test
        @DisplayName("Should return only active products")
        void getActiveProducts_returnsOnlyActive() {

            List<LoanProduct> active = List.of(
                buildProduct(1L, "Personal Loan", true),
                buildProduct(2L, "Home Loan",     true)
            );

            when(productRepository
                    .findByIsActiveTrueOrderByLoanTypeAsc())
                .thenReturn(active);

            List<LoanProductResponseDTO> result =
                    productService.getActiveProducts();

            assertThat(result).hasSize(2);
            assertThat(result)
                    .allSatisfy(p ->
                        assertThat(p.getIsActive()).isTrue());
        }

        @Test
        @DisplayName("Should return all products including inactive")
        void getAllProducts_returnsAll() {

            List<LoanProduct> all = List.of(
                buildProduct(1L, "Personal Loan", true),
                buildProduct(2L, "Old Product",   false)
            );

            when(productRepository
                    .findAllByOrderByCreatedAtDesc())
                .thenReturn(all);

            List<LoanProductResponseDTO> result =
                    productService.getAllProducts();

            assertThat(result).hasSize(2);
            assertThat(result.get(1).getIsActive())
                    .isFalse();
        }

        @Test
        @DisplayName("Should return empty list when none exist")
        void getActiveProducts_empty_returnsEmpty() {

            when(productRepository
                    .findByIsActiveTrueOrderByLoanTypeAsc())
                .thenReturn(List.of());

            List<LoanProductResponseDTO> result =
                    productService.getActiveProducts();

            assertThat(result).isEmpty();
        }
    }

    // ─────────────────────────────────────────────
    //  UPDATE PRODUCT TESTS
    // ─────────────────────────────────────────────

    @Nested
    @DisplayName("updateProduct()")
    class UpdateProductTests {

        @Test
        @DisplayName("Should update product name successfully")
        void updateProduct_newName_updatesName() {

            LoanProduct existing =
                    buildProduct(1L, "Old Name", true);

            when(productRepository.findById(1L))
                    .thenReturn(Optional.of(existing));
            when(productRepository
                    .existsByProductNameIgnoreCase("New Name"))
                .thenReturn(false);
            when(productRepository.save(any()))
                    .thenReturn(existing);

            UpdateLoanProductRequestDTO req =
                    new UpdateLoanProductRequestDTO();
            req.setProductName("New Name");

            LoanProductResponseDTO result =
                    productService.updateProduct(
                            1L, req, "admin");

            assertThat(result.getProductName())
                    .isEqualTo("New Name");
            verify(productRepository, times(1)).save(any());
        }

        @Test
        @DisplayName("Should deactivate product")
        void updateProduct_setInactive_deactivates() {

            LoanProduct existing =
                    buildProduct(1L, "Personal Loan", true);

            when(productRepository.findById(1L))
                    .thenReturn(Optional.of(existing));
            when(productRepository.save(any()))
                    .thenReturn(existing);

            UpdateLoanProductRequestDTO req =
                    new UpdateLoanProductRequestDTO();
            req.setIsActive(false);

            productService.updateProduct(1L, req, "admin");

            assertThat(existing.getIsActive()).isFalse();
        }

        @Test
        @DisplayName("Should throw 404 for non-existent product")
        void updateProduct_notFound_throws404() {

            when(productRepository.findById(999L))
                    .thenReturn(Optional.empty());

            assertThatThrownBy(() ->
                productService.updateProduct(
                    999L,
                    new UpdateLoanProductRequestDTO(),
                    "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("httpStatus")
                .isEqualTo(HttpStatus.NOT_FOUND);
        }

        @Test
        @DisplayName("Should throw 409 for duplicate name")
        void updateProduct_duplicateName_throws409() {

            LoanProduct existing =
                    buildProduct(1L, "Personal Loan", true);
            LoanProduct other =
                    buildProduct(2L, "Home Loan", true);

            when(productRepository.findById(1L))
                    .thenReturn(Optional.of(existing));
            when(productRepository
                    .existsByProductNameIgnoreCase("Home Loan"))
                .thenReturn(true);

            UpdateLoanProductRequestDTO req =
                    new UpdateLoanProductRequestDTO();
            req.setProductName("Home Loan");

            assertThatThrownBy(() ->
                productService.updateProduct(
                        1L, req, "admin"))
                .isInstanceOf(NeoBankException.class)
                .extracting("errorCode")
                .isEqualTo("PRODUCT_EXISTS");
        }

        @Test
        @DisplayName("Should allow updating with same name")
        void updateProduct_sameName_doesNotThrow() {

            LoanProduct existing =
                    buildProduct(1L, "Personal Loan", true);

            when(productRepository.findById(1L))
                    .thenReturn(Optional.of(existing));
            when(productRepository
                    .existsByProductNameIgnoreCase(
                            "Personal Loan"))
                .thenReturn(true); // exists but same product
            when(productRepository.save(any()))
                    .thenReturn(existing);

            UpdateLoanProductRequestDTO req =
                    new UpdateLoanProductRequestDTO();
            req.setProductName("Personal Loan"); // same name

            // Should NOT throw because it's the same product
            assertThatCode(() ->
                productService.updateProduct(
                        1L, req, "admin"))
                .doesNotThrowAnyException();
        }
    }
}
import {
  Component, OnInit, OnDestroy, signal,
  ViewChild, ElementRef
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnalyticsService } from
  '../../../core/services/analytics.service';
import { AuthService } from
  '../../../core/services/auth.service';
import { NotificationService } from
  '../../../core/services/notification.service';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

type Tab = 'spending' | 'wealth';

@Component({
  selector: 'app-user-analytics',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './customer-analytics.component.html',
  styleUrl: './customer-analytics.component.css',
})
export class CustomerAnalyticsComponent implements OnInit, OnDestroy {

  @ViewChild('doughnutChart')
  doughnutRef!: ElementRef<HTMLCanvasElement>;

  @ViewChild('stackedBarChart')
  stackedBarRef!: ElementRef<HTMLCanvasElement>;

  @ViewChild('netWorthChart')
  netWorthRef!: ElementRef<HTMLCanvasElement>;

  @ViewChild('rewardChart')
  rewardRef!: ElementRef<HTMLCanvasElement>;

  error = signal('');
  tab = signal<Tab>('spending');

  spendingLoading = signal(true);
  spendingData = signal<any>(null);
  selectedMonthIdx = signal(5);

  private doughnutChart: Chart | null = null;
  private stackedChart: Chart | null = null;

  wealthLoading = signal(true);
  wealthData = signal<any>(null);

  private netWorthChart: Chart | null = null;
  private rewardChart: Chart | null = null;

  private userId = 0;

  // ✅ lowercase mapping for chart
  private readonly CATEGORY_COLORS: Record<string, string> = {
    groceries: '#22c55e',
    utilities: '#6366f1',
    rent: '#ef4444',
    entertainment: '#f59e0b',
    transport: '#8b5cf6',
    other: '#9ca3af'
  };

  // ✅ used in HTML legend
  categoryColors: Record<string, string> = {
    Groceries: '#22c55e',
    Utilities: '#6366f1',
    Rent: '#ef4444',
    Entertainment: '#f59e0b',
    Transport: '#8b5cf6',
    Other: '#9ca3af'
  };

  constructor(
    private analyticsService: AnalyticsService,
    private authService: AuthService,
    private ns: NotificationService
  ) {}

  ngOnInit(): void {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.userId = user.userId ?? 0;
    this.loadSpending();
  }

  ngOnDestroy(): void {
    this.doughnutChart?.destroy();
    this.stackedChart?.destroy();
    this.netWorthChart?.destroy();
    this.rewardChart?.destroy();
  }

  switchTab(t: Tab): void {
    this.tab.set(t);
    this.error.set('');

    if (t === 'wealth' && !this.wealthData()) {
      this.loadWealth();
    } else if (t === 'wealth') {
      setTimeout(() => {
        this.buildNetWorthChart();
        this.buildRewardChart();
      }, 100);
    } else {
      setTimeout(() => {
        this.buildDoughnutChart();
        this.buildStackedBarChart();
      }, 100);
    }
  }

  // ✅ FIXED METHOD
  selectMonth(idx: number): void {
    this.selectedMonthIdx.set(idx);
    setTimeout(() => this.buildDoughnutChart(), 50);
  }

  // ✅ LOAD DATA (FIXED)
  loadSpending(): void {
    this.spendingLoading.set(true);

    this.analyticsService
      .getSpendingAnalytics(this.userId, 6)
      .subscribe({
        next: (res: any) => {
          this.spendingLoading.set(false);

          if (res.success) {
            this.spendingData.set(res.data);

            this.selectedMonthIdx.set(
              res.data.monthlySpending.length - 1
            );

            setTimeout(() => {
              this.buildDoughnutChart();
              this.buildStackedBarChart();
            }, 100);
          }
        },
        error: (err: any) => {
          this.spendingLoading.set(false);
          this.error.set(err.error?.message ?? 'Failed to load.');
        }
      });
  }

  get selectedMonth(): any {
    const data = this.spendingData();
    if (!data) return null;
    return data.monthlySpending[this.selectedMonthIdx()];
  }

  // ✅ MULTICOLOR DOUGHNUT
  buildDoughnutChart(): void {
    const month = this.selectedMonth;
    if (!month || !this.doughnutRef) return;

    this.doughnutChart?.destroy();

    const categories = month.categories || [];
    if (!categories.length) return;

    const labels = categories.map((c: any) => c.category);

    const normalized = labels.map((l: string) =>
      l.toLowerCase().trim()
    );

    const values: number[] = categories.map((c: any) =>
      Number(c.amount) || 0
    );

    const colors = normalized.map((l: string) =>
      this.CATEGORY_COLORS[l] || this.getRandomColor()
    );

    const ctx = this.doughnutRef.nativeElement.getContext('2d');
    if (!ctx) return;

    this.doughnutChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: colors,
          borderWidth: 2,
          borderColor: '#fff',
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: { position: 'right' },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const val = ctx.parsed as number;
                const total = values.reduce(
                  (a: number, b: number) => a + b, 0
                );

                const pct = total
                  ? ((val / total) * 100).toFixed(1)
                  : '0';

                return `${ctx.label}: ${this.fmt(val)} (${pct}%)`;
              }
            }
          }
        }
      }
    });
  }

  // ✅ SIMPLE BAR CHART
  buildStackedBarChart(): void {
    const data = this.spendingData();
    if (!data?.monthlySpending?.length || !this.stackedBarRef) return;

    this.stackedChart?.destroy();

    const labels = data.monthlySpending.map((m: any) => m.monthLabel);
    const values = data.monthlySpending.map((m: any) =>
      Number(m.totalSpent) || 0
    );

    const ctx = this.stackedBarRef.nativeElement.getContext('2d');
    if (!ctx) return;

    this.stackedChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Total Spending',
          data: values,
          backgroundColor: '#6366f1'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false
      }
    });
  }

  // ── Wealth (unchanged) ──
  loadWealth(): void {
    this.analyticsService
      .getWealthAnalytics(this.userId)
      .subscribe((res: any) => {
        if (res.success) {
          this.wealthData.set(res.data);
        }
      });
  }

  buildNetWorthChart(): void {}
  buildRewardChart(): void {}

  // ✅ RANDOM COLOR
  getRandomColor(): string {
    const palette = [
      '#06b6d4', '#14b8a6', '#f43f5e',
      '#84cc16', '#eab308', '#a855f7',
      '#f97316'
    ];
    return palette[Math.floor(Math.random() * palette.length)];
  }

  fmt(v: string | number | null): string {
    if (v == null) return '₹0.00';
    const n = parseFloat(String(v));
    return isNaN(n)
      ? '₹0.00'
      : '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 2 });
  }

  get netWorthPositive(): boolean {
    const nw = this.wealthData()?.currentNetWorth;
    return nw ? parseFloat(nw) >= 0 : true;
  }
}

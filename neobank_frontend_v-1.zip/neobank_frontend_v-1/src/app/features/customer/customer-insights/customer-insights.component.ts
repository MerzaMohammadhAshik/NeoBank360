// customer-insights.component.ts

import {
  Component, Input, OnInit,
  signal, ViewChild, ElementRef,
  AfterViewInit, OnDestroy
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { InsightsService } from
  '../../../core/services/insights.service';
import { NotificationService } from
  '../../../core/services/notification.service';
import { AuthService } from
  '../../../core/services/auth.service';

// Chart.js
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

@Component({
  selector:    'app-customer-insights',
  standalone:  true,
  imports:     [CommonModule],
  templateUrl: './customer-insights.component.html',
  styleUrl:    './customer-insights.component.css',
})
export class CustomerInsightsComponent
    implements OnInit, AfterViewInit, OnDestroy {

  @Input() isDark = false;
  @ViewChild('trendChart')
  chartRef!: ElementRef<HTMLCanvasElement>;

  // ── Alerts ──
  error   = signal('');
  success = signal('');

  // ── State ──
  loading  = signal(true);
  insights = signal<any>(null);

  private chart: Chart | null = null;
  private userId: number = 0;

  constructor(
    private insightsService: InsightsService,
    private ns:              NotificationService,
    private authService:     AuthService,
  ) {}

  ngOnInit(): void {
    // var user1 : any=null ;
    // var respons : any=null;
    //  this.authService.getUser().subscribe({
    //   next: (res: any) => {
    //     this.loading.set(false);
    //     if (res.success) {
    //       respons=res.data;
    //       setTimeout(() => this.buildChart(), 100);
    //     } else {
    //       this.error.set(res.message ?? 'Failed to load.');
    //     }
    //   },
    //   error: (err: any) => {
    //     this.loading.set(false);
    //     this.error.set(
    //       err.error?.message ?? 'Failed to load insights.');
    //   },
    // });
    // // user=respons;
    
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.userId = user.userId ?? user.user ?? 0;
    // this.userId=1;
    this.loadInsights();
  }

  ngAfterViewInit(): void {
    // Chart built after data loads
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  // ── Load ──
  loadInsights(): void {
    this.loading.set(true);
    this.error.set('');

    this.insightsService.getInsights(this.userId).subscribe({
      next: (res: any) => {
        this.loading.set(false);
        if (res.success) {
          this.insights.set(res.data);
          setTimeout(() => this.buildChart(), 100);
        } else {
          this.error.set(res.message ?? 'Failed to load.');
        }
      },
      error: (err: any) => {
        this.loading.set(false);
        this.error.set(
          err.error?.message ?? 'Failed to load insights.');
      },
    });
  }

  // ── Build Chart ──
  buildChart(): void {
    const data = this.insights();
    if (!data?.trendSummary || !this.chartRef) return;

    this.chart?.destroy();

    const labels  = data.trendSummary.map(
      (t: any) => t.monthLabel);
    const income  = data.trendSummary.map(
      (t: any) => parseFloat(t.totalIncome));
    const expense = data.trendSummary.map(
      (t: any) => parseFloat(t.totalExpense));

    const ctx = this.chartRef.nativeElement.getContext('2d');
    if (!ctx) return;

    this.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Income',
            data: income,
            backgroundColor: 'rgba(34, 197, 94, 0.8)',
            borderColor:     '#16a34a',
            borderWidth:     2,
            borderRadius:    6,
          },
          {
            label: 'Expense',
            data: expense,
            backgroundColor: 'rgba(239, 68, 68, 0.8)',
            borderColor:     '#dc2626',
            borderWidth:     2,
            borderRadius:    6,
          },
        ],
      },
      options: {
        responsive:          true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              color:    this.isDark ? '#f1f5f9' : '#0f172a',
              padding:  16,
              font:     { size: 12, weight: 'bold' },
            },
          },
          tooltip: {
            callbacks: {
              label: (ctx) =>
                ` ₹${(ctx.parsed.y??0).toLocaleString('en-IN',
                  { minimumFractionDigits: 2 })}`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: this.isDark
              ? 'rgba(255,255,255,0.05)'
              : 'rgba(0,0,0,0.05)' },
            ticks: {
              color: this.isDark ? '#94a3b8' : '#64748b',
              font:  { size: 11 },
            },
          },
          y: {
            grid: { color: this.isDark
              ? 'rgba(255,255,255,0.05)'
              : 'rgba(0,0,0,0.05)' },
            ticks: {
              color:    this.isDark ? '#94a3b8' : '#64748b',
              font:     { size: 11 },
              callback: (val) =>
                '₹' + Number(val).toLocaleString('en-IN'),
            },
          },
        },
      },
    });
  }

  // ── Helpers ──
  fmt(v: string | number | null): string {
    if (v == null) return '₹0.00';
    const n = parseFloat(String(v));
    if (isNaN(n)) return '₹0.00';
    return '₹' + n.toLocaleString('en-IN',
      { minimumFractionDigits: 2 });
  }

  get savingsClass(): string {
    const s = this.insights();
    if (!s) return '';
    return s.savingsNegative ? 'savings-negative' : 'savings-positive';
  }

  get savingsIcon(): string {
    const s = this.insights();
    if (!s) return '💰';
    return s.savingsNegative ? '📉' : '📈';
  }

  get maxTrendValue(): number {
    const data = this.insights();
    if (!data?.trendSummary) return 1;
    return Math.max(
      ...data.trendSummary.map(
        (t: any) => Math.max(
          parseFloat(t.totalIncome),
          parseFloat(t.totalExpense)
        )
      ), 1);
  }

  barHeight(val: string): number {
    const max = this.maxTrendValue;
    const v   = parseFloat(val);
    return max > 0 ? Math.round((v / max) * 120) : 0;
  }
  // Add to customer-insights.component.ts class:
parseFloat = parseFloat;
}
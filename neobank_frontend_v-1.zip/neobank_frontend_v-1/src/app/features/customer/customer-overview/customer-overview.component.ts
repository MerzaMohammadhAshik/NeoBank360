// customer-overview.component.ts

import {
  Component, EventEmitter, Input, OnInit, Output, signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { InsightsService } from
  '../../../core/services/insights.service';
import { AuthService } from
  '../../../core/services/auth.service';
import { NotificationService } from
  '../../../core/services/notification.service';

@Component({
  selector:    'app-customer-overview',
  standalone:  true,
  imports:     [CommonModule],
  templateUrl: './customer-overview.component.html',
  styleUrl:    './customer-overview.component.css',
})
export class CustomerOverviewComponent implements OnInit {

  @Input() accounts: any[] = [];
  @Input() isDark = false;
  @Input() totalAccounts : number= 0;


  @Output() sectionSelected = new EventEmitter<string>();

  onSectionSelected(section: string): void {
    this.sectionSelected.emit(section);
  }

  // ── Insights (replaces balance/interest/type cards) ──
  insights        = signal<any>(null);
  insightsLoading = signal(true);

  // ── User ──
  userName = signal('');
  private userId = 0;
  

  constructor(
    private insightsService: InsightsService,
    private authService:     AuthService,
    private ns:              NotificationService,
  ) {}

ngOnInit(): void {
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  this.userId = user?.userId ?? user?.id ?? 0;

  this.userName.set(
    user?.fullName ?? user?.username ?? 'User'
  );

  this.loadInsights();
}

  

  // ── Load financial insights ──
  loadInsights(): void {
    this.insightsLoading.set(true);

    this.insightsService
        .getInsights(this.userId)
        .subscribe({
      next: (res: any) => {
        this.insightsLoading.set(false);
        if (res.success) {
          this.insights.set(res.data);
        }
      },
      error: () => {
        this.insightsLoading.set(false);
        // Silently fail — overview still shows accounts
      },
    });
  }

  // ── Helpers ──
  fmt(v: string | number | null): string {
    if (v == null) return '₹0.00';
    const n = parseFloat(String(v));
    if (isNaN(n)) return '₹0.00';
    return '₹' + n.toLocaleString('en-IN',
      { minimumFractionDigits: 2 });
  }

  get savingsNegative(): boolean {
    return this.insights()?.savingsNegative === true;
  }

  // get totalAccounts(): number {
  //   return this.accounts?.length ?? 0;
  // }

  get greeting(): string {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  }
}

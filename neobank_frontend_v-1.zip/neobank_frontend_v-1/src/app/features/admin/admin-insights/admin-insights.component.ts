// admin-insights.component.ts

import {
  Component, OnInit, signal,
  ViewChild, ElementRef, OnDestroy
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InsightsService } from
  '../../../core/services/insights.service';
import { NotificationService } from
  '../../../core/services/notification.service';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

type Tab = 'overview' | 'pending' | 'health' | 'audit';
type PendingFilter = 'ALL' | 'LOAN' | 'CARD' | 'APPLICATION';

@Component({
  selector:    'app-admin-insights',
  standalone:  true,
  imports:     [CommonModule, FormsModule],
  templateUrl: './admin-insights.component.html',
  styleUrl:    './admin-insights.component.css',
})
export class AdminInsightsComponent
    implements OnInit, OnDestroy {

  // ── Alerts ──
  error   = signal('');
  success = signal('');

  // ── Tabs ──
  tab = signal<Tab>('overview');

  // ── Dashboard ──
  dashboard        = signal<any>(null);
  dashboardLoading = signal(true);

  // ── Pending ──
  pending        = signal<any[]>([]);
  pendingLoading = signal(false);
  pendingFilter  = signal<PendingFilter>('ALL');

  // ── Health ──
  health        = signal<any>(null);
  healthLoading = signal(false);

  // ── User Activity ──
  selectedUser   = signal<any>(null);
  activityLoading = signal(false);
  activityUser   = signal<any>(null);

  private refreshTimer: any;

  constructor(
    private insightsService: InsightsService,
    private ns:              NotificationService,
  ) {}

  ngOnInit(): void {
    this.loadDashboard();
  }

  ngOnDestroy(): void {
    clearInterval(this.refreshTimer);
  }

  // ── Load Dashboard ──
  loadDashboard(): void {
    this.dashboardLoading.set(true);
    this.insightsService.getAdminDashboard().subscribe({
      next: (res: any) => {
        this.dashboardLoading.set(false);
        if (res.success) this.dashboard.set(res.data);
        else this.error.set(
          res.message ?? 'Failed to load dashboard.');
      },
      error: (err: any) => {
        this.dashboardLoading.set(false);
        this.error.set(
          err.error?.message ?? 'Failed to load dashboard.');
      },
    });
  }

  // ── Load Pending ──
  loadPending(filter?: string): void {
    this.pendingLoading.set(true);
    const mod = filter === 'ALL' ? undefined : filter;
    this.insightsService.getPendingApprovals(mod).subscribe({
      next: (res: any) => {
        this.pendingLoading.set(false);
        if (res.success) this.pending.set(res.data ?? []);
      },
      error: () => {
        this.pendingLoading.set(false);
        this.ns.danger('Failed to load pending approvals.');
      },
    });
  }

  // ── Load Health ──
  loadHealth(): void {
    this.healthLoading.set(true);
    this.insightsService.getSystemHealth().subscribe({
      next: (res: any) => {
        this.healthLoading.set(false);
        if (res.success) this.health.set(res.data);
      },
      error: () => {
        this.healthLoading.set(false);
        this.ns.danger('Failed to load system health.');
      },
    });
  }

  // ── Tab Switch ──
  switchTab(t: Tab): void {
    this.tab.set(t);
    this.error.set('');
    if (t === 'pending' && this.pending().length === 0) {
      this.loadPending();
    }
    if (t === 'health' && !this.health()) {
      this.loadHealth();
    }
  }

  // ── Filter Pending ──
  filterPending(f: string): void {
    this.pendingFilter.set(f as PendingFilter);
    this.loadPending(f === 'ALL' ? undefined : f);
  }

  // ── User Status Toggle ──
  toggleUserStatus(user: any): void {
    const newStatus =
      user.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';

    if (!confirm(
      `${newStatus === 'ACTIVE' ? 'Activate' : 'Deactivate'} ` +
      `user ${user.username}?`
    )) return;

    this.insightsService
        .updateUserStatus(user.id, newStatus).subscribe({
      next: (res: any) => {
        if (res.success) {
          this.ns.success(
            `${user.username} ${newStatus.toLowerCase()}d.`);
          this.loadDashboard();
        }
      },
      error: (err: any) => {
        const code = err.error?.errorCode ?? '';
        if (code === 'SELF_DEACTIVATION') {
          this.ns.warning(
            'You cannot deactivate your own account.');
        } else {
          this.ns.danger(
            err.error?.message ?? 'Failed.');
        }
      },
    });
  }

  // ── Helpers ──
  fmt(v: string | number | null): string {
    if (v == null) return '₹0.00';
    const n = parseFloat(String(v));
    if (isNaN(n)) return '₹0.00';
    return '₹' + n.toLocaleString('en-IN',
      { minimumFractionDigits: 2 });
  }

  getModuleIcon(mod: string): string {
    return {
      LOAN:        '🏦',
      CARD:        '💳',
      APPLICATION: '📋',
    }[mod] ?? '📄';
  }

  getModuleClass(mod: string): string {
    return {
      LOAN:        'mod-loan',
      CARD:        'mod-card',
      APPLICATION: 'mod-app',
    }[mod] ?? 'mod-app';
  }

  get dashKpis(): any[] {
    const d = this.dashboard();
    if (!d) return [];
    return [
      {
        icon: '👥', label: 'Total Users',
        val: d.totalUsers, sub: `${d.totalActiveUsers} active`,
        color: '#6366f1',
      },
      {
        icon: '🏦', label: 'Total Accounts',
        val: d.totalAccounts,
        sub: `${d.totalActiveAccounts} active`,
        color: '#0d7377',
      },
      {
        icon: '💸', label: 'Transactions',
        val: d.totalTransactions,
        sub: `${d.todayTransactions} today`,
        color: '#f59e0b',
      },
      {
        icon: '📋', label: 'Total Loans',
        val: d.totalLoans,
        sub: `${d.activeLoans} active`,
        color: '#8b5cf6',
      },
      {
        icon: '⏳', label: 'Pending Approvals',
        val: d.totalPendingApprovals,
        sub: `${d.pendingLoans}L / ` +
             `${d.pendingCards}C / ` +
             `${d.pendingApplications}A`,
        color: '#ef4444',
        urgent: d.totalPendingApprovals > 0,
      },
      {
        icon: '📈', label: 'Savings Rate',
        val: d.platformSavingsRate,
        sub: 'Platform-wide',
        color: '#22c55e',
      },
    ];
  }
}
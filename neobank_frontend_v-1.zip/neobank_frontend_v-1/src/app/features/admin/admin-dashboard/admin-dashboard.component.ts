import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output, signal } from '@angular/core';
import { AdminService } from '../../../core/services/admin.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css',
})
export class AdminDashboardComponent implements OnInit {
  @Output() navigateTo = new EventEmitter<string>();

  stats = signal<any>(null);
  statsLoading = signal(false);

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadStats();
  }

  loadStats(): void {
    this.statsLoading.set(true);
    this.adminService.getAdminStats().subscribe({
      next: (res: any) => {
        this.statsLoading.set(false);
        if (res.success) {
          this.stats.set(res.data);
        }
      },
      error: () => this.statsLoading.set(false),
    });
  }

  formatAmount(value: string | number | null | undefined): string {
    const amount = Number(value ?? 0);

    return `₹${(Number.isFinite(amount) ? amount : 0).toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  }
}

// admin-analytics.component.ts

import {
  Component, OnInit, OnDestroy, signal,
  ViewChild, ElementRef
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AnalyticsService } from
  '../../../core/services/analytics.service';
import { NotificationService } from
  '../../../core/services/notification.service';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

type Tab = 'transactions' | 'loans' | 'logs';
type Timeframe = '7d' | '30d' | 'YTD';

@Component({
  selector:    'app-admin-analytics',
  standalone:  true,
  imports:     [CommonModule, FormsModule],
  templateUrl: './admin-analytics.component.html',
  styleUrl:    './admin-analytics.component.css',
})
export class AdminAnalyticsComponent
    implements OnInit, OnDestroy {

  @ViewChild('volumeChart')
  volumeChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('loanChart')
  loanChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('errorRateChart')
  errorRateChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('responseTimeChart')
  responseTimeChartRef!: ElementRef<HTMLCanvasElement>;

  error = signal('');
  tab   = signal<Tab>('transactions');

  // ── Transactions ──
  txnTimeframe = signal<Timeframe>('7d');
  txnLoading   = signal(true);
  txnData      = signal<any>(null);
  private volumeChart: Chart | null = null;

  // ── Loans ──
  loanTimeframe = signal<Timeframe>('30d');
  loanLoading   = signal(true);
  loanData      = signal<any>(null);
  private loanChart: Chart | null = null;

  // ── System Logs ──
  logsLoading = signal(true);
  logsData    = signal<any>(null);
  statusFilter = signal<string>('');
  logPage = signal(0);
  private errorRateChart: Chart | null = null;
  private responseTimeChart: Chart | null = null;

  constructor(
    private analyticsService: AnalyticsService,
    private ns:               NotificationService,
  ) {}

  ngOnInit(): void {
    this.loadTransactionAnalytics();
    this.loadLoanAnalytics();
  }

  ngOnDestroy(): void {
    this.volumeChart?.destroy();
    this.loanChart?.destroy();
    this.errorRateChart?.destroy();
    this.responseTimeChart?.destroy();
  }

  // ══════════════════════════════════════════
  //  TAB SWITCH
  // ══════════════════════════════════════════

  switchTab(t: Tab): void {
    this.tab.set(t);
    this.error.set('');
    if (t === 'logs' && !this.logsData()) {
      this.loadSystemLogs();
    }
  }

  // ══════════════════════════════════════════
  //  TRANSACTION ANALYTICS
  // ══════════════════════════════════════════

  loadTransactionAnalytics(): void {
    this.txnLoading.set(true);
    this.analyticsService
        .getTransactionAnalytics(this.txnTimeframe())
        .subscribe({
      next: (res: any) => {
        this.txnLoading.set(false);
        if (res.success) {
          this.txnData.set(res.data);
          setTimeout(() => this.buildVolumeChart(), 100);
        }
      },
      error: (err: any) => {
        this.txnLoading.set(false);
        this.error.set(
          err.error?.message ?? 'Failed to load.');
      },
    });
  }

  changeTxnTimeframe(tf: Timeframe): void {
    this.txnTimeframe.set(tf);
    this.loadTransactionAnalytics();
  }

  buildVolumeChart(): void {
    const data = this.txnData();
    if (!data?.dailyVolumes || !this.volumeChartRef) return;

    this.volumeChart?.destroy();

    const labels = data.dailyVolumes.map((d: any) =>
      this.shortDate(d.date));
    const inflow = data.dailyVolumes.map((d: any) =>
      parseFloat(d.inflow));
    const outflow = data.dailyVolumes.map((d: any) =>
      parseFloat(d.outflow));

    const ctx = this.volumeChartRef.nativeElement
        .getContext('2d');
    if (!ctx) return;

    this.volumeChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Inflow',
            data: inflow,
            borderColor: '#22c55e',
            backgroundColor: 'rgba(34,197,94,0.1)',
            fill: true, tension: 0.3,
          },
          {
            label: 'Outflow',
            data: outflow,
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239,68,68,0.1)',
            fill: true, tension: 0.3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top' },
tooltip: {
  callbacks: {
    label: (ctx) => {
      const value = ctx.parsed.y ?? 0;
      return `₹${value.toLocaleString('en-IN', {
        minimumFractionDigits: 2
      })}`;
    }
  }
}
        },
        scales: {
          y: {
            ticks: {
              callback: (val) =>
                '₹' + Number(val).toLocaleString('en-IN'),
            },
          },
        },
      },
    });
  }

  // ══════════════════════════════════════════
  //  LOAN ANALYTICS
  // ══════════════════════════════════════════

  loadLoanAnalytics(): void {
    this.loanLoading.set(true);
    this.analyticsService
        .getLoanAnalytics(this.loanTimeframe())
        .subscribe({
      next: (res: any) => {
        this.loanLoading.set(false);
        if (res.success) {
          this.loanData.set(res.data);
          setTimeout(() => this.buildLoanChart(), 100);
        }
      },
      error: (err: any) => {
        this.loanLoading.set(false);
        this.error.set(
          err.error?.message ?? 'Failed to load.');
      },
    });
  }

  changeLoanTimeframe(tf: Timeframe): void {
    this.loanTimeframe.set(tf);
    this.loadLoanAnalytics();
  }

  buildLoanChart(): void {
    const data = this.loanData();
    if (!data?.loanDistribution || !this.loanChartRef) return;

    this.loanChart?.destroy();

    // Group by status, stack by loan type
    const statuses = ['PENDING','APPROVED','REJECTED',
                       'CLOSED','OVERDUE','FORECLOSED'];
    const loanTypes = [...new Set(
      data.loanDistribution.map((d: any) => d.loanType))];

    const colorMap: Record<string,string> = {
      PERSONAL: '#6366f1', HOME: '#8b5cf6',
      VEHICLE: '#f59e0b', EDUCATION: '#ec4899',
    };

    const datasets = loanTypes.map((type: any) => ({
      label: type,
      data: statuses.map(status => {
        const match = data.loanDistribution.find(
          (d: any) => d.status === status &&
                       d.loanType === type);
        return match ? match.count : 0;
      }),
      backgroundColor: colorMap[type as string] ?? '#94a3b8',
    }));

    const ctx = this.loanChartRef.nativeElement
        .getContext('2d');
    if (!ctx) return;

    this.loanChart = new Chart(ctx, {
      type: 'bar',
      data: { labels: statuses, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'top' } },
        scales: {
          x: { stacked: true },
          y: { stacked: true, beginAtZero: true,
               ticks: { stepSize: 1 } },
        },
      },
    });
  }

  // ══════════════════════════════════════════
  //  SYSTEM LOGS
  // ══════════════════════════════════════════

  loadSystemLogs(): void {
    this.logsLoading.set(true);
    const status = this.statusFilter()
      ? parseInt(this.statusFilter()) : undefined;

    this.analyticsService.getSystemLogs({
      status, page: this.logPage(), size: 20,
    }).subscribe({
      next: (res: any) => {
        this.logsLoading.set(false);
        if (res.success) {
          this.logsData.set(res.data);
          setTimeout(() => {
            this.buildErrorRateChart();
            this.buildResponseTimeChart();
          }, 100);
        }
      },
      error: () => {
        this.logsLoading.set(false);
        this.ns.danger('Failed to load system logs.');
      },
    });
  }

  filterByStatus(status: string): void {
    this.statusFilter.set(status);
    this.logPage.set(0);
    this.loadSystemLogs();
  }

  changePage(delta: number): void {
    const newPage = this.logPage() + delta;
    if (newPage < 0) return;
    this.logPage.set(newPage);
    this.loadSystemLogs();
  }

  buildErrorRateChart(): void {
    const data = this.logsData();
    if (!data?.errorRateByHour?.length ||
        !this.errorRateChartRef) return;

    this.errorRateChart?.destroy();

    const labels = data.errorRateByHour.map((d: any) =>
      d.hour.split(' ')[1]);
    const rates = data.errorRateByHour.map((d: any) =>
      parseFloat(d.errorRate));

    const ctx = this.errorRateChartRef.nativeElement
        .getContext('2d');
    if (!ctx) return;

    this.errorRateChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Error Rate %',
          data: rates,
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239,68,68,0.1)',
          fill: true, tension: 0.3,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true,
          ticks: { callback: (v) => v + '%' } } },
      },
    });
  }

  buildResponseTimeChart(): void {
    const data = this.logsData();
    if (!data?.responseTimeByHour?.length ||
        !this.responseTimeChartRef) return;

    this.responseTimeChart?.destroy();

    const labels = data.responseTimeByHour.map((d: any) =>
      d.hour.split(' ')[1]);
    const times = data.responseTimeByHour.map((d: any) =>
      parseFloat(d.avgTimeMs));

    const ctx = this.responseTimeChartRef.nativeElement
        .getContext('2d');
    if (!ctx) return;

    this.responseTimeChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Avg Response Time (ms)',
          data: times,
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99,102,241,0.1)',
          fill: true, tension: 0.3,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true,
          ticks: { callback: (v) => v + 'ms' } } },
      },
    });
  }

  // ══════════════════════════════════════════
  //  HELPERS
  // ══════════════════════════════════════════

  fmt(v: string | number | null): string {
    if (v == null) return '₹0.00';
    const n = parseFloat(String(v));
    if (isNaN(n)) return '₹0.00';
    return '₹' + n.toLocaleString('en-IN',
      { minimumFractionDigits: 2 });
  }

  shortDate(dateStr: string): string {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN',
      { day: 'numeric', month: 'short' });
  }

  getStatusClass(status: number): string {
    if (status >= 500) return 'st-500';
    if (status >= 400) return 'st-400';
    if (status >= 300) return 'st-300';
    return 'st-200';
  }

  getMethodClass(method: string): string {
    return {
      GET: 'm-get', POST: 'm-post',
      PUT: 'm-put', PATCH: 'm-patch',
      DELETE: 'm-delete',
    }[method] ?? 'm-get';
  }

  parseFloat=parseFloat;
}
// src/app/core/services/analytics.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AnalyticsService {

  private readonly base = `${environment.apiUrl}/admin`;

  constructor(private http: HttpClient) {}

  getTransactionAnalytics(timeframe: string): Observable<any> {
    return this.http.get(
        `${this.base}/analytics/transactions`,
        { params: { timeframe } });
  }

  getLoanAnalytics(timeframe: string): Observable<any> {
    return this.http.get(
        `${this.base}/analytics/loans`,
        { params: { timeframe } });
  }

  getSystemLogs(params: {
    from?: string; to?: string;
    status?: number; page?: number; size?: number;
  }): Observable<any> {
    const httpParams: any = {};
    if (params.from)   httpParams.from = params.from;
    if (params.to)     httpParams.to = params.to;
    if (params.status) httpParams.status = params.status;
    httpParams.page = params.page ?? 0;
    httpParams.size = params.size ?? 20;

    return this.http.get(
        `${this.base}/system-logs`,
        { params: httpParams });
  }

  // Add to analytics.service.ts

getSpendingAnalytics(userId: number,
    months = 6): Observable<any> {
  return this.http.get(
      `${environment.apiUrl}/analytics/spending/${userId}`,
      { params: { months } });
}

getWealthAnalytics(userId: number): Observable<any> {
  return this.http.get(
      `${environment.apiUrl}/analytics/wealth/${userId}`);
}
}
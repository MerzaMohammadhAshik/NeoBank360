// src/app/core/services/insights.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class InsightsService {

  private readonly base = `${environment.apiUrl}`;

  constructor(private http: HttpClient) {}

  // ── Customer insights ──
  getInsights(userId: number): Observable<any> {
    return this.http.get(
      `${this.base}/insights/${userId}`);
  }

  // ── Admin ──
  getAdminDashboard(): Observable<any> {
    return this.http.get(
      `${this.base}/admin/dashboard`);
  }

  getPendingApprovals(module?: string): Observable<any> {
    const params: any = {};
    if (module) params.module = module;
    return this.http.get(
      `${this.base}/admin/pending-approvals`,
      { params });
  }

  getSystemHealth(): Observable<any> {
    return this.http.get(
      `${this.base}/admin/system-health`);
  }

  getUserActivity(userId: number): Observable<any> {
    return this.http.get(
      `${this.base}/admin/users/${userId}/activity`);
  }

  updateUserStatus(userId: number,
      status: string): Observable<any> {
    return this.http.patch(
      `${this.base}/admin/users/${userId}/status`,
      null, { params: { status } });
  }
}
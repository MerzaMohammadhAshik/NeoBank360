// src/app/core/services/loan.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface EmiCalculation {
  principal: string; annualRate: string; tenureMonths: number;
  emiAmount: string; totalInterest: string; totalPayable: string;
}

@Injectable({ providedIn: 'root' })
export class LoanService {

  private readonly base = `${environment.apiUrl}/loans`;

  constructor(private http: HttpClient) {}

  calculateEmi(payload: {
    principal: string; annualRate: string; tenureMonths: number;
  }): Observable<any> {
    return this.http.post(`${this.base}/calculate-emi`, payload);
  }

  applyLoan(form: FormData): Observable<any> {
    return this.http.post(`${this.base}/apply`, form);
  }

  getMyLoans(): Observable<any> {
    return this.http.get(`${this.base}/my`);
  }

  getEmiSchedule(loanId: string): Observable<any> {
    return this.http.get(`${this.base}/${loanId}/emi-schedule`);
  }

  requestForeclosure(loanId: string): Observable<any> {
    return this.http.post(`${this.base}/${loanId}/foreclosure`, {});
  }

  // Admin
  getAllLoans(status = '', page = 0, size = 15): Observable<any> {
    return this.http.get(`${this.base}/admin/all`,
      { params: { status, page, size } });
  }

  getLoanDetail(loanId: string): Observable<any> {
    return this.http.get(`${this.base}/admin/${loanId}`);
  }

  approveLoan(loanId: string, interestRate: string,treasuryId : any): Observable<any> {
    return this.http.post(`${this.base}/admin/${loanId}/approve`,
      { interestRate });
  }

  rejectLoan(loanId: string, reason: string): Observable<any> {
    return this.http.post(`${this.base}/admin/${loanId}/reject`,
      { reason });
  }

  approveForeclosure(loanId: string): Observable<any> {
    return this.http.post(
      `${this.base}/admin/${loanId}/foreclosure/approve`, {});
  }

  
}
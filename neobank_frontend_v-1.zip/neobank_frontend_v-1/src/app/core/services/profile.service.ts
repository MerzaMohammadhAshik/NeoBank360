// src/app/core/services/profile.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface UpdateProfilePayload {
  fullName?:    string;
  phone?:       string;
  dateOfBirth?: string;
  gender?:      string;
  addressLine?: string;
  city?:        string;
  state?:       string;
  pincode?:     string;
}

export interface UpdateEmailPayload {
  newEmail: string;
  otp:      string;
}

@Injectable({ providedIn: 'root' })
export class ProfileService {

  private readonly base = `${environment.apiUrl}/profile`;

  constructor(private http: HttpClient) {}

  getMyProfile(): Observable<any> {
    return this.http.get(this.base);
  }

  updateProfile(payload: UpdateProfilePayload): Observable<any> {
    return this.http.put(this.base, payload);
  }

  uploadPhoto(file: File): Observable<any> {
    const form = new FormData();
    form.append('photo', file, file.name);
    return this.http.post(`${this.base}/photo`, form);
  }

  removePhoto(): Observable<any> {
    return this.http.delete(`${this.base}/photo`);
  }

  sendEmailChangeOtp(newEmail: string): Observable<any> {
    return this.http.post(
      `${this.base}/email/send-otp`,
      null,
      { params: { newEmail } }
    );
  }

  updateEmail(payload: UpdateEmailPayload): Observable<any> {
    return this.http.put(`${this.base}/email`, payload);
  }
}
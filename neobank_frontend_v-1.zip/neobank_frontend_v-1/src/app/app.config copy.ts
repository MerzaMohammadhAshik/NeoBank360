// //------------------------- app.config.ts -----------------------------//
// import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
// import { provideRouter } from '@angular/router';
// import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';

// import { routes } from './app.routes';
// // import { authInterceptor } from './core/interceptors/auth.interceptor';
// import { HTTP_INTERCEPTORS } from '@angular/common/http';
// import { JwtInterceptor } from './core/interceptors/jwt.intercepter';

// // export const appConfig: ApplicationConfig = {
// //   providers: [
// //     provideBrowserGlobalErrorListeners(),
// //     provideRouter(routes),
// //     provideHttpClient(withFetch()
// //     , withInterceptors([authInterceptor])
// //   )
// //     ,{
// //   provide:  HTTP_INTERCEPTORS,
// //   useClass: JwtInterceptor,
// //   multi:    true,
// // }
// //   ]
// // };



// // app.config.ts
// export const appConfig: ApplicationConfig = {
//   providers: [
//     provideBrowserGlobalErrorListeners(),
//     provideRouter(routes),
//     provideHttpClient(), // ← remove withFetch()
//     {
//       provide: HTTP_INTERCEPTORS,
//       useClass: JwtInterceptor,
//       multi: true,
//     }
//   ]
// };







// // // app.config.ts
// // import { provideHttpClient, withInterceptors } from '@angular/common/http';
// // import { HTTP_INTERCEPTORS } from '@angular/common/http';
// // import { JwtInterceptor } from './core/interceptors/jwt.interceptor';

// // // Add to providers:
// // {
// //   provide:  HTTP_INTERCEPTORS,
// //   useClass: JwtInterceptor,
// //   multi:    true,
// // }
// src/environments/environment.ts

export const environment = {
  production: false,
  apiUrl: 'http://localhost:8765/api',
};